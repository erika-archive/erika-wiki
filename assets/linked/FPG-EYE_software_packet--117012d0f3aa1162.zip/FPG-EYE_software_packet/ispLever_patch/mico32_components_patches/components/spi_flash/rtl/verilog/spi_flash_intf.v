// ==============================================================================
//                            NOTICE
// This software is a version modified and distributed by Evidence srl 
// under the conditions of the 
// Lattice Semiconductor Corporation Open Source License Agreement.
// The heading below is taken verbatim from the original file.
// ==============================================================================

// =============================================================================
//                           COPYRIGHT NOTICE
// Copyright 2006 (c) Lattice Semiconductor Corporation
// ALL RIGHTS RESERVED
// This confidential and proprietary software may be used only as authorised by
// a licensing agreement from Lattice Semiconductor Corporation.
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement from
// Lattice Semiconductor Corporation.
//
// Lattice Semiconductor Corporation        TEL : 1-800-Lattice (USA and Canada)
// 5555 NE Moore Court                            408-826-6000 (other locations)
// Hillsboro, OR 97124                     web  : http://www.latticesemi.com/
// U.S.A                                   email: techsupport@latticesemi.com
// =============================================================================/
//                         FILE DETAILS
// Project          : SPI Flash Controller
// File             : spi_flash_intf.v
// Title            : Module that implements SPI signalling.
// Version          : 3.0
//                  : Initial version (replaces deprecated SPI Flash ROM v3.1)
// =============================================================================
module spi_flash_intf
       #(parameter BUF_WIDTH  = 6,
         parameter PAGE_WIDTH = 8)
(
// SPI flash signals
output reg           SI,                  // Serial data to SPI flash
input  wire          SO,                  // Serial data from SPI flash
output reg           CS,                  // SPI flash chip select
output wire          SCK,                 // Serial clock to SPI flash
output wire          WP,                  // Write protect

// command from wishbone to SPI flash signals
input  wire [31:0]    spi_cmd,             // command and address send to spi flash
input  wire [31:0]    spi_cmd_ext,         // extended high 4 bytes of command address send to spi flash
                                           // only used for arbitrary command
input  wire [3:0]     cmd_bytes,           // command and address byte numbers send to spi flash
input  wire [PAGE_WIDTH:0]  byte_length,         // data bytes after address command
input  wire           page_cmd,            // page program or page read command
input  wire           wr_enb,              // precede a write enable command
output reg  [31:0]    read_data,           // return data from spi flash
input  wire [31:0]    write_data,          // data write to spi flash
input  wire [7:0]     spi_wrt_enb,         // spi write enable command byte
input  wire [7:0]     spi_read_stat,       // spi read status register command byte
input  wire           fast_read,           // read command is fast read
input  wire           spi_wr,              // asserted when spi write command
input  wire           spi_req,             // request a spi command, deasserted when detect a positive edge on spi_ack
output reg            spi_ack,             // acknowledge a spi command, deasserted when the transaction is finished

`ifdef PAGE_PRG_BUF_ENA
output wire [BUF_WIDTH-1:0] wb2spi_rd_addr,
input  wire [31:0]          wb2spi_q,
`endif

`ifdef PAGE_READ_BUF_ENA
output reg  [BUF_WIDTH-1:0] spi2wb_wr_addr,
output reg  [31:0]          spi2wb_data,
output reg                  spi2wb_we,
`endif

// system signals
input            spi_clk,
input            RST_I
);

// cmd_state state machine
parameter CMD_IDLE = 2'b00;
parameter CMD_ENB  = 2'b01;
parameter CMD_SPI  = 2'b10;
parameter CMD_CHK  = 2'b11;
// spi_state state machine
parameter SPI_IDLE   =3'b000;
parameter SPI_OPCODE =3'b001;
parameter SPI_WAIT   =3'b010;
parameter SPI_READ   =3'b011;
parameter SPI_WRITE  =3'b100;
parameter SPI_END    =3'b101;
parameter SPI_INIT   =3'b110;

parameter STOP_CYCLE    = 8;  // for 100MHz, 100ns/period(ns)-2

reg [1:0]       cmd_state;
reg [2:0]       spi_state;
reg [5:0]       bit_cnt;
reg [11:0]      spi_init_delay;

reg [31:0]      cmd_dword;
reg [PAGE_WIDTH-1:0]  byte_cnt;
reg [7:0]       byte_wr;
reg [31:0]      dword_wr;

assign SCK = !spi_clk;
assign WP  = 1'b0;

always @(posedge spi_clk or posedge RST_I)
if (RST_I) begin
   cmd_state <= CMD_IDLE;
   spi_ack   <= 1'b0;
end else case(cmd_state)
CMD_IDLE:if(spi_req == 1'b0)
            spi_ack   <= 1'b0;
         else if(spi_req && ~spi_ack && spi_state == SPI_IDLE) begin
            spi_ack   <= 1'b0;
            if(wr_enb)
               cmd_state <= CMD_ENB;
            else
               cmd_state <= CMD_SPI;
         end
CMD_ENB :if(spi_state == SPI_END && bit_cnt == 0)
            cmd_state <= CMD_SPI;
CMD_SPI :if(spi_state == SPI_END) begin
            if(wr_enb) begin
               if(bit_cnt == 0)
                  cmd_state <= CMD_CHK;
               spi_ack   <= 1'b0;
            end else begin
               cmd_state <= CMD_IDLE;
               spi_ack   <= 1'b1;
            end
         end
CMD_CHK :if(spi_state == SPI_END && read_data[0] == 1'b0)begin
               cmd_state <= CMD_IDLE;
               spi_ack   <= 1'b1;
         end

default: begin
             cmd_state <= CMD_IDLE;
         end
endcase



always @(posedge spi_clk or posedge RST_I)
if (RST_I) begin
   spi_state <= SPI_INIT;
   cmd_dword <= 32'h000000;
   bit_cnt   <= 6'b000000;
   CS        <= 1'b1;
   SI        <= 1'b0;
   byte_cnt  <= 0;
   spi_init_delay  <= 12'h9c4;
end else case(spi_state)
SPI_INIT  :begin
              spi_init_delay <= spi_init_delay - 1;
              if(spi_init_delay == 12'h000)
                 spi_state <= SPI_IDLE;
           end
SPI_IDLE  :if(cmd_state == CMD_ENB) begin
              spi_state <= SPI_OPCODE;
              cmd_dword <= {spi_wrt_enb[6:0],25'h0000};
              bit_cnt   <= 7;
              CS        <= 1'b0;
              SI        <= spi_wrt_enb[7];
           end else if(cmd_state == CMD_CHK) begin
              spi_state <= SPI_OPCODE;
              cmd_dword <= {spi_read_stat[6:0],25'h0000};
              bit_cnt   <= 7;
              CS        <= 1'b0;
              SI        <= spi_read_stat[7];
           end else if(cmd_state == CMD_SPI) begin
              spi_state <= SPI_OPCODE;
              bit_cnt   <= (cmd_bytes<<3) - 1;
`ifdef PORT_ENABLE
              if(cmd_bytes > 4) begin
                 case(cmd_bytes)
                 5:begin
                      cmd_dword[31:24] <= {spi_cmd_ext[6:0],1'b0};
                      SI        <= spi_cmd_ext[7];
                   end
                 6:begin
                      cmd_dword[31:16] <= {spi_cmd_ext[14:0],1'b0};
                      SI        <= spi_cmd_ext[15];
                   end
                 7:begin
                      cmd_dword[31:8] <= {spi_cmd_ext[22:0],1'b0};
                      SI        <= spi_cmd_ext[23];
                   end
                 8:begin
                      cmd_dword <= {spi_cmd_ext[30:0],1'b0};
                      SI        <= spi_cmd_ext[31];
                   end
                 default:begin
                            cmd_dword <= spi_cmd<<1;
                            SI        <= spi_cmd[31];
                         end
                 endcase
              end else begin
                 cmd_dword <= spi_cmd<<1;
                 SI        <= spi_cmd[31];
              end
`else
              cmd_dword <= spi_cmd<<1;
              SI        <= spi_cmd[31];
`endif
              CS        <= 1'b0;
           end else
              CS        <= 1'b1;
SPI_OPCODE:if(bit_cnt == 0) begin
              if(cmd_state == CMD_CHK) begin
                 spi_state <= SPI_READ;
                 bit_cnt   <= 7;
                 byte_cnt  <= 0;
              end else if(cmd_state == CMD_ENB || byte_length == 0) begin
                 spi_state <= SPI_END;
                 CS        <= 1'b1;
                 bit_cnt   <= STOP_CYCLE;
              end else if(spi_wr) begin
                 spi_state <= SPI_WRITE;
                 bit_cnt   <= 7;
                 byte_cnt  <= byte_length - 1;
                 SI        <= dword_wr[31];
                 byte_wr   <= {dword_wr[30:24],1'b0};
              end else begin
                 if(fast_read)
                    spi_state <= SPI_WAIT;
                 else
                    spi_state <= SPI_READ;
                 bit_cnt   <= 7;
                 byte_cnt  <= byte_length - 1;
              end
           end else begin
              bit_cnt      <= bit_cnt - 1;
              SI           <= cmd_dword[31];
`ifdef PORT_ENABLE
              if(bit_cnt == 33)
                 cmd_dword    <= spi_cmd;
              else
`endif
                 cmd_dword    <= cmd_dword<<1;
           end
SPI_WAIT  :begin
              spi_state <= SPI_READ;
           end
SPI_READ  :if(bit_cnt == 0) begin
              if(byte_cnt == 0) begin
                 spi_state <= SPI_END;
                 CS        <= 1'b1;
                 bit_cnt   <= STOP_CYCLE;
              end else begin
                 bit_cnt  <= 7;
                 byte_cnt <= byte_cnt - 1;
              end
           end else begin
              bit_cnt  <= bit_cnt - 1;
           end
SPI_WRITE :if(bit_cnt == 0) begin
              SI        <= dword_wr[31];
              byte_wr   <= {dword_wr[30:24],1'b0};
              if(byte_cnt == 0) begin
                 spi_state <= SPI_END;
                 CS        <= 1'b1;
                 bit_cnt   <= STOP_CYCLE;
              end else begin
                 bit_cnt  <= 7;
                 byte_cnt <= byte_cnt - 1;
              end
           end else begin
              bit_cnt <= bit_cnt - 1;
              SI      <= byte_wr[7];
              byte_wr <= byte_wr<<1;
           end
SPI_END   :if(bit_cnt == 0) begin
              spi_state <= SPI_IDLE;
              CS      <= 1'b1;
           end else begin
              bit_cnt <= bit_cnt - 1;
              CS      <= 1'b1;
           end
default   :begin
              spi_state <= SPI_INIT;
              spi_init_delay  <= 12'h9c4;
              bit_cnt   <= 0;
           end
endcase


always @(posedge spi_clk or posedge RST_I)
if (RST_I)
   read_data <= 32'h00000000;
else if(spi_state == SPI_OPCODE)
   read_data <= 32'h00000000;
else if(spi_state == SPI_READ)
   read_data <= {read_data[30:0],SO};



`ifdef PAGE_PRG_BUF_ENA
reg   [BUF_WIDTH+1:0] page_wr_addr;

assign wb2spi_rd_addr = page_wr_addr>>2;

always @(posedge spi_clk or posedge RST_I)
if (RST_I)
   page_wr_addr <= 0;
else if(page_cmd && spi_wr) begin
   if(spi_state == SPI_OPCODE)
      page_wr_addr <= spi_cmd[BUF_WIDTH+1:0];
   else if(spi_state == SPI_WRITE && bit_cnt == 7)
      page_wr_addr <= page_wr_addr + 1;
end

always @(posedge spi_clk or posedge RST_I)
if (RST_I)
   dword_wr  <= 32'h00000000;
else if(spi_state == SPI_OPCODE)
   if(page_cmd)
      case(page_wr_addr[1:0])
      2'b00:dword_wr[31:24]  <= wb2spi_q[31:24];
      2'b01:dword_wr[31:24]  <= wb2spi_q[23:16];
      2'b10:dword_wr[31:24]  <= wb2spi_q[15:8];
      2'b11:dword_wr[31:24]  <= wb2spi_q[7:0];
      endcase
   else
      dword_wr  <= write_data;
else if(spi_state == SPI_WRITE && bit_cnt == 1) begin
   if(page_cmd)
      case(page_wr_addr[1:0])
      2'b00:dword_wr[31:24]  <= wb2spi_q[31:24];
      2'b01:dword_wr[31:24]  <= wb2spi_q[23:16];
      2'b10:dword_wr[31:24]  <= wb2spi_q[15:8];
      2'b11:dword_wr[31:24]  <= wb2spi_q[7:0];
      endcase
   else
      dword_wr  <= dword_wr << 8;
end
`else
always @(posedge spi_clk or posedge RST_I)
if (RST_I)
   dword_wr  <= 32'h00000000;
else if(spi_state == SPI_OPCODE)
   dword_wr  <= write_data;
else if(spi_state == SPI_WRITE && bit_cnt == 1)
   dword_wr  <= dword_wr<<8;
`endif

`ifdef PAGE_READ_BUF_ENA
reg  [BUF_WIDTH+1:0] page_rd_addr;

always @(posedge spi_clk or posedge RST_I)
if (RST_I) begin
   page_rd_addr <= 0;
   spi2wb_we    <= 1'b0;
   spi2wb_data  <= 32'h00000000;
end else if(page_cmd && !spi_wr) begin
   if(spi_state == SPI_OPCODE) begin
      page_rd_addr <= spi_cmd[BUF_WIDTH+1:0];
      spi2wb_we    <= 1'b0;
   end else if(spi_state == SPI_READ && bit_cnt == 0) begin
      page_rd_addr <= page_rd_addr + 1;
      if(page_rd_addr[1:0] == 2'b11) begin
         spi2wb_we    <= 1'b1;
         spi2wb_wr_addr <= page_rd_addr>>2;
         spi2wb_data  <= {read_data[30:0],SO};
      end else if(byte_cnt == 0) begin
         spi2wb_we    <= 1'b1;
         spi2wb_wr_addr <= page_rd_addr>>2;
         case(page_rd_addr[1:0])
         2'b00:spi2wb_data  <= {read_data[6:0],SO,24'h0000};
         2'b01:spi2wb_data  <= {read_data[14:0],SO,16'h0000};
         2'b10:spi2wb_data  <= {read_data[22:0],SO,8'h00};
         2'b11:spi2wb_data  <= {read_data[30:0],SO};
         default:spi2wb_data  <= {read_data[30:0],SO};
         endcase
      end else
         spi2wb_we    <= 1'b0;
   end else
      spi2wb_we    <= 1'b0;
end else
   spi2wb_we    <= 1'b0;
`endif

endmodule





