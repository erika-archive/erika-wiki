// ==============================================================================
//                            NOTICE
// This software is a version modified and distributed by Evidence srl 
// under the conditions of the 
// Lattice Semiconductor Corporation Open Source License Agreement.
// The heading below is taken verbatim from the original file.
// ==============================================================================

// =============================================================================
//                           COPYRIGHT NOTICE
// Copyright 2006 (c) Lattice Semiconductor Corporation
// ALL RIGHTS RESERVED
// This confidential and proprietary software may be used only as authorised by
// a licensing agreement from Lattice Semiconductor Corporation.
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement from
// Lattice Semiconductor Corporation.
//
// Lattice Semiconductor Corporation        TEL : 1-800-Lattice (USA and Canada)
// 5555 NE Moore Court                            408-826-6000 (other locations)
// Hillsboro, OR 97124                     web  : http://www.latticesemi.com/
// U.S.A                                   email: techsupport@latticesemi.com
// =============================================================================/
//                         FILE DETAILS
// Project          : SPI Flash Controller
// File             : wb_intf.v
// Title            : Wishbone Interface of SPI Flash Controller
// Version          : 3.0
//                  : Initial Version (replaces deprecated SPI Flash ROM v3.1)
// =============================================================================
module wb_intf
   #(parameter BUF_WIDTH     = 6,
     parameter PAGE_WIDTH    = 8,
     parameter SPI_READ      = 8'h03,
     parameter SPI_FAST_READ = 8'h0b,
     parameter SPI_BYTE_PRG  = 8'h02,
     parameter SPI_PAGE_PRG  = 8'h02,
     parameter SPI_BLK1_ERS  = 8'h20,
     parameter SPI_BLK2_ERS  = 8'h52,
     parameter SPI_BLK3_ERS  = 8'hd8,
     parameter SPI_CHIP_ERS  = 8'h60,
     parameter SPI_WRT_ENB   = 8'h06,
     parameter SPI_WRT_DISB  = 8'h04,
     parameter SPI_READ_STAT = 8'h05,
     parameter SPI_WRT_STAT  = 8'h01,
     parameter SPI_PWD_DOWN  = 8'hb9,
     parameter SPI_PWD_UP    = 8'hab,
     parameter SPI_DEV_ID    = 8'h9f)
(
// wishbone PORT A signals
input  wire [31:0]    S_ADR_I,
input  wire [31:0]    S_DAT_I,
input  wire           S_WE_I,
input  wire           S_STB_I,
input  wire           S_CYC_I,
input  wire [3:0]     S_SEL_I,
input  wire [2:0]     S_CTI_I,
input  wire [1:0]     S_BTE_I,
output reg  [31:0]    S_DAT_O,
output reg            S_ACK_O,
output wire           S_ERR_O,
output wire           S_RTY_O,

`ifdef PORT_ENABLE
// wishbone PORT B signals
input  wire [31:0]    C_ADR_I,
input  wire [31:0]    C_DAT_I,
input  wire           C_WE_I,
input  wire           C_STB_I,
input  wire           C_CYC_I,
input  wire [3:0]     C_SEL_I,
input  wire [2:0]     C_CTI_I,
input  wire [1:0]     C_BTE_I,
output reg  [31:0]    C_DAT_O,
output reg            C_ACK_O,
output wire           C_ERR_O,
output wire           C_RTY_O,
`endif

// command from wishbone to SPI flash signals
output reg  [31:0]    spi_cmd,         // command and address send to spi flash
output reg  [31:0]    spi_cmd_ext,     // extended high 4 bytes of command address send to spi flash
                                       // only used for arbitrary command
output reg  [3:0]     cmd_bytes,       // command and address byte numbers send to spi flash
output reg  [PAGE_WIDTH:0]     byte_length,     // data bytes after address command
output reg            page_cmd,        // page program or page read command
output reg            wr_enb,          // precede a write enable command
input  wire [31:0]    read_data,       // return data from spi flash
output reg  [31:0]    write_data,      // data write to spi flash
`ifdef PORT_ENABLE
output reg  [7:0]     spi_wrt_enb,     // spi write enable command byte
output reg  [7:0]     spi_read_stat,   // spi read status register command byte
output reg            fast_read,       // read command is fast read
`else
output wire [7:0]     spi_wrt_enb,     // spi write enable command byte
output wire [7:0]     spi_read_stat,   // spi read status register command byte
output wire           fast_read,       // read command is fast read
`endif
output reg            spi_wr,          // asserted when spi write command
output reg            spi_req,         // request a spi command, deasserted when detect a positive edge on spi_ack
input  wire           spi_ack,         // acknowledge a spi command, deasserted when the transaction is finished

`ifdef PAGE_PRG_BUF_ENA
output wire [BUF_WIDTH-1:0] wb2spi_wr_addr,
output reg  [31:0]          wb2spi_data,
output reg                  wb2spi_we,
`endif

`ifdef PAGE_READ_BUF_ENA
output wire [BUF_WIDTH-1:0] spi2wb_rd_addr,
input  wire [31:0]          spi2wb_q,
`endif

// system signals
input            CLK_I,
input            RST_I
);

// wishbone state machine
parameter WB_IDLE  = 2'b00;
parameter WB_PORTA = 2'b01;
parameter WB_PORTB = 2'b10;

parameter CTR_IDLE =1'b0;
parameter CTR_CMD  =1'b1;

reg  [1:0]          wb_state;
reg                 ctr_state;
reg  [PAGE_WIDTH:0] page_prg_length;
reg  [PAGE_WIDTH:0] page_rd_length;
reg                 ctrl_port_req;
reg  [31:0]         spi_cmd_arb;
reg  [3:0]          bytes_arb;
reg  [2:0]          length_arb;
reg  [31:0]         read_data_arb;


`ifdef PORT_ENABLE
// spi operation code byte
reg [7:0] spi_read;            // 8'h03   Slow read command
reg [7:0] spi_fast_read;       // 8'h0b   Fast read command
reg [7:0] spi_byte_prg;        // 8'h02   Byte program command
reg [7:0] spi_page_prg;        // 8'h02   Page program command
reg [7:0] spi_blk1_ers;        // 8'h20   Type1 block erase, 4K erase
reg [7:0] spi_blk2_ers;        // 8'h52   Type2 block erase, 32k erase
reg [7:0] spi_blk3_ers;        // 8'hD8   Type3 block erase, 64k erase
reg [7:0] spi_chip_ers;        // 8'h60   Chip erase command
//reg [7:0] spi_wrt_enb;         // 8'h06   Write enable command
reg [7:0] spi_wrt_disb;        // 8'h04   Write disable command
//reg [7:0] spi_read_stat;       // 8'h05   Read status register
reg [7:0] spi_wrt_stat;        // 8'h10   Write status register
reg [7:0] spi_pwd_down;        // 8'hB9   Deep power down
reg [7:0] spi_pwd_up;          // 8'hAB   Resume from deep power down
reg [7:0] spi_dev_id;          // 8'h9F   Read manufacturer and device ID
`else
wire [7:0] spi_read;
wire [7:0] spi_fast_read;
wire [7:0] spi_page_prg;
//wire [7:0] spi_wrt_enb;
//wire [7:0] spi_read_stat;
`endif

assign S_ERR_O = 1'b0;
assign S_RTY_O = 1'b0;
`ifdef PORT_ENABLE
assign C_ERR_O = 1'b0;
assign C_RTY_O = 1'b0;
`endif

`ifdef PAGE_PRG_BUF_ENA
assign wb2spi_wr_addr = C_ADR_I>>2;
`endif
`ifdef PAGE_READ_BUF_ENA
assign spi2wb_rd_addr = C_ADR_I>>2;
`endif



always @(posedge CLK_I or posedge RST_I)
if(RST_I) begin
   wb_state      <= WB_IDLE;
   spi_cmd       <= 32'h00000000;
   cmd_bytes     <= 0;
   byte_length   <= 4;
   page_cmd      <= 1'b0;
   wr_enb        <= 1'b0;
   write_data    <= 32'h00000000;
   spi_wr        <= 1'b0;
   spi_req       <= 1'b0;
   S_ACK_O       <= 1'b0;
   S_DAT_O       <= 32'h00000000;
end else case(wb_state)
WB_IDLE :if(!spi_ack) begin
            if(S_STB_I && S_CYC_I && ~S_ACK_O) begin
               if(S_WE_I) begin
                  spi_cmd[31:2]<= {spi_page_prg,S_ADR_I[23:2]};
                  spi_wr        <= 1'b1;
                  wr_enb        <= 1'b1;
                  S_ACK_O       <= 1'b1;
               end else begin
                  if(fast_read)
                     spi_cmd[31:2] <= {spi_fast_read,S_ADR_I[23:2]};
                  else
                     spi_cmd[31:2] <= {spi_read,S_ADR_I[23:2]};
                  spi_wr        <= 1'b0;
                  wr_enb        <= 1'b0;
                  S_ACK_O       <= 1'b0;
               end
               case(S_SEL_I)
               4'b0001:begin
                          spi_cmd[1:0]  <= 2'b11;
                          byte_length   <= 1;
                          write_data    <= {S_DAT_I[7:0],24'h000000};
                       end
               4'b0010:begin
                          spi_cmd[1:0]  <= 2'b10;
                          byte_length   <= 1;
                          write_data    <= {S_DAT_I[15:8],24'h000000};
                       end
               4'b0100:begin
                          spi_cmd[1:0]  <= 2'b01;
                          byte_length   <= 1;
                          write_data    <= {S_DAT_I[23:16],24'h000000};
                       end
               4'b1000:begin
                          spi_cmd[1:0]  <= 2'b00;
                          byte_length   <= 1;
                          write_data    <= {S_DAT_I[31:24],24'h000000};
                       end
               4'b0011:begin
                          spi_cmd[1:0]  <= 2'b10;
                          byte_length   <= 2;
                          write_data    <= {S_DAT_I[15:0],16'h0000};
                       end
               4'b0110:begin
                          spi_cmd[1:0]  <= 2'b01;
                          byte_length   <= 2;
                          write_data    <= {S_DAT_I[23:8],16'h0000};
                       end
               4'b1100:begin
                          spi_cmd[1:0]  <= 2'b00;
                          byte_length   <= 2;
                          write_data    <= {S_DAT_I[31:16],24'h0000};
                       end
               4'b0111:begin
                          spi_cmd[1:0]  <= 2'b01;
                          byte_length   <= 3;
                          write_data    <= {S_DAT_I[23:0],8'h00};
                       end
               4'b1110:begin
                          spi_cmd[1:0]  <= 2'b00;
                          byte_length   <= 3;
                          write_data    <= {S_DAT_I[31:8],8'h00};
                       end
               4'b1111:begin
                          spi_cmd[1:0]  <= 2'b00;
                          byte_length   <= 4;
                          write_data    <= S_DAT_I;
                       end
               default:begin
                          spi_cmd[1:0]  <= 2'b00;
                          byte_length   <= 4;
                          write_data    <= S_DAT_I;
                       end
               endcase
               cmd_bytes     <= 4;
               page_cmd      <= 1'b0;
               spi_req       <= 1'b1;
               wb_state      <= WB_PORTA;
`ifdef PORT_ENABLE
            end else if(ctrl_port_req) begin
               S_ACK_O       <= 1'b0;
               spi_req       <= 1'b1;
               wb_state      <= WB_PORTB;
               case({C_ADR_I[6:2],2'b00})
`ifdef PAGE_PRG_BUF_ENA
               // 000h Write Page program command. B_DAT_I[23:0] defined page program command address.
               7'h00:begin
                        spi_cmd       <= {spi_byte_prg,C_DAT_I[23:0]};
                        cmd_bytes     <= 4;
                        byte_length   <= page_prg_length;
                        page_cmd      <= 1'b1;
                        wr_enb        <= 1'b1;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b1;
                     end
`endif
`ifdef PAGE_READ_BUF_ENA
               // 004h Write Page read command. C_DAT_I[23:0] defined page read command address.
               7'h04:begin
                        spi_cmd       <= {spi_read,C_DAT_I[23:0]};
                        cmd_bytes     <= 4;
                        byte_length   <= page_rd_length;
                        page_cmd      <= 1'b1;
                        wr_enb        <= 1'b0;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b0;
                     end
`endif
               // 008h Write Type1 block erase, 4K erase. C_DAT_I[23:0] defined erase address
               7'h08:begin
                        spi_cmd       <= {spi_blk1_ers,C_DAT_I[23:0]};
                        cmd_bytes     <= 4;
                        byte_length   <= 0;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b1;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b1;
                     end
               // 00ch Write Type2 block erase, 32k erase. C_DAT_I[23:0] defined erase address
               7'h0c:begin
                        spi_cmd       <= {spi_blk2_ers,C_DAT_I[23:0]};
                        cmd_bytes     <= 4;
                        byte_length   <= 0;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b1;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b1;
                     end
               // 010h Write Type3 block erase, 64k erase. C_DAT_I[23:0] defined erase address
               7'h10:begin
                        spi_cmd       <= {spi_blk3_ers,C_DAT_I[23:0]};
                        cmd_bytes     <= 4;
                        byte_length   <= 0;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b1;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b1;
                     end
               // 014h Write Chip erase command. C_DAT_I is ignored.
               7'h14:begin
                        spi_cmd       <= {spi_chip_ers,24'h000000};
                        cmd_bytes     <= 1;
                        byte_length   <= 0;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b1;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b1;
                     end
               // 018h Write Write enable command. C_DAT_I is ignored
               7'h18:begin
                        spi_cmd       <= {spi_wrt_enb,24'h000000};
                        cmd_bytes     <= 1;
                        byte_length   <= 0;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b0;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b1;
                     end
               // 01ch Write Write disable command. C_DAT_I is ignored.
               7'h1c:begin
                        spi_cmd       <= {spi_wrt_disb,24'h000000};
                        cmd_bytes     <= 1;
                        byte_length   <= 0;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b0;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b1;
                     end
               // 020h Read Read status register. C_DAT_O[7:0] is status register data.
               7'h20:begin
                        spi_cmd       <= {spi_read_stat,24'h000000};
                        cmd_bytes     <= 1;
                        byte_length   <= 1;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b0;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b0;
                     end
               // 024h Write Write status register. C_DAT_I[7:0] is data write to status register.
               7'h24:begin
                        spi_cmd       <= {spi_wrt_stat,24'h000000};
                        cmd_bytes     <= 1;
                        byte_length   <= 1;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b1;
                        write_data    <= {C_DAT_I[7:0],24'h000000};
                        spi_wr        <= 1'b1;
                     end
               // 028h Write Deep power down. C_DAT_I is ignored.
               7'h28:begin
                        spi_cmd       <= {spi_pwd_down,24'h000000};
                        cmd_bytes     <= 1;
                        byte_length   <= 0;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b0;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b1;
                     end
               // 02ch Write Resume from deep power down. C_DAT_I is ignored
               7'h2c:begin
                        spi_cmd       <= {spi_pwd_up,24'h000000};
                        cmd_bytes     <= 1;
                        byte_length   <= 0;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b0;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b1;
                     end
               // 030h Read Read manufacturer and device ID. C_DAT_O[31:0] is ID data.
               7'h30:begin
                        spi_cmd       <= {spi_dev_id,24'h000000};
                        cmd_bytes     <= 1;
                        byte_length   <= 4;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b0;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b0;
                     end
               // issue an arbitrary command
               7'h54:begin
                        spi_cmd       <= spi_cmd_arb;
                        cmd_bytes     <= bytes_arb;
                        byte_length   <= length_arb;
                        page_cmd      <= 1'b0;
                        wr_enb        <= C_DAT_I[1];
                        write_data    <= 32'h00000000;
                        spi_wr        <= length_arb == 0 ? 1'b1 : 1'b0;
                     end
               // select read status register as default command
               default:begin
                        spi_cmd       <= {spi_read_stat,24'h000000};
                        cmd_bytes     <= 1;
                        byte_length   <= 1;
                        page_cmd      <= 1'b0;
                        wr_enb        <= 1'b0;
                        write_data    <= 32'h00000000;
                        spi_wr        <= 1'b0;
                     end
               endcase
`endif                             // end `ifdef PORT_ENABLE
            end else
               S_ACK_O       <= 1'b0;
         end else
            S_ACK_O       <= 1'b0;
WB_PORTA:if(spi_ack) begin
            spi_req  <= 1'b0;
            if(~spi_wr) begin
               S_ACK_O       <= 1'b1;
               case(S_SEL_I[3:0])
               4'b0001:S_DAT_O <= {24'h000000,read_data[7:0]};
               4'b0010:S_DAT_O <= {16'h0000,read_data[7:0],8'h00};
               4'b0100:S_DAT_O <= {8'h00,read_data[7:0],16'h0000};
               4'b1000:S_DAT_O <= {read_data[7:0],24'h000000};
               4'b0011:S_DAT_O <= {16'h0000,read_data[15:0]};
               4'b0110:S_DAT_O <= {8'h00,read_data[15:0],8'h00};
               4'b1100:S_DAT_O <= {read_data[15:0],16'h0000};
               4'b0111:S_DAT_O <= {8'h00,read_data[23:0]};
               4'b1110:S_DAT_O <= {read_data[23:0],8'h00};
               4'b1111:S_DAT_O <= read_data;
               default:S_DAT_O <= read_data;
               endcase
            end else
               S_ACK_O       <= 1'b0;
               wb_state      <= WB_IDLE;
         end else
            S_ACK_O       <= 1'b0;
WB_PORTB:if(spi_ack) begin
            spi_req  <= 1'b0;
            wb_state <= WB_IDLE;
         end
default :begin
            spi_req  <= 1'b0;
            wb_state <= WB_IDLE;
         end
endcase  // end of wishbone state


`ifdef PORT_ENABLE
always @(posedge CLK_I or posedge RST_I)
if(RST_I) begin
   ctrl_port_req   <= 1'b0;
   ctr_state       <= CTR_IDLE;
   C_DAT_O         <= 32'h000000;
   C_ACK_O         <= 1'b0;
`ifdef PAGE_PRG_BUF_ENA
   wb2spi_data     <= 32'h000000;
   wb2spi_we       <= 1'b0;
`endif
   spi_cmd_arb     <= 32'h00000000;
   spi_cmd_ext     <= 32'h00000000;
   bytes_arb       <= 4'h0;
   length_arb      <= 3'b000;
   read_data_arb   <= 32'h00000000;
   fast_read       <= 1'b0;
   page_prg_length <= 0;
   page_rd_length  <= 0;
   spi_read        <= SPI_READ;        //8'h03;
   spi_fast_read   <= SPI_FAST_READ;   //8'h0b;
   spi_byte_prg    <= SPI_BYTE_PRG;    //8'h02;
   spi_page_prg    <= SPI_PAGE_PRG;    //8'h02;
   spi_blk1_ers    <= SPI_BLK1_ERS;    //8'h20;
   spi_blk2_ers    <= SPI_BLK2_ERS;    //8'h52;
   spi_blk3_ers    <= SPI_BLK3_ERS;    //8'hD8;
   spi_chip_ers    <= SPI_CHIP_ERS;    //8'h60;
   spi_wrt_enb     <= SPI_WRT_ENB;     //8'h06;
   spi_wrt_disb    <= SPI_WRT_DISB;    //8'h04;
   spi_read_stat   <= SPI_READ_STAT;   //8'h05;
   spi_wrt_stat    <= SPI_WRT_STAT;    //8'h10;
   spi_pwd_down    <= SPI_PWD_DOWN;    //8'hB9;
   spi_pwd_up      <= SPI_PWD_UP;      //8'hAB;
   spi_dev_id	     <= SPI_DEV_ID;	     //8'h9F;
end else case(ctr_state)
CTR_IDLE:if(C_STB_I && C_CYC_I && ~C_ACK_O) begin
            if((C_ADR_I[10:0] == 11'h054 && C_DAT_I[0] == 1'b1)          // h054 arbitrary command
               || C_ADR_I[10:6] == 5'b00000) begin                       // h000~h03f spi command
               if(wb_state == WB_IDLE) begin
                  ctrl_port_req <= 1'b1;
                  ctr_state     <= CTR_CMD;
                  C_ACK_O       <= 1'b0;
               end
            end else if(C_ADR_I[10:5] == 6'b000010) begin           // h040~h05c arbitrary command config space
               C_ACK_O <= 1'b1;
               case({4'b0010,C_ADR_I[4:2],2'b00})
               //040h	RW	Arbitrary command to SPI flash. B_DAT_I defined given command,
               // if the command is larger than 4 bytes, the higher bytes put on address 044h.
               9'h040:if(C_WE_I)
                         spi_cmd_arb <= C_DAT_I;
                      else
                         C_DAT_O     <= spi_cmd_arb;
               //044h	RW	Arbitrary command, higher 4 bytes
               9'h044:if(C_WE_I)
                         spi_cmd_ext <= C_DAT_I;
                      else
                         C_DAT_O     <= spi_cmd_ext;
               //048h	RW	B_DAT_I[7:0] is length of command
               9'h048:if(C_WE_I)
                         bytes_arb <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= bytes_arb;
               //04ch	RW	Length of return data. If B_DAT_I is 0, it means that the command is no return data.
               9'h04c:if(C_WE_I)
                         length_arb <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= length_arb;
               //050h	Read	Return data from SPI flash
               9'h050:C_DAT_O     <= read_data_arb;
               endcase
            end else if(C_ADR_I[10:8] == 3'b001) begin              // h100~h1fc config command
               C_ACK_O <= 1'b1;
               case({1'b1,C_ADR_I[7:2],2'b00})
               // 100h	RW	Fast read or low frequency read command, ��1�� of B_DAT_I bit 0 define fast read,
               //��0�� of B_DAT_I bit 0 define low frequency read command
               9'h100:if(C_WE_I)
                         fast_read <= C_DAT_I[0];
                      else
                         C_DAT_O     <= fast_read;
               // 104h	RW	Page program length, B_DAT_I[15:0] defined the page program length. Default value is page size.
               9'h104:if(C_WE_I)
                         page_prg_length <= C_DAT_I[15:0];
                      else
                         C_DAT_O     <= page_prg_length;
               // 108h	RW	Page read command length, B_DAT_I[15:0] defined the page read length.. Default value is page size.
               9'h108:if(C_WE_I)
                         page_rd_length <= C_DAT_I[15:0];
                      else
                         C_DAT_O     <= page_rd_length;
               // 180h	RW	Config Slow read command
               9'h180:if(C_WE_I)
                         spi_read <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_read;
               // 184h	RW	Config Fast read command
               9'h184:if(C_WE_I)
                         spi_fast_read <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_fast_read;
               // 188h	RW	Config Byte program command
               9'h188:if(C_WE_I)
                         spi_byte_prg <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_byte_prg;
               // 18ch	RW	Config Page program command
               9'h18c:if(C_WE_I)
                         spi_page_prg <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_page_prg;
               // 190h	RW	Config Type1 block erase command, 4K erase
               9'h190:if(C_WE_I)
                         spi_blk1_ers <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_blk1_ers;
               // 194h	RW	Config Type2 block erase command, 32k erase
               9'h194:if(C_WE_I)
                         spi_blk2_ers <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_blk2_ers;
               // 198h	RW	Config Type3 block erase command, 64k erase
               9'h198:if(C_WE_I)
                         spi_blk3_ers <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_blk3_ers;
               // 19ah	RW	Config Chip erase command
               9'h19a:if(C_WE_I)
                         spi_chip_ers <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_chip_ers;
               // 19ch	RW	Config Write enable command
               9'h19c:if(C_WE_I)
                         spi_wrt_enb <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_wrt_enb;
               // 1a0h	RW	Config Write disable command
               9'h1a0:if(C_WE_I)
                         spi_wrt_disb <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_wrt_disb;
               // 1a4h	RW	Config Read status register command
               9'h1a4:if(C_WE_I)
                         spi_read_stat <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_read_stat;
               // 1a8h	RW	Config Write status register command
               9'h1a8:if(C_WE_I)
                         spi_wrt_stat <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_wrt_stat;
               // 1ach	RW	Config Deep power down command
               9'h1ac:if(C_WE_I)
                         spi_pwd_down <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_pwd_down;
               // 1b0h	RW	Config Resume from deep power down command
               9'h1b0:if(C_WE_I)
                         spi_pwd_up <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_pwd_up;
               // 1b4h	RW	Config Read manufacturer and device ID command
               9'h1b4:if(C_WE_I)
                         spi_dev_id <= C_DAT_I[7:0];
                      else
                         C_DAT_O     <= spi_dev_id;
               endcase
`ifdef PAGE_PRG_BUF_ENA
            end else if(C_ADR_I[10:9] == 2'b01)  begin              // h200~h3fc page programe buffer space
               wb2spi_data <= C_DAT_I;
               wb2spi_we   <= 1'b1;
               C_ACK_O     <= 1'b1;
`endif
`ifdef PAGE_READ_BUF_ENA
            end else if(C_ADR_I[10:9] == 2'b10)  begin              // h400~h4fc page read buffer space
               C_DAT_O     <= spi2wb_q;
               C_ACK_O     <= 1'b1;
`endif
            end
         end else begin
            C_ACK_O         <= 1'b0;
            ctrl_port_req   <= 1'b0;
            ctr_state       <= CTR_IDLE;
`ifdef PAGE_PRG_BUF_ENA
            wb2spi_we       <= 1'b0;
`endif
         end
CTR_CMD :if(wb_state == WB_PORTB) begin
            ctrl_port_req <= 1'b0;
            if(spi_wr) begin                  // write control command
               C_ACK_O       <= 1'b1;
               ctr_state     <= CTR_IDLE;
            end else if(spi_ack) begin        // read control command and finish transferer
               if(C_ADR_I[10:0] == 11'h054)   // arbitrary read command
                  read_data_arb <= read_data;
               C_ACK_O       <= 1'b1;
               C_DAT_O       <= read_data;
               ctr_state     <= CTR_IDLE;
            end else
               C_ACK_O       <= 1'b0;
         end
endcase  // end of wishbone control port state
`else
assign fast_read     = 1'b0;
assign spi_read      = SPI_READ;        //8'h03;
assign spi_fast_read = SPI_FAST_READ;   //8'h0b;
assign spi_page_prg  = SPI_PAGE_PRG;    //8'h02;
assign spi_wrt_enb   = SPI_WRT_ENB;     //8'h06
assign spi_read_stat = SPI_READ_STAT;   //8'h05

`endif                             // end `ifdef PORT_ENABLE

endmodule
