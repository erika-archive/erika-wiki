#!/usr/bin/python
#
# * Copyright (C) 2002-2011  Evidence Srl
# This software is released under the GPLv2+Linking Exception License.
#
# You can redistribute it and/or modify it under the terms of the 
# GNU General Public License version 2 as published by the 
# Free Software Foundation (with a special exception described below).
#
# As a special exception, the copyright holders of this library give you
# permission to link this code with independent modules to produce an
# executable, regardless of the license terms of these independent
# modules, and to copy and distribute the resulting executable under
# terms of your choice, provided that you also meet, for each linked
# independent module, the terms and conditions of the license of that
# module.  An independent module is a module which is not derived from
# or based on this library.  If you modify this code, you may extend
# this exception to your version of the code, but you are not
# obligated to do so.  If you do not wish to do so, delete this
# exception statement from your version.
#
# This software is distributed in the hope that it will be
# useful, but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License version 2 for more details.
#
# You should have received a copy of the GNU General Public License
# version 2 along with this software; if not, write to the
# Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301 USA.
#

import os
import pprint
import re
import serial
import struct
import subprocess
import sys

global serport
global old_format
global be_verbose
global be_quiet

MAGIC_ACK =     0xb4
MAGIC_NACK =    0x1d
MAGIC_START =   0x4119b964
MAGIC_END =     0x7b40
FLASH_RECORD_MAGIC = 0x0ef00d01

RUN_CMD         = 0
CHECK_MEM_CMD   = 1
WRITE_MEM_CMD   = 2
WRITE_FLASH_CMD = 3
CHECK_FLASH_CMD = 4
ERASE_FLASH_CMD = 5
LOAD_FLASH_CMD  = 6

FLASH_START = 0
FLASH_REC_SIZE = 16

def checksum_string_old(strdata):
    slen = len(strdata) / 2
    data = struct.unpack('>%dH' % slen, strdata)
    chksum = 0L # This works even if len(str) > 2^17
    for d in data:
        chksum = chksum + d
    while chksum > 0xffff:
        chksum = (chksum & 0xffff) + (chksum >> 16)
    return chksum


def checksum_string(strdata):
    if old_format:
        return checksum_string_old(strdata)
    slen = len(strdata)
    data = struct.unpack('>%dB' % slen, strdata)
    chksum = 0L
    for d in data:
        chksum = (chksum >> 1) + ((chksum & 1) << 15)
        chksum += d
        chksum = (chksum & 0xffffL)
    return chksum


# Write `strdata' to the serial port
def transmit(strdata):
    serport.timeout = None
    serport.write(strdata)
    serport.flush()
    return


# Return a byte read from the serial port.  If no data is read within
# `timeout_ms', -1 is returned instead.
def get_byte_timeout(timeout_ms):
    serport.timeout = timeout_ms / 1000.0
    data = serport.read(1)
    if len(data) == 0:
        ret = -1
    else:
        ret = struct.unpack('B', data)[0]
    return ret


# Resynchronize with the bootloader
def resync():
    sync_word = struct.pack('>I', MAGIC_START)
    if not be_quiet:
        print 'Syncing...'
    while 1:
        ack = get_byte_timeout(20)
        if ack == MAGIC_ACK:
            break 
        elif ack == -1:
            if not be_quiet:
                sys.stdout.write('.')
                sys.stdout.flush()
            transmit(sync_word)
        else:
            # Ignore other characters
            pass
    if not be_quiet:
        print "Protocol synchronized"
    while 1:
        c = get_byte_timeout(1)
        if c == -1:
            break
    return


# Wait for an ACK from the serial port.  If a 10-second timeout expires or
# a NACK is received, try to resynchronize with the bootloader.  Return
# `True' if an ACK has been received, `False' otherwise.
def get_ack_or_resync():
    ack = get_byte_timeout(10000)
    if -1 == ack:
        print "ERROR: Time out"
    elif MAGIC_NACK == ack:
        print "ERROR: Got a NACK"
    elif MAGIC_ACK != ack:
        print "ERROR: Received a spurious character"
    if ack != MAGIC_ACK:
        resync()
        ret = False
    else:
        ret = True
    return ret

    
# Return a string of `size' bytes read from file `f' at offset `offset'
def load_segment(f, offset, size):
    f.seek(offset, os.SEEK_SET)
    newpos = f.tell()
    if newpos != offset:
        raise Exception('Error while seeking file: reached %d instead of %d' %
                        (newpos, offset))
    data = f.read(size)
    if len(data) != size:
        raise Exception('Error while reading: got %d bytes instead of %d' %
                        (len(data), size))
    if be_verbose:
        print "Loaded %d bytes from file at offset %d" % (size, offset)
        print " %02x %02x %02x %02x ... %02x %02x %02x %02x" % \
              (struct.unpack('4B', data[0:4])[0:4] \
               + struct.unpack('4B', data[size-4:size])[0:4])
    return data


# Send `strdata' (a string), to be loaded in RAM at address `addr'
def send_segment(addr, strdata):
    datalen = len(strdata)
    if datalen > 0x10000:
        raise Exception("Data is too long: %d bytes" % datalen)
    if be_verbose:
        print "Sending %d bytes to 0x%08x..." % (datalen, addr)
    cmd = WRITE_MEM_CMD
    header = struct.pack('>5I', cmd, addr, (~addr & 0xffffffff), \
                         datalen, (~datalen & 0xffffffff))
    chksum = struct.pack('>H', checksum_string(strdata))
    trailer = struct.pack('>H', MAGIC_END)
    done = False
    while not done:
        transmit(header)
        transmit(strdata)
        transmit(chksum)
        transmit(trailer)
        done = get_ack_or_resync()
    return


# Send a command to copy `size' bytes from RAM at address `addr' to Flash
# at `flash_offset' bytes from the beginning. `chksum' is the checksum of
# the data to be copied.
def send_write_flash_cmd(addr, size, flash_offset, chksum):
    if not be_quiet:
        print "Copying %d bytes to Flash at 0x%08x..." % (size, flash_offset)
    cmd = WRITE_FLASH_CMD
    header = struct.pack('>7I', cmd, addr, (~addr & 0xffffffff), \
                         size, (~size & 0xffffffff), \
                         flash_offset, (~flash_offset & 0xffffffff))
    chksum_str = struct.pack('>H', chksum)
    trailer = struct.pack('>H', MAGIC_END)
    transmit(header)
    transmit(chksum_str)
    transmit(trailer)
    return


# Return the Flash header for a segment of `size' bytes to be loaded in RAM
# at `addr', and whose data checksum is `data_checksum'
def build_flash_header(addr, size, data_checksum):
    minihead = struct.pack('>3I', FLASH_RECORD_MAGIC, addr, size)
    if old_format:
        header = minihead + struct.pack('>2H', 0, data_checksum)
        chksum = checksum_string(header)
        chksum = ~chksum & 0xffff
        header = minihead + struct.pack('>2H', 0, chksum)
    else:
        chksum = checksum_string(minihead)
        header = minihead + struct.pack('>2H', chksum, data_checksum)
    return header


# Build and send the header of a Flash record for the segment of `size'
# bytes in file `f' at `offset'. `addr' is the RAM address where the
# segment must be loaded, and `flash_offset' is the offset from the Flash
# beginning where the record must be written
def send_flash_header(f, addr, offset, size, flash_offset):
    if be_verbose:
        print "Sending segment header..."
    data_chksum = checksum_string(load_segment(f, offset, size))
    header = build_flash_header(addr, size, data_chksum)
    rec_chksum = checksum_string(header)
    done = False
    while not done:
        send_segment(addr, header)
        send_write_flash_cmd(addr, FLASH_REC_SIZE, flash_offset, rec_chksum)
        done = get_ack_or_resync()
    return (FLASH_REC_SIZE, data_chksum)


# Return the number of bytes needed to store the given list of segments in
# Flash (the overhead for metadata is included)
def compute_flash_size(segments):
    totsize = 0
    for s in segments:
        totsize += s[2] + FLASH_REC_SIZE
    return totsize


# Send the command to erase `size' bytes of Flash at `offset' bytes from
# the beginning.  BUG: Currently, the bootloader erases the whole Flash.
def send_erase_flash_cmd(offset, size):
    header = struct.pack('>5I', ERASE_FLASH_CMD, \
                         offset, (~offset & 0xffffffff), \
                         size, (~size & 0xffffffff))
    done = False
    while not done:
        if not be_quiet:
            print "Sending ERASE command..."
        transmit(header)
        done = get_ack_or_resync()
    return
    

# Send a segment read from file `f' at offset `offset' of `size' bytes, to
# be loaded at RAM address `addr'.  `size' must be no more than 65536 (as
# data is not fragmented).
def send_short_file_segment(f, addr, offset, size):
    strdata = load_segment(f, offset, size)
    send_segment(addr, strdata)
    return

    
# Send a segment read from file `f' at offset `offset' of `size' bytes, to
# be loaded at RAM address `addr'.  Data is fragmented if needed.
def send_file_segment_data(f, addr, offset, size):
    MAX_CHUNK_LEN = 0x10000
    remaining = size
    curr_addr = addr
    while remaining > MAX_CHUNK_LEN:
        send_short_file_segment(f, curr_addr, offset, MAX_CHUNK_LEN)
        curr_addr += MAX_CHUNK_LEN
        offset += MAX_CHUNK_LEN
        remaining -= MAX_CHUNK_LEN
    if (remaining > 0):
        send_short_file_segment(f, curr_addr, offset, remaining)
    return


# Send a segment read from file `f' at offset `offset' of `size' bytes, to
# be loaded at RAM address `addr'.  If `isflash' is True, the segment is
# saved to Flash at `flash_offset' bytes from the Flash beginning.
def send_file_segment(f, addr, offset, size, isflash, flash_offset = 0):
    if size == 0:
        if not be_quiet:
            print "Skipping empty segment (located at 0x%08x)" % (addr)
        if isflash:
            return 0
        else:
            return None
    if isflash:
        flashstr = ", flash 0x%08x" % flash_offset
    else:
        flashstr = ""
    if not be_quiet:
        print "Writing a segment (%d bytes at %d) to 0x%08x%s" % \
              (size, offset, addr, flashstr)
    if isflash:
        (flash_offset, chksum) = \
                       send_flash_header(f, addr, offset, size, flash_offset)
        done = False
        while not done:
            send_file_segment_data(f, addr, offset, size)
            send_write_flash_cmd(addr, size, flash_offset, chksum)
            done = get_ack_or_resync()
        return flash_offset + size
    else:
        send_file_segment_data(f, addr, offset, size)
        return None


# Send either a RUN or a LOAD_FLASH command (depending on `isflash')
def send_run_cmd(addr, isflash):
    if isflash:
        cmd = LOAD_FLASH_CMD
        cmdstr = "LOAD_FLASH"
    else:
        cmd = RUN_CMD
        cmdstr = "RUN"
    header = struct.pack('>3I', cmd, addr, (~addr & 0xffffffff))
    done = False
    while not done:
        if not be_quiet:
            print "Sending %s at 0x%08x command..." % (cmdstr, addr)
        transmit(header)
        done = get_ack_or_resync()
    return


# Parse the given ELF file and return a list of segments to load, where a
# segment is a tuple (address, offset, size).  The first segment is the one
# where the bootloader jumps to when launching the program.
def read_elf_info(elfname):
    ep_re = re.compile('[ \t]*Entry point[ \t]+([0-9a-fA-Fx]+)')
    h_re = re.compile('[ \t]*LOAD[ \t]+([0-9a-fA-Fx]+)[ \t]+[0-9a-fA-Fx]+[ \t]+([0-9a-fA-Fx]+)[ \t]+([0-9a-fA-Fx]+)[ \t]+[0-9a-fA-Fx]+')
    cmd = ("readelf", "-W", "-l", elfname)
    # close_fds is set to False for compatibility with Windows
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, close_fds=False)
    except OSError:
        try:
            cmd = ("lm32-elf-readelf",) + cmd[1:]
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, \
                                    close_fds=False)
        except OSError:
            raise Exception("Cannot execute readelf nor lm32-elf-readelf")
    epoint = -1
    segments = []
    for l in proc.stdout:
        m = ep_re.match(l)
        if m:
            epoint = int(m.groups()[0],0)
        m = h_re.match(l)
        if m:
            addr = int(m.groups()[1],0)
            offs = int(m.groups()[0],0)
            size = int(m.groups()[2],0)
            if epoint == addr:
                # This must be the first entry in `segments'
                segments.insert(0,(addr, offs, size))
            else:
                segments.append((addr, offs, size))
    proc.wait()
    ret = proc.returncode
    if ret != 0:
        raise Exception("Cannot parse given file")
    return segments


def usage_then_exit():
    print "Usage: send_prog [--flash] [--verbose] [--quiet] [--old] <serial_device> <elf_file> [<addr> <offset> <len>]"
    sys.exit(2)

#
# Main
#

be_quiet = False
be_verbose = False
deploy_flash = False
old_format = False
firstarg = 1
while firstarg < len(sys.argv):
    if sys.argv[firstarg] == "--flash" or sys.argv[firstarg] == "-flash":
        deploy_flash = True
    elif sys.argv[firstarg] == "--old":
        old_format = True
    elif sys.argv[firstarg] == "--verbose":
        be_verbose = True
    elif sys.argv[firstarg] == "--quiet":
        be_quiet = True
    else:
        break
    firstarg += 1
lenarg = len(sys.argv) - firstarg + 1
if lenarg != 3 and lenarg != 6:
    usage_then_exit()

try:
    ttysname = sys.argv[firstarg]
    efile = sys.argv[firstarg + 1]
    if len(sys.argv) > firstarg + 2:
        addr = int(sys.argv[firstarg + 2],0)
        foffset = int(sys.argv[firstarg + 3],0)
        flen = int(sys.argv[firstarg + 4],0)
        segments = ((addr, foffset, flen),)
    else:
        segments = read_elf_info(efile)
        if len(segments) == 0:
            raise Exception("No segment found in given file")

    f = open(efile, 'rb')
    serport = serial.Serial(ttysname, 115200, serial.EIGHTBITS, \
                            serial.PARITY_NONE, serial.STOPBITS_ONE)
    if be_verbose:
        print "Opened serial port: %s\n" % serport.portstr
    resync()
    flash_addr = FLASH_START
    if deploy_flash:
        flash_size = compute_flash_size(segments)
        send_erase_flash_cmd(flash_addr, flash_size)
    i = 0
    for s in segments:
        vaddr = s[0]
        offset = s[1]
        size = s[2]
        if deploy_flash:
            w = send_file_segment(f, vaddr, offset, size, True, flash_addr)
            flash_addr += w
        else:
            send_file_segment(f, vaddr, offset, size, False)
        i += 1
    if deploy_flash:
        send_run_cmd(FLASH_START, True)
    else:
        send_run_cmd(segments[0][0], False)
except Exception, e:
    print >>sys.stderr, "Failed: %s\n" % str(e)
    exit(1)
