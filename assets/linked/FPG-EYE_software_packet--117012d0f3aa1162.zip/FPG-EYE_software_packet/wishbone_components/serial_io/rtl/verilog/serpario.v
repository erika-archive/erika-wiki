/*
 * Copyright (C) 2011 Evidence Srl.  All rights reserved.
 *
 * This is free software; you can redistribute it
 * and/or modify it under the terms of the GNU General Public License
 * version 2 as published by the Free Software Foundation, 
 * (with a special exception described below).
 *
 * Linking this code statically or dynamically with other modules is
 * making a combined work based on this code.  Thus, the terms and
 * conditions of the GNU General Public License cover the whole
 * combination.
 *
 * As a special exception, the copyright holders of this library give you
 * permission to link this code with independent modules to produce an
 * executable, regardless of the license terms of these independent
 * modules, and to copy and distribute the resulting executable under
 * terms of your choice, provided that you also meet, for each linked
 * independent module, the terms and conditions of the license of that
 * module.  An independent module is a module which is not derived from
 * or based on this library.  If you modify this code, you may extend
 * this exception to your version of the code, but you are not
 * obligated to do so.  If you do not wish to do so, delete this
 * exception statement from your version.
 *
 * This software is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with this software; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301 USA.
 *
 */
 
`include "system_conf.v"
module serpario #(
    parameter INPUT_WIDTH = 9,
    parameter OUTPUT_WIDTH = 16,
    parameter OUT_INITIAL_VALUE = 0,
    parameter CLOCK_DIV = 10,
    parameter LOG2_POLLING_PERIOD = 14)
    (

          // wishbone slave signals
          input[31:0] serpario_ADR_I,
          input[31:0] serpario_DAT_I,
          input serpario_WE_I,
          input[3:0] serpario_SEL_I,
          input serpario_STB_I,
          input serpario_CYC_I,
          input serpario_LOCK_I,
          input[2:0] serpario_CTI_I,
          input[1:0] serpario_BTE_I,
          output[31:0] serpario_DAT_O,
          output serpario_ACK_O,
          output serpario_ERR_O,
          output serpario_RTY_O,

          // external signals
          input SER_IN,
          output SER_OUT,
          output SH_CLK,
          output STORE,
          output OUT_EN,

          input CLK_I,
          input RST_I   );


          // Instantiate user's custom module
          serial_io #( 
              .INPUT_WIDTH (INPUT_WIDTH),
              .OUTPUT_WIDTH (OUTPUT_WIDTH),
              .OUT_INITIAL_VALUE (OUT_INITIAL_VALUE),
              .CLOCK_DIV (CLOCK_DIV),
              .LOG2_POLLING_PERIOD (LOG2_POLLING_PERIOD) )
          instantiate_serial_io (

                // Connect Wishbone slave
               .WB_ADR_I(serpario_ADR_I),
               .WB_DAT_I(serpario_DAT_I),
               .WB_WE_I(serpario_WE_I),
               .WB_SEL_I(serpario_SEL_I),
               .WB_STB_I(serpario_STB_I),
               .WB_CYC_I(serpario_CYC_I),
               .WB_LOCK_I(serpario_LOCK_I),
               .WB_CTI_I(serpario_CTI_I),
               .WB_BTE_I(serpario_BTE_I),
               .WB_DAT_O(serpario_DAT_O),
               .WB_ACK_O(serpario_ACK_O),
               .WB_ERR_O(serpario_ERR_O),
               .WB_RTY_O(serpario_RTY_O),

                // Connect External signals
               .SER_IN(SER_IN),
               .SER_OUT(SER_OUT),
               .SH_CLK(SH_CLK),
               .STORE(STORE),
               .OUT_EN(OUT_EN),

               .CLK_I(CLK_I),
               .RST_I(RST_I) );

endmodule
