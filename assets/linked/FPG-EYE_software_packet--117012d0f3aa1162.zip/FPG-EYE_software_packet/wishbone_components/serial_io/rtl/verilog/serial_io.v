/*
 * Copyright (C) 2011 Evidence Srl.  All rights reserved.
 *
 * This is free software; you can redistribute it
 * and/or modify it under the terms of the GNU General Public License
 * version 2 as published by the Free Software Foundation, 
 * (with a special exception described below).
 *
 * Linking this code statically or dynamically with other modules is
 * making a combined work based on this code.  Thus, the terms and
 * conditions of the GNU General Public License cover the whole
 * combination.
 *
 * As a special exception, the copyright holders of this library give you
 * permission to link this code with independent modules to produce an
 * executable, regardless of the license terms of these independent
 * modules, and to copy and distribute the resulting executable under
 * terms of your choice, provided that you also meet, for each linked
 * independent module, the terms and conditions of the license of that
 * module.  An independent module is a module which is not derived from
 * or based on this library.  If you modify this code, you may extend
 * this exception to your version of the code, but you are not
 * obligated to do so.  If you do not wish to do so, delete this
 * exception statement from your version.
 *
 * This software is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with this software; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301 USA.
 *
 */
 
/* =============================================================================
 *                         FILE DETAILS
 * Project          : 
 * File             : serio.v
 * Dependencies     : system_conf.v
 * Description      : Interface for the 74HC165 and 74HC595 chips with 
 *                    Wishbone bus.
 * =============================================================================

  Wishbone registers:
  0x0 In
  0x4 Out
  0x8 Status
  0xC Control
 */
 
`ifndef SERIAL_IO_V
`define SERIAL_IO_V
`timescale 1ns/100 ps
`include "system_conf.v"
module serial_io #(parameter INPUT_WIDTH = 9,
                   parameter OUTPUT_WIDTH = 16,
                   parameter OUT_INITIAL_VALUE = 0,
                   parameter IRQ_MODE = 0,
                   parameter CLOCK_DIV = 10,
                   parameter LOG2_POLLING_PERIOD = 14)
    (
     //system clock and reset
     CLK_I,
     RST_I,
     //wishbone interface signals
     WB_ADR_I,
     WB_CYC_I,
     WB_DAT_I,
     WB_SEL_I,
     WB_STB_I,
     WB_WE_I,
     WB_LOCK_I,
     WB_CTI_I,
     WB_BTE_I,
     WB_ACK_O,
     WB_RTY_O,
     WB_DAT_O,
     WB_ERR_O,
     //IRQ_O,
     SER_IN,
     SER_OUT,
     SH_CLK,
     STORE,
     OUT_EN
     );

//---------------------------------------------------------------------
// inputs
    input               CLK_I;
    input               RST_I;
    input [31:0]        WB_ADR_I;
    input               WB_CYC_I;
    input [31:0]        WB_DAT_I;
    input [3:0]         WB_SEL_I;
    input               WB_STB_I;
    input               WB_WE_I;
    input               WB_LOCK_I;
    input [2:0]         WB_CTI_I;
    input [1:0]         WB_BTE_I;   
    input               SER_IN;

//---------------------------------------------------------------------
// outputs
    output              WB_ACK_O;
    output              WB_RTY_O;
    output              WB_ERR_O;
    output [31:0]       WB_DAT_O;
    output              SER_OUT;
    output              SH_CLK;
    output              STORE;
    output              OUT_EN;

    //----------------
    //process
    
    wire                ADR_0;
    wire                ADR_4;
    wire                ADR_8;
    wire                ADR_C;
    wire                read_addr_0;
    wire                read_addr_4;
    wire                read_addr_8;
    wire                read_addr_c;
    wire                write_addr_0;
    wire                write_addr_4;
    wire                write_addr_8;
    wire                write_addr_c;
//    wire                IRQ_O;
    reg                 WB_ACK_O;
    wire                WB_RTY_O;
    wire                WB_ERR_O;
    wire [31:0]         WB_DAT_O;
    reg                 STORE;

    assign WB_RTY_O = 1'b0;
    assign WB_ERR_O = 1'b0;
    assign ADR_0 = (WB_ADR_I[3:0] == 4'b0000 ? 1'b1 : 0); // In
    assign ADR_4 = (WB_ADR_I[3:0] == 4'b0100 ? 1'b1 : 0); // Out
    assign ADR_8 = (WB_ADR_I[3:0] == 4'b1000 ? 1'b1 : 0); // Status
    assign ADR_C = (WB_ADR_I[3:0] == 4'b1100 ? 1'b1 : 0); // Control
    assign read_addr_0 = (ADR_0 & WB_STB_I & ~WB_WE_I);
    assign read_addr_4 = (ADR_4 & WB_STB_I & ~WB_WE_I);
    assign read_addr_8 = (ADR_8 & WB_STB_I & ~WB_WE_I);
    assign read_addr_c = (ADR_C & WB_STB_I & ~WB_WE_I);  
    assign write_addr_0 = ((ADR_0 & WB_STB_I & WB_WE_I) == 1'b1 && !WB_ACK_O && WB_SEL_I == 4'b1111);
    assign write_addr_4 = ((ADR_4 & WB_STB_I & WB_WE_I) == 1'b1 && !WB_ACK_O && WB_SEL_I == 4'b1111);
    assign write_addr_8 = ((ADR_8 & WB_STB_I & WB_WE_I) == 1'b1 && !WB_ACK_O && WB_SEL_I == 4'b1111);
    assign write_addr_c = ((ADR_C & WB_STB_I & WB_WE_I) == 1'b1 && !WB_ACK_O && WB_SEL_I == 4'b1111);

    always @(posedge CLK_I or posedge RST_I) begin
        if (RST_I)
           WB_ACK_O       <= 1'b0;
        else if (WB_STB_I && !WB_ACK_O)
           WB_ACK_O       <= 1'b1;
        else
           WB_ACK_O       <= 1'b0;
    end

    reg [INPUT_WIDTH-1:0]       wb_data_in;	// Data read in
    reg [OUTPUT_WIDTH-1:0]      wb_data_out;	// Data to be written out
    reg [INPUT_WIDTH-1:0]       sh_data_in;	// Shift register, in
    reg [OUTPUT_WIDTH-1:0]      sh_data_out;	// Shift register, out
    reg                         out_en;

    assign OUT_EN = ~out_en;
    assign SER_OUT = sh_data_out[OUTPUT_WIDTH-1];

    
    // Wishbone interface
    
    reg                         update_req;
    assign WB_DAT_O = read_addr_0 ? wb_data_in : 
                      read_addr_4 ? wb_data_out :
                      read_addr_8 ? out_en :
                      0;
    always @(posedge CLK_I or posedge RST_I) begin
       if (RST_I) begin
           out_en <= 1'b1;
           wb_data_out <= OUT_INITIAL_VALUE;
           update_req <= 1'b0;
       end else begin
           if (write_addr_4) begin
               wb_data_out <= WB_DAT_I;
               update_req <= 1'b1;
           end else if (write_addr_8) begin
               out_en <= WB_DAT_I[0];
               update_req <= 1'b0;
           end else begin
               update_req <= 1'b0;
           end
       end // else: !if(RST_I)
    end // always @ (posedge CLK_I or posedge RST_I)
    
    
    // Internal & shift clock
    
    reg       div_clk;
    reg [7:0] div_cnt;
    wire      div_clk_negedge;
    
    always @(posedge CLK_I or posedge RST_I) begin
        if (RST_I) begin
            div_clk <= 1'b0;
            div_cnt <= 0;
        end else begin
            if (div_cnt == CLOCK_DIV-1) begin
                div_cnt <= 0;
                div_clk <= ~div_clk;
            end else begin
                div_cnt <= div_cnt + 1;
            end
        end // else: !if(RST_I)
    end // always @ (posedge CLK_I or posedge RST_I)

    assign div_clk_negedge = (div_cnt == CLOCK_DIV-1) && div_clk == 1'b1;

    
    // Update timer

    reg [LOG2_POLLING_PERIOD-1:0]  polling_cnt;
    wire [LOG2_POLLING_PERIOD-1:0] polling_zero = {LOG2_POLLING_PERIOD{1'b0}} ;
    wire                           update_poll;
    assign update_poll = (polling_cnt == polling_zero ? 1'b1 : 1'b0);
    always @(posedge CLK_I or posedge RST_I) begin
        if (RST_I) begin
            polling_cnt <= polling_zero;
        end else begin
            polling_cnt <= polling_cnt + 1;
        end
    end
    
    
    // Update scheduler

    reg update_needed;
    reg update_done;
    always @(posedge CLK_I or posedge RST_I) begin
        if (RST_I) begin
            update_needed <= 1'b0;
        end else begin
            if (update_req == 1'b1 || update_poll == 1'b1)
               update_needed <= 1'b1;
            else if (update_done == 1'b1)
               update_needed <= 1'b0;
        end
    end
    

    // I/O state machine

`define STATE_WIDTH         2
`define STATE_IDLE          2'b00
`define STATE_SHIFTING_OUT  2'b01
`define STATE_STROBE        2'b11
`define STATE_SHIFTING_IN   2'b10
    reg [`STATE_WIDTH-1:0]      state;
    reg [4:0] sh_cnt;
    reg       clk_en;
    always @(posedge CLK_I or posedge RST_I) begin
        if (RST_I) begin
            wb_data_in <= {INPUT_WIDTH{1'b0}};
            sh_data_in <= {INPUT_WIDTH{1'b0}};
            sh_data_out <= {OUTPUT_WIDTH{1'b0}};
            update_done <= 1'b0;
            state <= `STATE_IDLE;
            STORE <= 1'b1;
            sh_cnt <= 0;
            clk_en <= 1'b0;
        end else begin
            if (update_done == 1'b1)
               update_done <= 1'b0;
            if (div_clk_negedge) begin
                case (state)
                   `STATE_IDLE: begin
                       if (update_needed == 1'b1) begin
                           update_done <= 1'b1;
                           state <= `STATE_SHIFTING_OUT;
                           sh_data_out <= wb_data_out;
                           sh_cnt <= OUTPUT_WIDTH-1;
                           clk_en <= 1'b1;
                       end
                   end
                   `STATE_SHIFTING_OUT: begin
                       sh_data_out <= sh_data_out << 1;
                       if (sh_cnt - 1 == 0) begin
                           STORE <= 1'b0;
                           state <= `STATE_STROBE;
                       end
                       sh_cnt <= sh_cnt - 1;
                   end
                   `STATE_STROBE: begin
                       STORE <= 1'b1;
                       state <= `STATE_SHIFTING_IN;
                       // Skip one clock cycle, so that 74HC165's D7 isn't lost
                       clk_en <= 1'b0;
                       sh_cnt <= INPUT_WIDTH - 1;
                   end
                   `STATE_SHIFTING_IN: begin
                       clk_en <= 1'b1;
                       sh_data_in <= { sh_data_in[INPUT_WIDTH-2:0], SER_IN };
                       if (sh_cnt == 0) begin
                           wb_data_in <= { sh_data_in[INPUT_WIDTH-2:0], SER_IN };
                           state <= `STATE_IDLE;
                           clk_en <= 1'b0;
                       end
                       sh_cnt <= sh_cnt - 1;
                   end
                endcase // case (state)
            end // if (div_clk_negedge)
        end // else: !if(RST_I)
    end // always @ (posedge CLK_I)

    assign SH_CLK = div_clk & clk_en;

endmodule // serial_io

`endif // SERIAL_IO_V
