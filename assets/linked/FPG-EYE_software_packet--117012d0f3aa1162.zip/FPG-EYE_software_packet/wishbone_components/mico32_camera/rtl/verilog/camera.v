/*
 * Copyright (C) 2011 Evidence Srl.  All rights reserved.
 *
 * Evidence Srl licenses to you the right to use, copy, 
 * and distribute the mico32_camera component when embedded on a FPG-EYE board.
 *
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * EVIDENCE SRL BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 */
 
module camera (

          // wishbone slave signals
          input[31:0] slv_ADR_I,
          input[31:0] slv_DAT_I,
          input slv_WE_I,
          input[3:0] slv_SEL_I,
          input slv_STB_I,
          input slv_CYC_I,
          input slv_LOCK_I,
          input[2:0] slv_CTI_I,
          input[1:0] slv_BTE_I,
          output[31:0] slv_DAT_O,
          output slv_ACK_O,
          output slv_ERR_O,
          output slv_RTY_O,

          // wishbone master signals
          output[31:0] mst_ADR_O,
          output[31:0] mst_DAT_O,
          output mst_WE_O,
          output[3:0] mst_SEL_O,
          output mst_STB_O,
          output mst_CYC_O,
          output mst_LOCK_O,
          output[2:0] mst_CTI_O,
          output[1:0] mst_BTE_O,
          input[31:0] mst_DAT_I,
          input mst_ACK_I,
          input mst_ERR_I,
          input mst_RTY_I,

          // external signals
          input [7:0] cam_y,
          input cam_pclk,
          input cam_hsync,
          input cam_vsync,
          output cam_mclk,
          output cam_rst,
          output cam_enb,

          input CLK_I,
          input RST_I,
          output INTR_O  );


	wire   [7:0] wcnt;
	wire	fifo_threshold;

	camera_component_mod camera_mod (

        // Connect Wishbone slave
        .slv_addr(slv_ADR_I),
        .slv_datai(slv_DAT_I),
        .slv_we(slv_WE_I),
        .slv_sel(slv_SEL_I),
        .slv_stb(slv_STB_I),
        .slv_cyc(slv_CYC_I),
        .slv_datao(slv_DAT_O),
        .slv_ack(slv_ACK_O),
        .slv_err(slv_ERR_O),
        .slv_rty(slv_RTY_O),

		// fifo I/O
		.wcnt(wcnt),
		.threshold(fifo_threshold),

        // Connect Wishbone master
        .mst_addr(mst_ADR_O),
        .mst_data(mst_DAT_O),
        .mst_we(mst_WE_O),
        .mst_sel(mst_SEL_O),
        .mst_stb(mst_STB_O),
        .mst_cyc(mst_CYC_O),
        .mst_lock(mst_LOCK_O),
        .mst_cti(mst_CTI_O),
        .mst_bte(mst_BTE_O),
        .mst_ack(mst_ACK_I),
        .mst_err(mst_ERR_I),
        .mst_rty(mst_RTY_I),

        // Connect External signals
        .y(cam_y),
        .pclk(cam_pclk),
        .hsync(cam_hsync),
        .vsync(cam_vsync),
        .mclk(cam_mclk),
        .rst(cam_rst),
        .enb(cam_enb),

        .w_clk(CLK_I),
        .w_reset(RST_I),
        .w_irq(INTR_O) );

		  
assign fifo_threshold = 
		`ifdef CAMERA_FIFO_DEPTH_2 
			wcnt[1];
		`else
		`ifdef CAMERA_FIFO_DEPTH_4
			wcnt[2];
		`else
		`ifdef CAMERA_FIFO_DEPTH_8
			wcnt[3];
		`else
		`ifdef CAMERA_FIFO_DEPTH_16
			wcnt[4];
		`else
		`ifdef CAMERA_FIFO_DEPTH_32
			wcnt[5];
		`else
		`ifdef CAMERA_FIFO_DEPTH_64
			wcnt[6];
		`else
		`ifdef CAMERA_FIFO_DEPTH_128
			wcnt[7];
		`else 
			wcnt[4];
		`endif 
		`endif						
		`endif						
		`endif						
		`endif						
        `endif						
		`endif					

endmodule
