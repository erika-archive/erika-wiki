/*
 * Copyright (C) 2011 Evidence Srl.  All rights reserved.
 *
 * Evidence Srl licenses to you the right to use, copy, 
 * and distribute the mico32_camera component when embedded on a FPG-EYE board.
 *
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * EVIDENCE SRL BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 */

`include "system_conf.v"
module mico32_camera (

          // wishbone slave signals
          input[31:0] slv_ADR_I,
          input[31:0] slv_DAT_I,
          input slv_WE_I,
          input[3:0] slv_SEL_I,
          input slv_STB_I,
          input slv_CYC_I,
          input slv_LOCK_I,
          input[2:0] slv_CTI_I,
          input[1:0] slv_BTE_I,
          output[31:0] slv_DAT_O,
          output slv_ACK_O,
          output slv_ERR_O,
          output slv_RTY_O,

          // wishbone master signals
          output[31:0] mst_ADR_O,
          output[31:0] mst_DAT_O,
          output mst_WE_O,
          output[3:0] mst_SEL_O,
          output mst_STB_O,
          output mst_CYC_O,
          output mst_LOCK_O,
          output[2:0] mst_CTI_O,
          output[1:0] mst_BTE_O,
          input[31:0] mst_DAT_I,
          input mst_ACK_I,
          input mst_ERR_I,
          input mst_RTY_I,

          // external signals
          input [7:0] cam_y,
          input cam_pclk,
          input cam_hsync,
          input cam_vsync,
          output cam_mclk,
          output cam_rst,
          output cam_enb,

          input CLK_I,
          input RST_I,
          output INTR_O  );



          // Instantiate user's custom module
          camera instantiate_camera ( 

                // Connect Wishbone slave
               .slv_ADR_I(slv_ADR_I),
               .slv_DAT_I(slv_DAT_I),
               .slv_WE_I(slv_WE_I),
               .slv_SEL_I(slv_SEL_I),
               .slv_STB_I(slv_STB_I),
               .slv_CYC_I(slv_CYC_I),
               .slv_DAT_O(slv_DAT_O),
               .slv_ACK_O(slv_ACK_O),
               .slv_ERR_O(slv_ERR_O),
               .slv_RTY_O(slv_RTY_O),

                // Connect Wishbone master
               .mst_ADR_O(mst_ADR_O),
               .mst_DAT_O(mst_DAT_O),
               .mst_WE_O(mst_WE_O),
               .mst_SEL_O(mst_SEL_O),
               .mst_STB_O(mst_STB_O),
               .mst_CYC_O(mst_CYC_O),
               .mst_LOCK_O(mst_LOCK_O),
               .mst_CTI_O(mst_CTI_O),
               .mst_BTE_O(mst_BTE_O),
               .mst_ACK_I(mst_ACK_I),
               .mst_ERR_I(mst_ERR_I),
               .mst_RTY_I(mst_RTY_I),

                // Connect External signals
               .cam_y(cam_y),
               .cam_pclk(cam_pclk),
               .cam_hsync(cam_hsync),
               .cam_vsync(cam_vsync),
               .cam_mclk(cam_mclk),
               .cam_rst(cam_rst),
               .cam_enb(cam_enb),

               .CLK_I(CLK_I),
               .RST_I(RST_I),
               .INTR_O(INTR_O) );

endmodule
