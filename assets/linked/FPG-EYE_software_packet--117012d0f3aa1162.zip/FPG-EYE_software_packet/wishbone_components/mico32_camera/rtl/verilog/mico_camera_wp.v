/*
 * Copyright (C) 2011 Evidence Srl.  All rights reserved.
 *
 * Evidence Srl licenses to you the right to use, copy, 
 * and distribute the mico32_camera component when embedded on a FPG-EYE board.
 *
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * EVIDENCE SRL BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 */

`timescale 1ns / 1ps

`ifndef _CAMERA_COMPONENT_
`define _CAMERA_COMPONENT_

module camera_component_mod
	(	
	// Clock and reset signals from Wishbone.
	w_clk,
	w_reset,

	// Slave Wishbone.
	slv_addr,
	slv_datai,
	slv_sel,
	slv_cyc,
	slv_stb,
	slv_we,
	slv_datao,
	slv_ack,
	slv_err,
	slv_rty,
	
	// Processor interrupt.
	w_irq,
	
	// fifo I/O
	wcnt,
	threshold,
	
	// Master Wishbone.
	mst_addr,
	mst_data,
	mst_sel,
	mst_cti,
	mst_we,
	mst_stb,
	mst_cyc,
	mst_lock,
	mst_ack,
	mst_err,
	mst_bte,
	mst_rty,
	
	// Camera Pin.
	y,
	pclk,
	hsync,
	vsync,
	mclk,
	rst,
	enb
	);
	
	// Clock and reset signals from Wishbone.
	input w_clk;
	input w_reset;
	// Slave Wishbone.
	input  [31:0] slv_addr;
	input  [31:0] slv_datai;
	input  [ 3:0] slv_sel;
	input  slv_cyc;
	input  slv_stb;
	input  slv_we;
	output [31:0] slv_datao;
	output slv_ack;
	output slv_err;
	output slv_rty;
	
	// Processor interrupt.
	output w_irq;
	
	// fifo I/O
	output	[7:0] wcnt;
	input   threshold;
	
	// Master Wishbone.
	output [31:0] mst_addr;
	output [31:0] mst_data;
	output [ 3:0] mst_sel;
	output [ 2:0] mst_cti;
	output mst_we;
	output mst_stb;
	output mst_cyc;
	output mst_lock;
	input  mst_ack;
	input  mst_err;
	input  mst_rty;
	output mst_bte;
		
	// Camera Pin.
	input  [ 7:0] y;
	input  pclk;
	input  hsync;
	input  vsync;
	output mclk;
	output rst;
	output enb;

endmodule

`endif

