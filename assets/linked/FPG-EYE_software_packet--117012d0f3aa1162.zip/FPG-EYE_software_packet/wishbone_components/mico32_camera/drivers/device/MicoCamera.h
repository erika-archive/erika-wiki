/*
 * Copyright (C) 2011 Evidence Srl.  All rights reserved.
 *
 * Evidence Srl licenses to you the right to use, copy, 
 * and distribute the mico32_camera component when embedded on a FPG-EYE board.
 *
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL
 * EVIDENCE SRL BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 * Author: Dario Di Stefano, Bernardo Dal Seno
 * Date: June 2010
 * Description: Cmos camera driver
 */

#ifndef MICO_CAMERA_H
#define MICO_CAMERA_H

#define MICO_CAMERA_VER 1
#define MICO_CAMERA_MINOR_VER 0

/* Camera controller registers */
typedef struct st_MicoCamera {
    void *volatile addr;
    volatile unsigned int state;
    volatile unsigned int flag;
    volatile unsigned int cntr1;
    volatile unsigned int cntr2;
    volatile unsigned int div;
    volatile unsigned int size;
}MicoCamera_t;

/* Camera controller bit masks */
/* Flag register */
#define MICO_CAM_IF_FLAG_MASK       0x0001  /* Frame completed */
#define MICO_CAM_ERR_FLAG_MASK      0x0002  /* Error during acquisition */
#define MICO_CAM_SIZE_MASK          0x0004  /* Size error */
/* Ctnr1 register */
#define MICO_CAM_START_MASK         0x0001  /* Start command */
#define MICO_CAM_IFACK_MASK         0x0002  /* Acknowledge interrupt */
#define MICO_CAM_RESET_MASK         0x0004  /* Reset camera */
/* Cntr2 register */
#define MICO_CAM_ENABLE_IRQ_MASK    0x0001  /* IRQ enable */

/* MICO CAMERA Macros */
#define Mico_camera_read_address(cam)           ((cam)->addr)
#define Mico_camera_write_address(cam, address) ((cam)->addr = (address))
#define Mico_camera_read_status_register(cam)   ((cam)->state)
#define Mico_camera_read_IF_flag(cam)           ((cam)->flag & MICO_CAM_IF_FLAG_MASK)
#define Mico_camera_read_ERR_flag(cam)          ((cam)->flag & MICO_CAM_ERR_FLAG_MASK)
#define Mico_camera_start(cam)                  ((cam)->cntr1 = MICO_CAM_START_MASK)
#define Mico_camera_clear_IRQ_flag(cam)         ((cam)->cntr1 = MICO_CAM_IFACK_MASK)
#define Mico_camera_reset(cam)                  ((cam)->cntr1 = MICO_CAM_RESET_MASK)
#define Mico_camera_enable_IRQ(cam)             ((cam)->cntr2 = MICO_CAM_IF_FLAG_MASK)
#define Mico_camera_disable_IRQ(cam)            ((cam)->cntr2 = 0)
#define Mico_camera_IRQ_enabled(cam)            ((cam)->cntr2 & MICO_CAM_ENABLE_IRQ_MASK)
#define Mico_camera_write_divisor(cam, divisor) ((cam)->div = (divisor))
#define Mico_camera_read_divisor(cam)           ((cam)->div)
#define Mico_camera_frame_terminated(cam)       ((cam)->flag & MICO_CAM_IF_FLAG_MASK)
#define Mico_camera_write_size(cam, value)      ((cam)->size = (value))
#define Mico_camera_read_size_err_flag(cam)     ((cam)->flag & MICO_CAM_SIZE_MASK)

/* Camera component states */

/* Camera is resetting */
#define MICO_CAMERA_RESET           0
/* Idle: camera and component are ready */
#define MICO_CAMERA_IDLE            1
/* Waiting for the beginning of a frame */
#define MICO_CAMERA_WAITING_FIRST   2
/* Waiting for the beginning of a frame; one more is scheduled for acquisition */
#define MICO_CAMERA_WAITING_NEXT    3
/* Acquiring a frame; one more is scheduled */
#define MICO_CAMERA_COPYING         4
/* Acquiring a frame */
#define MICO_CAMERA_COPYING_LAST    5

/* Size to be used for `size' register, from size in bytes */
#define MICO_CAMERA_SIZE_WORDS(size_bytes) (((size_bytes)+3)/4)


#endif /* #ifndef MICO_CAMERA_H */
