===============================
    FPG-EYE Software Packet
===============================

Copyright (C) 2011  Evidence Srl

Web Site: http://erika.tuxfamily.org/wiki, http://evidence.eu.com,
Contact: info@evidence.eu.com
Authors: Bernardo Dal Seno, Salvatore Marrapese
Date: 10-2011
Version: 1.0

== Description ==

FPG-EYE is a powerful prototyping board that allows you to implement complex
applications by using the Mico32 softcore and the flexibility of the FPGA
logic.
The board includes external RAM and Flash memories to store big amount of data,
and it also includes Ethernet, serial and 802.15.4 radio for wired and wireless
connections.

In this packet you can find some software utilities needed to work with the
board. You can find more information on how use this software at
http://erika.tuxfamily.org/wiki/index.php?
title=Installation_of_Mico32/FPG-EYE_development_environment .

If you use ispLever development tools, you have to apply the patches
on the sram and flash components. 
 
== Directory Layout & files description ==

/
|
|_ bootloader_client_python_script/
|   |
|   |_ send_prog.py: Python client script for launching custom program in
|       FPG-EYE platform with bootloader application.
|
|_ ispLever_patch/
|             |
|             |_ components/
|                  |
|                  |_ asram_top/
|                  |   |
|                  |   |_ rtl/
|                  |       |
|                  |       |_ verilog/
|                  |           |
|                  |           |_ asram_core.v: Mico32 Async SRAM Controller
|                  |                            component patched
|                  |
|                  |_ spi_flash/
|                  |
|                  |_ rtl/
|                  |
|                  |_ verilog/
|                       |
|                       |_ spi_flash_intf.v: Mico32 SPI Flash Controller
|                       |                    component patched
|                       |
|                       |_ wb_intf.v: Mico32 Wishbone Interface of SPI
|                                     Flash Controller patched
|
|_ wishbone_components/
|   |
|   |_ mico32_camera/
|   |   |
|   |   |_ camera_binary/
|   |   |   |
|   |   |   |_ camera_component_mod.ngo: The binary core of the mico32_camera
|   |   |       component to drop in ispLEVER projects.
|   |   |
|   |   |_ drivers/
|   |   |   |
|   |   |   |_ device/
|   |   |       |
|   |   |       |_ MicoCamera.h: header to be included in Mico32 C projects
|   |   |
|   |   |_ rtl/
|   |   |   |
|   |   |   |_ verilog/
|   |   |       |
|   |   |       |_ camera.v: binary component interface
|   |   |       |
|   |   |       |_ mico_camera_wp.v: wrapper used to specify camera FIFO depth
|   |   |       |
|   |   |       |_ mico32_camera.v: real Mico32 component connected to wishbone
|   |   |           bus
|   |   |
|   |   |_ mico32_camera.xml: Lattice Mico32 camera component description to be
|   |       included in MSB
|   |
|   |_ serial_io /
|       |
|       |
|       |_ rtl/
|       |   |
|       |   |_ verilog/
|       |       |
|       |       |_ serial_io.v: Core component
|       |       |
|       |       |_ serpario.v: Interface towards wishbone bus
|       |
|       |_ serpario.xml: Serial-Parallel IO Lattice Mico32 component 
|           description to be included in MSB
|
|_ license.txt: GPL 2 license
|
|_ Readme.txt: this file.