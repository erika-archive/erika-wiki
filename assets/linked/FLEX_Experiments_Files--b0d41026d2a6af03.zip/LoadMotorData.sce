Data = read('DCPos500Hz.txt',-1,3);
t = Data(:,1);
U = Data(:,2);
Y = Data(:,3);
plot(t,U,t,Y);

