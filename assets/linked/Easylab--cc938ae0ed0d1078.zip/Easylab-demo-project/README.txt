=======================
    Easylab Library    
=======================

Copyright (C) 2002-2011  Evidence Srl

Web Site: evidence.eu.com
Contact: info@evidence.eu.com
Authors: Dario di Stefano, Errico Guidieri
Date: 07-2011
Version: 1.0

== Description ==

Easylab board is cheap easy to use prototyping board that let you develop 
with Microchip Microstick dsPIC33F and PIC24H Development Board. 
The board give you two connectors to access to all Microcontroller I/O pins, 
a bounch of leds to visually test Digital I/O, a buzzer to play with and 
an USB port to interact with the microcontroller, through serial over USB protocol.
Power supply and serial communication come both through the same USB cable.

In addition you get with your board this software packet that contains 
the source files for a simple library (easylab.h, easylab.c) to access 
all easylab goodies and a complete example that show how to use these 
API (main.c). The library rely on dsPIC33F Microchip support library, 
so you need to install a Microchip C30 compiler for dsPIC 
(we tested with version 3.25), hereunder there is a brief tutorial for 
Microchip MPLAB IDE, where we explain how to compile and flash 
Easylab Library Example.

== Microcontroller ==

The library has been coded with dsPIC33FJ64MC802 as only test target, even 
though Microstick package come with a PIC24FJ64GP too.

== Peripheral == 

The library contains API for:

    * Configure dspic pins in realation with board layout
    * Set/Get actual clock frequency (with internal FRC with PLL)
    * Turn on/off & toggle leds
    * Read/Write DIO pins
    * Configure up to 2 General Purpose Timers
    * Start and stop a buzzer with a given forcing frequency
    * Configure one of 4 ADC channels and sample that synchronously
    * Configure 2 couple of PWM pins in any combination of PWM/override, 
      with given frequency and duty cycle
    * Serial comunication with UART serial over USB
 
== The Example ==

Easylab Library come with a simple example that shows the usage of some features of the board 
like Buzzer, USB/Serial, and leds. 

== Compile & Run the example ==

To compile and run the example you should use MPLAB IDE v8.66 or later and follow these steps:
    
    Step 1: Create a project directory and put all Easylab Library files inside (easylab.h, easylab.c, main.c).
    Step 2: Open MPLAB IDE and start a new Project Wizard ([MAIN MENU] Project-> [ITEM] Project Wizard...).
            Following steps are made inside wizard procedure.
    Step 3: Connect your Easylab with supply-communication cable and connect you microstic 
            board with programmer cable to your computer
    Step 4: select dsPIC33FJ64MC802 as target device
    Step 5: Choose your Toolsuite (Microchip C30 Toolsuite), eventually give the path to the tools
            if MPLAB IDE is not able to found them by it self.
    Step 6: Create a new Project file browsing for the previously created project directory and giving a 
            name to project file in "Save Project As" dialog.
    Step 7: Add all Easylab Library files at your project.
    Step 8: After click next until the end of wizard you could uncomment all needed compile defines 
            at begin of easylab.h file or add them to your project build options 
            ([Project CONTEXT MENU] (right click on the project) -> [ITEM] Build Options... -> [TAB] MPLAB C30 -> 
            [GROUP] Preprocessr Macros -> [BUTTON] Add) .
    Step 9: Build your project  ([Project CONTEXT MENU] -> [ITEM] Build All).
    Step 10: Select Starter Kits programmer ([MAIN MENU] Programmer -> [SUB MENU] Select Programmer -> [ITEM] Starter Kits)
    Step 11: Open a Serial Terminal (e.g. Putty.exe, HTerm.exe). Configure the port, baud rate (115200),
             data bits(8 bit), stop bits (1 bit) and parity bits (none). DON'T enable CTS. Connet to the channel.
    Step 11: Program your board ([MAIN TOLLBAR] ->[BUTTON] Program (It should have been appeared after you selected the 
             programmer) )
    Step 12: Enjoy the kitt effect and a nice stadium choir. :)
    Step 13: Have fun with it. :D
    
== EOD ==