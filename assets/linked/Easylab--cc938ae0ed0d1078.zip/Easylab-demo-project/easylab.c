/* ###*B*###
 * Easylab Library - Easylab Board Library for dsPIC33FJ64MC802
 *
 * Copyright (C) 2002-2011  Evidence Srl
 *
 * This is free software; you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License version 2 as published 
 * by the Free Software Foundation,
 * (with a special exception described below).
 *
 * Linking this code statically or dynamically with other modules is
 * making a combined work based on this code.  Thus, the terms and
 * conditions of the GNU General Public License cover the whole
 * combination.
 *
 * As a special exception, the copyright holders of this library give you
 * permission to link this code with independent modules to produce an
 * executable, regardless of the license terms of these independent
 * modules, and to copy and distribute the resulting executable under
 * terms of your choice, provided that you also meet, for each linked
 * independent module, the terms and conditions of the license of that
 * module.  An independent module is a module which is not derived from
 * or based on this library.  If you modify this code, you may extend
 * this exception to your version of the code, but you are not
 * obligated to do so.  If you do not wish to do so, delete this
 * exception statement from your version.
 *
 * Easylab Library is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with ERIKA Enterprise; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301 USA.
 * ###*E*### 
 */
/* 
    This is the source for all driver and method to interact with easylab board. 
    ere are API for Leds, Buzzer, UART, Timer, ADC e PWM.
    
    author: Dario Di Stefano
    date:   07/2011
*/

/**********************************
   ATTENTION! 
   The following defines are needed 
   for compilation. You could set 
   them as build options or 
   uncomment those ones 
**********************************/
/*
#define __USE_BUZZER__
#define __USE_TIMER__
#define __USE_PWM__
#define __USE_ADC__
#define __USE_UART__
*/


#include "easylab.h"

#define MEGA 1000000ul

void easylab_board_init(void){
    init_uart1_tx_pin();
    init_uart1_rx_pin();
}

/*variabile che mantiene il clock di istruzione impostato */
static volatile unsigned fcy_ = 8;

/* Imposta il clock di istruzione del dspic. Range [8,40] Mhz
 * vedi pag 147 data sheet dsPic
 *
 * e.g with Fcy = 40 e N1 = N2 = 2; 
 * Fin:  frequenza oscillatore primario. Nel nostro caso FRC interno = 7.37 MHz
 * Fosc = Fin*M/(N1*N2),    --> Oscillator frequency / PLL output
 * Fcy  = Fosc/2            --> Device operating frequency
 * Fosc = 7.37M*43(2*2) =~ 80Mhz for 7.37M input clock 
 */
void set_device_mips(unsigned fcy) {
    /*Input out of range correction */
    if(fcy < 8)       fcy = 8; 
    else if(fcy > 40) fcy = 40;
    
    /* M = (2 * N1 * N2) * Fcy / Fin  */
    unsigned M = (fcy * MEGA * 8 + FRC_OSC_FREQ/2) / FRC_OSC_FREQ; /*Usato trucco per arrotondamento */
    
    OSCTUN             = 0;   /* FRC  Oscillator Tuning Register. 0 => center frequency nominal FRC frequency (7,37 MHz) */
    CLKDIVbits.DOZEN   = 0;   /* DOZE not enabled => Processor clock/peripheral clock ratio forced to 1:1 */
    CLKDIVbits.PLLPOST = 0;   /* N1=2  */
    CLKDIVbits.PLLPRE  = 0;   /* N2=2  */
    PLLFBDbits.PLLDIV  = M - 2; /* M PLL Feedback Divisor VCO output. Symbol eq PLLFDB. (questo registro ad un offset */
     
    
    __builtin_write_OSCCONH(0x01); /* Initiate Clock Switch to FRC with PLL  */
    __builtin_write_OSCCONL(0x01); 
    
    while (OSCCONbits.COSC != 0b01);   /* Wait for Clock switch to occur  */
    while (!OSCCONbits.LOCK);          /* Wait for PLL to lock
     *Setta il valore appena impostato come fcy */
    fcy_ = fcy;
}

unsigned long get_device_fcy(){
    return fcy_ * MEGA;
}

unsigned long get_device_fosc(){
    return fcy_* 2 * MEGA;
}

#ifdef __USE_TIMER__

volatile ISR_callback t1_cbk = 0;
volatile ISR_callback t2_cbk = 0;

/**
   Timer1 ISR. As request by microchip compiler
 */
void __attribute__((interrupt, auto_psv)) _T1Interrupt( void )
{
    IFS0bits.T1IF = 0;                /* reset timer interrupt flag    */
    if(t1_cbk!=0)
        t1_cbk();
}

/**
   Timer2 ISR. As request by microchip compiler
 */
void __attribute__((interrupt, auto_psv)) _T2Interrupt( void )
{
     IFS0bits.T2IF = 0;                /* reset timer interrupt flag    */
    if(t2_cbk!=0)
        t2_cbk();
}


void Timer1_start( int t1_period, enum TimerPrescaleFactor ps)
{
    T1CON = 0;                        /* ensure Timer 1 is in reset state */
    IFS0bits.T1IF = 0;                /* reset Timer 1 interrupt flag */
    IPC0bits.T1IP = 5;                /* set Timer1 interrupt priority level to 4 */
    IEC0bits.T1IE = 1;                /* enable Timer 1 interrupt */
    T1CONbits.TCS = 0;                /* select external timer clock */
    T1CONbits.TGATE = 0;              /* Gated time accumulation disabled */
    TMR1 = 0x00;                      /* Clear timer register */
    PR1 = t1_period;                  /* set Timer 1 period register */
    T1CONbits.TCKPS = ps;             /* select Timer1 Input Clock Prescale */
    T1CONbits.TON = 1;                /* enable Timer 1 and start the count */ 
    
}

void Timer1_stop( void )
{
    T1CONbits.TON = 0;                /* enable Timer 1 and start the count */ 
    IEC0bits.T1IE = 0;                /* enable Timer 1 interrupt */
}

void Timer1_set_callback(ISR_callback func)
{
    t1_cbk = func;
}

void Timer2_start( int t2_period, enum TimerPrescaleFactor ps)
{
    T2CON = 0;                      /* ensure Timer 2 is in reset state */
    IFS0bits.T2IF = 0;              /* reset Timer 2 interrupt flag */
    IPC1bits.T2IP = 5;              /* set Timer 2 interrupt priority level to 4 */
    IEC0bits.T2IE = 1;              /* enable Timer 2 interrupt */
    T2CONbits.T32 = 0;              /* select 16-bit timer */
    T2CONbits.TCS = 0;              /* select external timer clock */
    T2CONbits.TGATE = 0;            /* Gated time accumulation disabled */
    TMR2 = 0x00;                    /* Clear timer register */
    PR2 = t2_period;                /* set Timer 2 period register */
    T2CONbits.TCKPS = ps;           /* select Timer 2 Input Clock Prescale */
    T2CONbits.TON = 1;              /* enable Timer 2 and start the count */ 
}

void Timer2_stop( void )
{
    T2CONbits.TON = 0;                 /* enable Timer 2 and start the count */ 
    IEC0bits.T2IE = 0;                /* enable Timer 2 interrupt */
}

void Timer2_set_callback(ISR_callback func)
{
    t2_cbk = func;
}

#endif /* __USE_TIMER__ */

#ifdef __USE_UART__

void uart1_init(unsigned long baud, unsigned byte_format)
{
    U1MODE          = 0;                /* reset UART 1 mode registry */  
    IEC0bits.U1RXIE = 0;                 /* Disable Interrupts */
    IEC0bits.U1TXIE = 0;
    IFS0bits.U1RXIF = 0;                /* Clear Interrupt flag bits */
    IFS0bits.U1TXIF = 0;

    U1MODEbits.BRGH   = 0;              /* UART bit lenght is 16x of clock (istruction not needed, judspst to make it explicit) */
    U1MODE |= byte_format & 0x07;       /* Number of bit, Parity and Stop bits. Only the 3 lsb mans for this */

    /*Per far esguire l'arrotondamemto si utilizza il trucco (x + (y/2))y */
    U1BRG             = (fcy_ * MEGA + (16 * baud)/2)/(16 * baud) - 1; /* UART Baud Rate Generator (BRG): vedi dspic family reference manual section 19-3 */

    U1MODEbits.UARTEN = 1;              /* enable UART */

    /* TX & RX interrupt modes */
    U1STA = 0;
    U1STAbits.UTXEN = 1;
}

void uart1_write_byte(unsigned char data)
{
    /* Polling mode */
    while (U1STAbits.UTXBF) ;
    U1TXREG = data;
    while (!U1STAbits.TRMT) ;
}

int uart1_read_byte_polling(unsigned char *data)
{        
    if (U1STAbits.OERR) {
        U1STAbits.OERR = 0;
        return UART_ERR_OVERFLOW;
    }
    if (U1STAbits.URXDA) {
        *data = U1RXREG & 0x00FF;
        U1STAbits.URXDA = 0;
        return 1;
    }
    return UART_ERR_NO_DATA;
}

void uart1_write_string(const char* str)
{
    int i;
    for(i=0; str[i]!='\0'; i++)
        uart1_write_byte(str[i]);
}


#endif /* __USE_UART__ */


#ifdef __dsPIC33FJ64MC802__
#ifdef __USE_LEDS__

void easylab_leds_init(void){
    /*Inizializzione LED pins regA */
    TRISAbits.TRISA3 = 0;
    TRISAbits.TRISA4 = 0;

    /*Inizializzione LED pins regB */
    TRISBbits.TRISB4  = 0;
    TRISBbits.TRISB5  = 0;
    TRISBbits.TRISB6  = 0;
    TRISBbits.TRISB7  = 0;
    TRISBbits.TRISB12 = 0;
    TRISBbits.TRISB13 = 0;    
}

#endif /* __USE_LEDS__ */

void easylab_buzzer_toggle(void)
{
    LATAbits.LATA2 = ~LATAbits.LATA2;
}

void easylab_buzzer_start(unsigned int period)
{
    /* to get the desired period I have to half the given value */
    period /= 2;
    TRISAbits.TRISA2 = 0; /* output */
    LATAbits.LATA2 = 0;
    Timer2_set_callback(easylab_buzzer_toggle);
    Timer2_start( MICROSECONDS_TO_TICKS(period, get_device_fcy()/8) , Tx_PS8);
}

void easylab_buzzer_stop(void)
{
    Timer2_set_callback(0);
    Timer2_stop();
}

#endif /* __USE_BUZZER */


#ifdef __USE_ADC__

void easylab_adc_init( unsigned char adc_mask )
{
    /* turn off ADC module */
    AD1CON1bits.ADON = 0;
    /* set configuration bits as ADC input */
    if(adc_mask & 0x01) /* ADC_1 pin */
        AD1PCFGLbits.PCFG0 = 0;
    else
        AD1PCFGLbits.PCFG0 = 1;
     if(adc_mask & 0x02) /* ADC_2 pin */
        AD1PCFGLbits.PCFG1 = 0;     
    else
        AD1PCFGLbits.PCFG1 = 1;
    if(adc_mask & 0x04) /* ADC_3 pin */
        AD1PCFGLbits.PCFG4 = 0;
    else
        AD1PCFGLbits.PCFG4 = 1;
    if(adc_mask & 0x08) /* ADC_4 pin */
        AD1PCFGLbits.PCFG5 = 0;
    else
        AD1PCFGLbits.PCFG5 = 1;
    /* Set control register 1 */
    /* 12-bit, unsigned integer format, autosampling */
    AD1CON1 = 0x04E0;

    /* Set control register 2 */
    /* Vref = AVcc/AVdd, Scan Inputs */
    AD1CON2 = 0x0000;
    /* Set Samples and bit conversion time
       AS = 31 Tad, Tad = 64 Tcy = 1.6us 
       disable channel scanning here */
    AD1CON3 = 0x1F3F; /* ** Last PATCH xxx **/
    AD1CSSL = 0x0000;
    /* reset ADC interrupt flag */
    IFS0bits.AD1IF = 0;
    /* disable ADC interrupts */
    IEC0bits.AD1IE = 0;
    /* turn on ADC module */
    AD1CON1bits.ADON = 1;
}

void easylab_adc_close( void )
{
    /* turn off ADC module */
    AD1CON1bits.ADON = 0;
}

int easylab_adc_get( unsigned char channel )
{
    switch (channel) {
        case ADC_PCFG0: 
            if(AD1PCFGLbits.PCFG0)
                return -1;
            AD1CHS0 = 0;
            break;
        case ADC_PCFG1: 
            if(AD1PCFGLbits.PCFG1)
                return -1;
            AD1CHS0 = 1;
            break;
        case ADC_PCFG4: 
            if(AD1PCFGLbits.PCFG4)
                return -1;
            AD1CHS0 = 4;
            break;
        case ADC_PCFG5: 
            if(AD1PCFGLbits.PCFG5)
                return -1;
            AD1CHS0 = 5;
            break;
        default: /* Set to channel 1 as default */
            return -1;
    }

    /* Start conversion */
    AD1CON1bits.SAMP = 1;
    /* Wait till the EOC */
    while(!IFS0bits.AD1IF);
    /* reset ADC interrupt flag */
    IFS0bits.AD1IF = 0;
    /* Acquire data */
    return ADC1BUF0;
}

#endif /*__USE_ADC__ */

#ifdef __USE_PWM__

int easylab_pwm_init(int pwm_ch, unsigned long pwm_freq)
{
    switch(pwm_ch)
    {
        case PWM_PWM1:
            return easylab_pwm1_init(pwm_freq, 0, PWM_MOD2);
        case PWM_PWM2:
            return easylab_pwm1_init(pwm_freq, 0, PWM_MOD1);
        case PWM_PWM3:
            return easylab_pwm2_init(pwm_freq, 0, PWM_MOD2);
        case PWM_PWM4:
            return easylab_pwm2_init(pwm_freq, 0, PWM_MOD1);
        case PWM_PWM12:
            return easylab_pwm1_init(pwm_freq, 0, PWM_MOD3);
        case PWM_PWM34:
            return easylab_pwm2_init(pwm_freq, 0, PWM_MOD3);
        default:
            return -1;
    }
}

int easylab_pwm_close(int pwm_ch)
{
    switch(pwm_ch)
    {
        case PWM_PWM1:
            easylab_pwm1_close();
            return 1;
        case PWM_PWM2:
            easylab_pwm1_close();
            return 1;
        case PWM_PWM3:
            easylab_pwm2_close();
            return 1;
        case PWM_PWM4:
            easylab_pwm2_close();
            return 1;
        case PWM_PWM12:
            easylab_pwm1_close();
            return 1;
        case PWM_PWM34:
            easylab_pwm2_close();
            return 1;
        default:
            return -1;
    }
}

int easylab_pwm_set_duty(int pwm_ch, unsigned int duty)
{
    switch(pwm_ch)
    {
        case PWM_PWM1:
            easylab_pwm1_set_duty(duty);
            return 1;
        case PWM_PWM2:
            easylab_pwm1_set_duty(duty);
            return 1;
        case PWM_PWM3:
            easylab_pwm2_set_duty(duty);
            return 1;
        case PWM_PWM4:
            easylab_pwm2_set_duty(duty);
            return 1;
        case PWM_PWM12:
            easylab_pwm1_set_duty(duty);
            return 1;
        case PWM_PWM34:
            easylab_pwm2_set_duty(duty);
            return 1;
        default:
            return -1;
    }
}

int easylab_pwm1_init(unsigned long pwm_freq, unsigned int init_duty, char dir)
{
    if(P1TCONbits.PTEN == 0)
    {
        unsigned int ptper = get_device_fcy() / pwm_freq;    
        
        if( (ptper <= 1) || (init_duty > 100) )
            return -1;

        P1TCONbits.PTEN =     0;
        P1TCONbits.PTSIDL =   0;            /*PWM time base runs in CPU Idle mode */
        P1TCONbits.PTOPS =    0b0000;       /*1:1 postscale */
        P1TCONbits.PTCKPS =   0b00;         /*PWM time base input clock period is TCY (1:1 prescale) */
        P1TCONbits.PTMOD =    0b00;         /*PWM time base operates in a Free-Running mode */
        P1TMRbits.PTMR =      0;
        P1TPER =              ptper - 1;    /* prescaler == 1 */
        P1SECMP =             0;
        
        PWM1CON1bits.PMOD1 = 1;        /*PWM I/O pin pair is in Independent PWM Output mode */
        PWM1CON1bits.PEN1H = 1;        /*PWMxy pin is enabled for PWM output */
        PWM1CON1bits.PEN1L = 1;        /*PWMxy pin is enabled for PWM output */
    
        PWM1CON2bits.SEVOPS = 0b0000;
        PWM1CON2bits.IUE    = 0;
        PWM1CON2bits.OSYNC  = 1;
        PWM1CON2bits.UDIS   = 0;

        P1DTCON1 =             0;
        P1FLTACON =         0;

        P1OVDCONbits.POUT1H = 0; 
        P1OVDCONbits.POUT1L = 0;
        easylab_pwm1_set_direction(dir);
        
        P1DC1 = 0<<1;    
        easylab_pwm1_set_duty(init_duty);
        
        IEC3bits.FLTA1IE =  0;
        IEC3bits.PWM1IE  =     0;
        P1TCONbits.PTEN  = 1;
    }
    else
    {
        easylab_pwm1_set_direction(dir);
        easylab_pwm1_set_duty(init_duty);
    }
    return 1;
}

int easylab_pwm2_init(unsigned long pwm_freq, unsigned int init_duty, char dir)
{
    if(P2TCONbits.PTEN == 0)
    {
        unsigned int ptper = get_device_fcy() / pwm_freq;    
        
        if( (ptper <= 1) || (init_duty > 100) )
            return -1;

        P2TCONbits.PTEN =     0;
        P2TCONbits.PTSIDL =     0;        /*PWM time base runs in CPU Idle mode */
        P2TCONbits.PTOPS =     0b0000;    /*1:1 postscale */
        P2TCONbits.PTCKPS = 0b00;    /*PWM time base input clock period is TCY (1:1 prescale) */
        P2TCONbits.PTMOD =     0b00;    /*PWM time base operates in a Free-Running mode */
        P2TMRbits.PTMR =     0;
        P2TPER =             ptper - 1;    /* prescaler == 1 */
        P2SECMP =             0;
        
        PWM2CON1bits.PMOD1 = 1;        /*PWM I/O pin pair is in Independent PWM Output mode */
        PWM2CON1bits.PEN1H = 1;        /*PWMxy pin is enabled for PWM output */
        PWM2CON1bits.PEN1L = 1;        /*PWMxy pin is enabled for PWM output */
    
        PWM2CON2bits.SEVOPS = 0b0000;
        PWM2CON2bits.IUE    = 0;
        PWM2CON2bits.OSYNC  = 1;
        PWM2CON2bits.UDIS   = 0;

        P2DTCON1 =             0;
        P2FLTACON =         0;

        P2OVDCONbits.POUT1H = 0; 
        P2OVDCONbits.POUT1L = 0;
        easylab_pwm2_set_direction(dir);
        
        P2DC1 = 0<<1;    
        easylab_pwm2_set_duty(init_duty);
        
        IEC4bits.FLTA2IE =  0;
        IEC4bits.PWM2IE  =     0;
        P2TCONbits.PTEN  =     1;
    }
    else
    {
        easylab_pwm2_set_direction(dir);
        easylab_pwm2_set_duty(init_duty);
    }
    return 1;
}


void easylab_pwm1_set_duty(unsigned int duty)
{
    P1DC1 = (((unsigned long)duty * (P1TPER+1) + (PWM_DUTY_MAX/2))/PWM_DUTY_MAX) << 1;    /* please, note the shift operation... (used the round trick...) */
}

void easylab_pwm2_set_duty(unsigned int duty)
{
    P2DC1 = (((unsigned long)duty * (P2TPER+1) + (PWM_DUTY_MAX/2))/PWM_DUTY_MAX) << 1;    /* please, note the shift operation... (used the round trick...) */
}

void easylab_pwm1_set_direction(char dir)
{
    switch(dir)
    {
        case PWM_MOD1:
            P1OVDCONbits.POVD1H = 1;      /* PWM */
            P1OVDCONbits.POVD1L = 0;      /* OVERRIDE */
            break;
        case PWM_MOD2:
            P1OVDCONbits.POVD1H = 0;      /* OVERRIDE */
            P1OVDCONbits.POVD1L = 1;      /* PWM */
            break;
        case PWM_MOD3:
            P1OVDCONbits.POVD1H = 1;      /* PWM */
            P1OVDCONbits.POVD1L = 1;      /* PWM */
            break;
        case PWM_MOD4:
            P1OVDCONbits.POVD1H = 0;      /* OVERRIDE */
            P1OVDCONbits.POVD1L = 0;      /* OVERRIDE */
            break;
        default:
            P1OVDCONbits.POVD1H = 1;      /* PWM */
            P1OVDCONbits.POVD1L = 1;      /* PWM */
    }
}

void easylab_pwm2_set_direction(char dir)
{
    switch(dir)
    {
        case PWM_MOD1:
            P2OVDCONbits.POVD1H = 1;      /* PWM */
            P2OVDCONbits.POVD1L = 0;      /* OVERRIDE */
            break;
        case PWM_MOD2:
            P2OVDCONbits.POVD1H = 0;      /* OVERRIDE */
            P2OVDCONbits.POVD1L = 1;      /* PWM */
            break;
        case PWM_MOD3:
            P2OVDCONbits.POVD1H = 1;      /* PWM */
            P2OVDCONbits.POVD1L = 1;      /* PWM */
            break;
        case PWM_MOD4:
            P2OVDCONbits.POVD1H = 0;      /* OVERRIDE */
            P2OVDCONbits.POVD1L = 0;      /* OVERRIDE */
            break;
        default:
            P2OVDCONbits.POVD1H = 1;      /* PWM */
            P2OVDCONbits.POVD1L = 1;      /* PWM */
    }
}

void easylab_pwm1_close(void)
{
    P1TCONbits.PTEN = 0;
}

void easylab_pwm2_close(void)
{
    P2TCONbits.PTEN = 0;
}

#endif /* __USE_PWM__ */
