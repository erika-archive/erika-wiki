/* ###*B*###
 * Easylab Library - Easylab Board Library for dsPIC33FJ64MC802
 *
 * Copyright (C) 2002-2011  Evidence Srl
 *
 * This is free software; you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License version 2 as published 
 * by the Free Software Foundation,
 * (with a special exception described below).
 *
 * Linking this code statically or dynamically with other modules is
 * making a combined work based on this code.  Thus, the terms and
 * conditions of the GNU General Public License cover the whole
 * combination.
 *
 * As a special exception, the copyright holders of this library give you
 * permission to link this code with independent modules to produce an
 * executable, regardless of the license terms of these independent
 * modules, and to copy and distribute the resulting executable under
 * terms of your choice, provided that you also meet, for each linked
 * independent module, the terms and conditions of the license of that
 * module.  An independent module is a module which is not derived from
 * or based on this library.  If you modify this code, you may extend
 * this exception to your version of the code, but you are not
 * obligated to do so.  If you do not wish to do so, delete this
 * exception statement from your version.
 *
 * Easylab Library is distributed in the hope that it will be
 * useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 * of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License version 2 for more details.
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with ERIKA Enterprise; if not, write to the
 * Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
 * Boston, MA 02110-1301 USA.
 * ###*E*### 
 */


/* 
    This is the header for all driver and method to interact with easylab board. 
    ere are API for Leds, Buzzer, UART, Timer, ADC e PWM.
    
    author: Dario Di Stefano
    date:   07/2011
*/

#ifndef __INCLUDE_EASYLAB_H__
#define __INCLUDE_EASYLAB_H__

/**********************************
   ATTENTION! 
   The following defines are needed 
   for compilation of the example. 
   You could set them as build options 
   or uncomment those ones 
**********************************/
/*
#define __USE_LEDS__
#define __USE_DIO__
#define __USE_BUZZER__
#define __USE_TIMER__
#define __USE_PWM__
#define __USE_ADC__
#define __USE_UART__
*/

/******************************* 
Include device header
********************************/
#include "p33Fxxxx.h"

#define __INLINE__ static inline

/* initialiazation board pins */
void easylab_board_init(void);

#ifdef __dsPIC33FJ64MC802__
/* Set on pin RP11 the output signal U1TX */
__INLINE__ void init_uart1_tx_pin(void) {RPOR5bits.RP11R = 0b00011;}

/* Route U1RX through pin RP10 */
__INLINE__ void init_uart1_rx_pin(void) {
    RPINR18bits.U1CTSR = 0b11111; /* U1CTS is routed through no pin */
    RPINR18bits.U1RXR  = 10; /* Route U1RX through pin RP10 */
}
#endif /*__dsPIC33FJ64MC802__ */

#ifdef __USE_LEDS__
/* Dichiarazione funzione di inizializzazione LEDs */
void easylab_leds_init(void);

#ifdef __dsPIC33FJ64MC802__
/*Enable/Disable all LEDS */
__INLINE__ void easylab_leds_enable(void){
    /*Abilitazione LED pins regA */
    LATAbits.LATA3 = 1;
    LATAbits.LATA4 = 1;

    /*Abilitazione LED pins regB */
    LATBbits.LATB4  = 1;
    LATBbits.LATB5  = 1;
    LATBbits.LATB6  = 1;
    LATBbits.LATB7  = 1;
    LATBbits.LATB12 = 1;
    LATBbits.LATB13 = 1;
}

__INLINE__ void easylab_leds_disable(void){
    /*Disabilitazione LED pins regA */
    LATAbits.LATA3 = 0;
    LATAbits.LATA4 = 0;

    /*Disabilitazione LED pins regB */
    LATBbits.LATB4  = 0;
    LATBbits.LATB5  = 0;
    LATBbits.LATB6  = 0;
    LATBbits.LATB7  = 0;
    LATBbits.LATB12 = 0;
    LATBbits.LATB13 = 0;    
}

/** @brief Initialize led 1 **/
__INLINE__ void easylab_led1_init(void)
{
    TRISAbits.TRISA3 = 0;
}

/** @brief Enable led 1 **/
__INLINE__ void easylab_led1_on(void){
    LATAbits.LATA3 = 1;
}

/** @brief Disable led 1 **/
__INLINE__ void easylab_led1_off(void){
    LATAbits.LATA3 = 0;
}

/** @brief Toggle led 1 **/
__INLINE__ void easylab_led1_toggle(void){
    LATAbits.LATA3 = ~LATAbits.LATA3;
}

/** @brief Initialize led 2 **/
__INLINE__ void easylab_led2_init(void)
{
    TRISBbits.TRISB4 = 0;
}

/** @brief Enable led 2 **/
__INLINE__ void easylab_led2_on(void){
    LATBbits.LATB4 = 1;
}

/** @brief Disable led 2 **/
__INLINE__ void easylab_led2_off(void){
    LATBbits.LATB4 = 0;
}

/** @brief Toggle led 2 **/
__INLINE__ void easylab_led2_toggle(void){
    LATBbits.LATB4 = ~LATBbits.LATB4;
}

/** @brief Initialize led 3 **/
__INLINE__ void easylab_led3_init(void)
{
    TRISAbits.TRISA4 = 0;
}

/** @brief Enable led 3 **/
__INLINE__ void easylab_led3_on(void){
    LATAbits.LATA4 = 1;
}

/** @brief Disable led 3 **/
__INLINE__ void easylab_led3_off(void){
    LATAbits.LATA4 = 0;
}

/** @brief Toogle led 3 **/
__INLINE__ void easylab_led3_toggle(void){
    LATAbits.LATA4 = ~LATAbits.LATA4;
}

/** @brief Initialize led 4 **/
__INLINE__ void easylab_led4_init(void)
{
    TRISBbits.TRISB5 = 0;
}

/** @brief Enable led 4 **/
__INLINE__ void easylab_led4_on(void){
    LATBbits.LATB5 = 1;
}

/** @brief Disable led 4 **/
__INLINE__ void easylab_led4_off(void){
    LATBbits.LATB5 = 0;
}

/** @brief Toggle led 4 **/
__INLINE__ void easylab_led4_toggle(void){
    LATBbits.LATB5 = ~LATBbits.LATB5;
}

/** @brief Initialize led 5 **/
__INLINE__ void easylab_led5_init(void)
{
    TRISBbits.TRISB12 = 0;
}

/** @brief Enable led5 **/
__INLINE__ void easylab_led5_on(void){
    LATBbits.LATB12 = 1;
}

/** @brief Disable led 5 **/
__INLINE__ void easylab_led5_off(void){
    LATBbits.LATB12 = 0;
}

/** @brief Toogle led 5 **/
__INLINE__ void easylab_led5_toggle(void){
    LATBbits.LATB12 = ~LATBbits.LATB12;
}

/** @brief Initialize led 6 **/
__INLINE__ void easylab_led6_init(void)
{
    TRISBbits.TRISB13 = 0;
}

/** @brief Enable led 6 **/
__INLINE__ void easylab_led6_on(void){
    LATBbits.LATB13 = 1;
}

/** @brief Disable led 6 **/
__INLINE__ void easylab_led6_off(void){
    LATBbits.LATB13 = 0;
}

/** @brief Toggle led 6 **/
__INLINE__ void easylab_led6_toggle(void){
    LATBbits.LATB13 = ~LATBbits.LATB13;
}

/** @brief Initialize led 7 **/
__INLINE__ void easylab_led7_init(void)
{
    TRISBbits.TRISB7 = 0;
}

/** @brief Enable led 7 **/
__INLINE__ void easylab_led7_on(void){
    LATBbits.LATB7 = 1;
}

/** @brief Disable led 7 **/
__INLINE__ void easylab_led7_off(void){
    LATBbits.LATB7 = 0;
}

/** @brief Toggle led 7 **/
__INLINE__ void easylab_led7_toggle(void){
    LATBbits.LATB7 = ~LATBbits.LATB7;
}

/** @brief Initialize led 8 **/
__INLINE__ void easylab_led8_init(void)
{
    TRISBbits.TRISB6 = 0;
}

/** @brief Enable led 8 **/
__INLINE__ void easylab_led8_on(void){
    LATBbits.LATB6 = 1;
}

/** @brief Disable led 8 **/
__INLINE__ void easylab_led8_off(void){
    LATBbits.LATB6 = 0;
}

/** @brief Toggle led 8 **/
__INLINE__ void easylab_led8_toggle(void){
    LATBbits.LATB6 = ~LATBbits.LATB6;
}
#endif /* __dsPIC33FJ64MC802__ */
#endif /* __USE_LEDS__ */

#ifdef __USE_BUZZER__
/*
    Start the buzzer. These Buzzer API use Timer2 of dspic mcu.
    period (unsigned int): output square wave period
*/
void easylab_buzzer_start(unsigned int period);
void easylab_buzzer_stop(void);

/*
 * Toggle the status of the pin connected with the buzzer
 */
void easylab_buzzer_toggle(void);

#endif /* __USE_BUZZER__ */

#ifdef __USE_ADC__

#define AVDD 5.0
#define VREF 5.0

/*mapping for AND channel over PINs*/
#define ADC_AN1   ADC_PCFG0 
#define ADC_AN2   ADC_PCFG1
#define ADC_AN3   ADC_PCFG4
#define ADC_AN4   ADC_PCFG5

/* ADC pins value */
#define ADC_PCFG0 0b0001
#define ADC_PCFG1 0b0010
#define ADC_PCFG4 0b0100
#define ADC_PCFG5 0b1000

/* Initialize and Start ADC */
void easylab_adc_init( unsigned char adc_mask );
/* Close ADC*/
void easylab_adc_close( void );
int easylab_adc_get( unsigned char channel );
double easylab_adc_get_volt( unsigned char channel );

#endif /*__USE_ADC__ */

/********************************************/
/*              PWM                         */
/********************************************/
#ifdef __USE_PWM__

#define PWM_DUTY_MAX    32768U

/* PWM channels IDs */
#define PWM_PWM1 1
#define PWM_PWM2 2
#define PWM_PWM3 3
#define PWM_PWM4 4
/* use those follow define if you want activate simultanelly 
   channels 1 - 2 and 3 - 4*/
#define PWM_PWM12 12
#define PWM_PWM34 34

/* PWM modes*/
#define PWM_MOD1 1
#define PWM_MOD2 2
#define PWM_MOD3 3
#define PWM_MOD4 4

/* Initialize and Start a PWM channel */
int easylab_pwm_init(int pwm_ch, unsigned long pwm_freq);
/* Close a PWM channel */
int easylab_pwm_close(int pwm_ch);
/* Set a PWM channel's duty cycle */
int easylab_pwm_set_duty(int pwm_ch, unsigned int duty);

/* Initialize and start MCPWM1 microchip meaning */
int easylab_pwm1_init(unsigned long pwm_freq, unsigned int init_duty, char dir);
/* Initialize and start MCPWM1 microchip meaning */
int easylab_pwm2_init(unsigned long pwm_freq, unsigned int init_duty, char dir);
/* Set MCPWM1 duty cycle */
void easylab_pwm1_set_duty(unsigned int duty);
/* Set MCPWM2 duty cycle */
void easylab_pwm2_set_duty(unsigned int duty);
/* Set MCPWM1 (motor) direction */
void easylab_pwm1_set_direction(char dir);
/* Set MCPWM2 (motor) direction */
void easylab_pwm2_set_direction(char dir);
/* Set MCPWM1 close */
void easylab_pwm1_close(void);
/* Set MCPWM2 close */
void easylab_pwm2_close(void);

#endif /* __USE_PWM__ */

/****************************************
Other - Globlas, defines, functions, ...
*****************************************/
/* Interruption callback type */
typedef void (*ISR_callback)(void);

/* 
    _FOSCSEL: Configuration Register Oscillator Source.
    FNOSC_FRC: The Clock Source Oscillator is the internal FRC Oscillator 
    
    _FOSC: Clock Configuration Register
    FCKSM_CSECMD: Clock Switching Enabled, Clock Monitor Disabled
    OSCIOFNC_ON: OSC2 Pin is a Digital I/O
    POSCMD_NONE: Primary Oscillator disabled (no oscillator in board)
    
    _FWDT: Configuration Register Watchdog Timer 
    FWDTEN_OFF: Watch Dog Timer Disabled

*/
#define CONFIGURE_MCU()\
    _FOSCSEL(FNOSC_FRC);\
    _FOSC(FCKSM_CSECMD & OSCIOFNC_ON & POSCMD_NONE);\
    _FWDT(FWDTEN_OFF);\

/* Nominal Frequency Fast RC primary oscillator */
#ifndef FRC_OSC_FREQ
#define FRC_OSC_FREQ 7370000ul
#endif

/* Set clock frequency. Range [8,40] Mhz */
void set_device_mips(unsigned freq);
/* Return CPU/Peripheral clock [half of oscillator frequency](Hz) */
unsigned long get_device_fcy();
/* Return Oscillator Frequency (Hz) */
unsigned long get_device_fosc();

/* Macro to convert Milliseconds/Microseconds in clock ticks (given the frequency) */
#define MILLISECONDS_TO_TICKS(X_MS, REF_FREQ_HZ)                            \
    ((X_MS) * ((REF_FREQ_HZ) / 1000UL))
    
#define MICROSECONDS_TO_TICKS(X_MICROSECS, REF_FREQ_HZ)                     \
    (((X_MICROSECS) / 1000UL)?                                              \
        (MILLISECONDS_TO_TICKS(((X_MICROSECS) / 1000UL), (REF_FREQ_HZ))):   \
        (MILLISECONDS_TO_TICKS((X_MICROSECS), (REF_FREQ_HZ)) / 1000UL))

#ifdef __USE_UART__

/*UART Data parity mask selection */
#define BIT9      0x06
#define BIT8_ODD  0x04
#define BIT8_EVEN 0x02
#define BIT8_NO   0x00

/*UART Stop bits mask selection */
#define BIT_STOP_1 0x00
#define BIT_STOP_2 0x01

/*UART Error codes */
#define UART_ERR_OVERFLOW -1
#define UART_ERR_NO_DATA  -2 

/* Init and start UART */
void uart1_init(unsigned long baud, unsigned byte_format);
/* Read a byte asynchronously */
int uart1_read_byte_polling(unsigned char *data);
/* Write a byte */
void uart1_write_byte(unsigned char data);
/* Write a 0 terminated string */
void uart1_write_string(const char* str);

#endif /*__USE_UART__ */

#ifdef __USE_TIMER__

enum TimerPrescaleFactor{
    Tx_PS1 = 0,
    Tx_PS8 = 1,
    Tx_PS64 = 2,
    Tx_PS256 = 3 
};

/*
    Initialization timer1 procedure, with period ticks.
    
    t1_period (int): period value as number of ticks
    ps (TimerPrescaleFactor): prescale factor values
*/
void Timer1_start( int t1_period, enum TimerPrescaleFactor ps);
/* Stop timer1 */
void Timer1_stop( void );
/* Set cycle callback for timer1 (called every period = number of tics)*/
void Timer1_set_callback(ISR_callback func);

/*
    Initialization timer2 procedure, with period ticks.
    
    t2_period (int): period value as number of ticks
    ps (TimerPrescaleFactor): prescale factor values
*/
void Timer2_start( int t2_period, enum TimerPrescaleFactor ps);
/* Stop timer2 */
void Timer2_stop( void );
/* Set cycle callback for timer2 (called every period = number of ticks)*/
void Timer2_set_callback(ISR_callback func);

#endif /*__USE_TIMER__ */

#ifdef __USE_DIO__
#ifdef __dsPIC33FJ64MC802__
/* DIO bit allocation

Board     dsPIC     LED
DIO1       RA3       7
DIO2       RB4       8
DIO3       RA4       9
DIO4       RB5       10
DIO5       RB12      1
DIO6       RB13      2
DIO7       RB7       3
DIO8       RB6       4
           RB15      sys
*/

#endif /*__dsPIC33FJ64MC802__ */

/**
    @brief configure DIO1
    @param in: TRUE if the pin is a IN, FALSE if it is an OUT
**/
__INLINE__ void easylab_dio1_configure(unsigned char in)
{
    TRISAbits.TRISA3 = in;
}

/**
    @brief write on DIO1
    @param bit: value to set on pin
**/
__INLINE__ void easylab_dio1_write(unsigned char bit)
{
    LATAbits.LATA3 = bit;
}

/**
    @brief read DIO1
    @return value set on pin
**/
__INLINE__ unsigned char easylab_dio1_read(void)
{
    return PORTAbits.RA3;
}

/**
    @brief configure DIO2
    @param in: TRUE if the pin is a IN, FALSE if it is an OUT
**/
__INLINE__ void easylab_dio2_configure(unsigned char in)
{
    TRISBbits.TRISB4 = in;
}

/**
    @brief write on DIO2
    @param bit: value to set on pin
**/
__INLINE__ void easylab_dio2_write(unsigned char bit)
{
    LATBbits.LATB4 = bit;
}

/**
    @brief read DIO2
    @return value set on pin
**/
__INLINE__ unsigned char easylab_dio2_read(void)
{
    return PORTBbits.RB4;
}

/**
    @brief configure DIO3
    @param in: TRUE if the pin is a IN, FALSE if it is an OUT
**/
__INLINE__ void easylab_dio3_configure(unsigned char in)
{
    TRISAbits.TRISA4 = in;
}

/**
    @brief write on DIO3
    @param bit: value to set on pin
**/
__INLINE__ void easylab_dio3_write(unsigned char bit)
{
    LATAbits.LATA4 = bit;
}

/**
    @brief read DIO3
    @return value set on pin
**/
__INLINE__ unsigned char easylab_dio3_read(void)
{
    return PORTAbits.RA4;
}

/**
    @brief configure DIO4
    @param in: TRUE if the pin is a IN, FALSE if it is an OUT
**/
__INLINE__ void easylab_dio4_configure(unsigned char in)
{
    TRISBbits.TRISB5 = in;
}

/**
    @brief write on DIO4
    @param bit: value to set on pin
**/
__INLINE__ void easylab_dio4_write(unsigned char bit)
{
    LATBbits.LATB5 = bit;
}

/**
    @brief read DIO4
    @return value set on pin
**/
__INLINE__ unsigned char easylab_dio4_read(void)
{
    return PORTBbits.RB5;
}

/**
    @brief configure DIO5
    @param in: TRUE if the pin is a IN, FALSE if it is an OUT
**/
__INLINE__ void easylab_dio5_configure(unsigned char in)
{
    TRISBbits.TRISB12 = in;
}

/**
    @brief write on DIO5
    @param bit: value to set on pin
**/
__INLINE__ void easylab_dio5_write(unsigned char bit)
{
    LATBbits.LATB12 = bit;
}

/**
    @brief read DIO5
    @return value set on pin
**/
__INLINE__ unsigned char easylab_dio5_read(void)
{
    return PORTBbits.RB12;
}

/**
    @brief configure DIO6
    @param in: TRUE if the pin is a IN, FALSE if it is an OUT
**/
__INLINE__ void easylab_dio6_configure(unsigned char in)
{
    TRISBbits.TRISB13 = in;
}

/**
    @brief write on DIO6
    @param bit: value to set on pin
**/
__INLINE__ void easylab_dio6_write(unsigned char bit)
{
    LATBbits.LATB13 = bit;
}

/**
    @brief read DIO6
    @return value set on pin
**/
__INLINE__ unsigned char easylab_dio6_read(void)
{
    return PORTBbits.RB13;
}

/**
    @brief configure DIO7
    @param in: TRUE if the pin is a IN, FALSE if it is an OUT
**/
__INLINE__ void easylab_dio7_configure(unsigned char in)
{
    TRISBbits.TRISB7 = in;
}

/**
    @brief write on DIO7
    @param bit: value to set on pin
**/
__INLINE__ void easylab_dio7_write(unsigned char bit)
{
    LATBbits.LATB7 = bit;
}

/**
    @brief read DIO7
    @return value set on pin
**/
__INLINE__ unsigned char easylab_dio7_read(void)
{
    return PORTBbits.RB7;
}

/**
    @brief configure DIO7
    @param in: TRUE if the pin is a IN, FALSE if it is an OUT
**/
__INLINE__ void easylab_dio8_configure(unsigned char in)
{
    TRISBbits.TRISB6 = in;
}

/** 
    @brief write on DIO8 
    @param bit: value to set on pin 
**/
__INLINE__ void easylab_dio8_write(unsigned char bit)
{
    LATBbits.LATB6 = bit;
}

/**
    @brief read DIO8
    @return value set on pin
**/
__INLINE__ unsigned char easylab_dio8_read(void)
{
    return PORTBbits.RB6;
}

#endif /*__USE_DIO__ */


#endif /*__INCLUDE_EASYLAB_H__ */
