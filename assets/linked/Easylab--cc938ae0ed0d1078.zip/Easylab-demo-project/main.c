/*
    The demo shows the usage of some features of the board like Buzzer, USB/Serial, and leds.
    You can send ESC char to restart the demo.
 
    Author: Errico Guidieri
    Date:   2011
*/

/******************************* 
Include libraries headers 
********************************/

#include "easylab.h"

/* Macro to configure mcu hardware */
CONFIGURE_MCU();


/******************************* 
 Other - Globlas, defines, functions, ...
********************************/

/* Timer 1 global flag/counter */
volatile unsigned int timer1_counter = 0;

/* Function used to configure the demo. */
void easylab_demo_init(void);
 
/* basic peripheral demos */
void easylab_buzzer_demo(void);
void easylab_led_demo(void);
void easylab_serial_demo(void);

/* Utility: */
/* Sleep function */
void wait_ms(int ms);
/*  pretty print on string of for a unit16
    params: 
        data  (unsigned int) value to be printed
        out   (char *)       string to fill with data
        fillc (char)         value to be used to fill the buffer if data is not enough        
       
*/
void print_u16(unsigned int data, char *out, unsigned char fillc);

/******************************* 
Callbacks called by interrupt handlers
********************************/

/*
 * wait_cbk()
 * Callback used to implement the wait function.
 */
void wait_cbk (void) 
{
    timer1_counter++;    /* keep a running counter */
}

/*
 * serial_echo_cbk()
 * Callback used by the serial interface.
 */
void serial_echo_cbk (void)
{
    unsigned char data = 0;
    
    if( uart1_read_byte_polling(&data) > 0) {
        if(data == '\e') 
            /* escape to reset */
            asm("reset");
        else
            uart1_write_byte(data);
    }
}

/********************************* 
main entry point
*********************************/
int main ( void )
{
    /* Set the microcontroller instructions frequency, 40 MIPS */
    set_device_mips(40); 
	/* Buzzer demo only once because is too much annoying */
    easylab_buzzer_demo();    
    /* Demo Initialization */
    easylab_demo_init();
    while (1)
    {
        easylab_led_demo();
        easylab_serial_demo();
        wait_ms(2500);
    }
}

/********************************* 
Application functions
*********************************/

/*  pretty print on string of for a unit16
    params: 
        data  (unsigned int) value to be printed
        out   (char *)       string to fill with data
        fillc (char)         value to be used to fill the buffer if data is not enough        
       
*/
void print_u16(unsigned int data, char *out, unsigned char fillc)
{
    /* print the vaule on a char array long 6 (at least) */
    out[5] = '\0';
    out[4] = '0' + (data % 10);
    out[3] = '0' + ((data / 10) % 10);
    out[2] = '0' + ((data / 100) % 10);
    out[1] = '0' + ((data / 1000) % 10);
    out[0] = '0' + ((data / 10000) % 10);

    /*fill array with the right padding character */
    if(fillc!='0')
    {
        int i;
        for(i=0; i<6; i++) {
            if(out[i]=='0')
                out[i]=fillc;
            else
                break;
        }
    }
}

/*
 * Function used to configure the demo.
 */
void easylab_demo_init(void) 
{
    easylab_board_init();
    uart1_init(115200, BIT_STOP_1 | BIT8_NO );
    
    uart1_write_string("************* EasyLab board *************\r\n");
    uart1_write_string("***    A small board, a lot of fun!   ***\r\n");
    uart1_write_string("***  Copyright(c) 2011, Evidence Srl  ***\r\n");
    uart1_write_string("*****************************************\r\n\r\n");
    
    uart1_write_string("= = = = = = = = = = = = = = =\r\n");
    uart1_write_string("Description: This is the demo preloaded on the EasyLab board.\r\n");
    uart1_write_string("  The demo shows the usage of some features of the board like,\r\n"); 
    uart1_write_string("  Buzzer, USB/Serial, and leds.\r\n");
    uart1_write_string("= = = = = = = = = = = = = = =\r\n\r\n");
    
    /* Set the echo character callback */
    Timer2_set_callback(serial_echo_cbk);
    Timer2_start( MILLISECONDS_TO_TICKS(100, get_device_fcy()/256) , Tx_PS256);

    uart1_write_string("Starting demo... if type a character the board will send it back. If you type 'ESC' the demo will restart'\r\n");
}

/*
 * wait_ms(ms)
 * Function used to implement a sleep.
 * ms: milliseconds to wait
 */
void wait_ms(int ms) {
    Timer1_set_callback(wait_cbk);
    while(ms > 0) {
        int millisecs = 0;
        if(ms <= 200 )
            millisecs = ms;
        else
            millisecs = 200;
        timer1_counter = 0;                /* reset the counter */
        Timer1_start( MILLISECONDS_TO_TICKS(millisecs, get_device_fcy()/256) , Tx_PS256);
        while(timer1_counter == 0)
            ;
        Timer1_stop();
        ms -= millisecs;
    }
    Timer1_set_callback(0);
}

/*
 * easylab_serial_demo()
 * Function used to start the serial demo. That send back a received character
 */
void easylab_serial_demo(void)
{
    uart1_write_string("*** EasyLab board ... Enjoy! ***\r\n");
}

/*
 * easylab_led_demo()
 * Function used to start the led demo. A Kitt effect
 */
void easylab_led_demo(void)
{
    typedef void (*op)(void);
    op operations[] = {easylab_led1_toggle, easylab_led2_toggle, easylab_led3_toggle, easylab_led4_toggle, 
        easylab_led5_toggle, easylab_led6_toggle, easylab_led7_toggle, easylab_led8_toggle
    };
    unsigned const op_size = sizeof(operations)/sizeof(op);
    /* Initialize Leds */
    easylab_leds_init();    
    easylab_leds_enable();
    wait_ms(500);
    easylab_leds_disable();
    
    unsigned total_leds = 0;
    operations[op_size -1]();
    while (total_leds < 16) 
    {
        unsigned turn_on_index;
        unsigned turn_off_index;
        turn_on_index  = total_leds++ % op_size;
        turn_off_index = (turn_on_index)?(turn_on_index-1):(op_size -1);
        operations[turn_on_index]();
        operations[turn_off_index]();
        wait_ms(100);
    }
    easylab_leds_enable();
}

/*
 * easylab_buzzer_demo()
 * Function used to start the buzzer demo.
 */
void easylab_buzzer_demo(void)
{
    easylab_leds_init();    
    /* 1 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(200);
    /* 2 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(200);
    /* 3 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(100);
    /* 4 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(100);
    /* 5 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(200);
    /* 6 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(100);
    /* 7 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(100);
    /* 8 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(100);
    /* 9 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(200);
    /* 10 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
    wait_ms(100);
    /* 11 */
    easylab_leds_enable();
    easylab_buzzer_start(1000);
    wait_ms(100);
    easylab_leds_disable();
    easylab_buzzer_stop();
}
