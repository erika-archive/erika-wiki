//** Plant parameters
R = 1.0; L = 1.0;
//** PI controller parameters
Kp = 1; Ki = 100 ;
//** sys plant build 
N_plant = poly([1],"s", "coeff");
D_plant = poly([R L],"s", "coeff");
sys_ol = syslin("c", N_plant, D_plant);
//** plant root locus 
Kmax = 100;
scf(0); evans(sys_ol,Kmax);
disp("With PI controller"); pause
//** sys PID build 
N_pid = poly([Ki Kp],"s", "coeff");
D_pid = poly([0 1],"s", "coeff");
//** controller + plant 
N = N_pid * N_plant;
D = D_pid * D_plant;
//** full system 
sys_cl = syslin("c", N, D);
scf(1); evans(sys_cl);
//** plant Bode diagram 
scf(2); bode(sys_ol);
//** controller + plant Bode diagram
scf(3); bode(sys_cl);



