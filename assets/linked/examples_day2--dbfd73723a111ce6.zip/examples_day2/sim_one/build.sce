//** 
fun_names = "sim_one" ;  //** C function entry point string matrix
files     = "sim_one.o"; //** file names string matrix (where the source code is) 
libs  = []  ; //** external libraries 
flag  = "c" ; //** "c" means "C" source files 
libn = ilib_for_link(fun_names,files,libs,flag);


