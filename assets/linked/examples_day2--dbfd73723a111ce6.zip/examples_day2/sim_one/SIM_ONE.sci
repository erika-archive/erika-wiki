function [x,y,typ] = SIM_ONE(job,arg1,arg2)
 x = []; y = []; typ = [];
 
 select job
  case "plot" then
   graphics = arg1.graphics;
   standard_draw(arg1); 
  case "getinputs" then
   [x,y,typ] = standard_inputs(arg1); 
  case "getoutputs" then
   [x,y,typ] = standard_outputs(arg1); 
  case "getorigin" then
   [x,y] = standard_origin(arg1);
  case "set" then
   //** do nothing for the moment    
  case "define" then
   model = scicos_model() ; //** create an empty scicos model
   model.sim = list("sim_one", 4); //** name of the C function, type of comp.fun. (4=C code)

   model.in  = [3;3] ;  //** two input of size three (row)
   model.in2 = [ ]   ;  //** empty (used to specify column for matrix input)
   model.intyp = [1;1]; //** 1=double , 2=complex(double) , 3=int32, ecc..

   model.out  = [1]  ; //** one output of size one (scalar)
   model.out2 = [ ]  ; //** empty (used to specify column for matrix output)
   model.outtyp = [1] ; //** 1=double , 2=complex(double) , 3=int32, ecc..

   model.evtin = [1] ; //** one single event input  

   model.dstate = [0]; //** a scalar value (the initial value, zero in this case)

   model.rpar = [ ] ; //** real parameters
   model.ipar = [ ]  ; //** integer parameters

   model.blocktype = "d" ; //** consider it as discrete block (optional)

   model.dep_ut = [%f %f]; //** no dependency from input, no dependency from time

   label = [sci2exp(1),sci2exp(0)];
   gr_i = ["xstringb(orig(1),orig(2),''Sim_One'',sz(1),sz(2),''fill'');"]

   //** this is the real function that build the block and return it to Scicos 
   x = standard_define([2 2], model, label, gr_i); 

end

endfunction




