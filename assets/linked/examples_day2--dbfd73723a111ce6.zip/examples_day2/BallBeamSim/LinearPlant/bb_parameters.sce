//** 16 Apr 2008 - Update and cleaning for Scilab 4.1.2 "Diablo"
//** 25 Feb 2006 - Saturday morning : bb_10.sce 
//**----------------------------------------------------------------------------------
//** bb_dlqr : automatic design of Digital LQR regulator (Roberto Bucher; roberto.bucher@supsi.ch)
function k = bb_dlqr(fi,H,Q,R)
 // Calculates the LQR gains for discrete systems
 [n1,d1] = size(fi);
  big = sysdiag(Q,R);
 [w,wp] = fullrf(big,1e-20);
  C1 = wp(:,1:n1);
  D12 = wp(:,n1+1:$);
  P = syslin('d',fi,H,C1,D12);
 [k,X] = lqr(P);
  k=-k;
endfunction ;
//**--------------------------------------------------------------------------

//***************** Sampling Time ********************************************

Ts = 10E-3;  //** Sampling time (1:10) ms

//****************************************************************************


//**
//** Ball and beam model parameters

g = 9.81; //** m/s^2 gravity accelertion

//**
//** ------------------- BALL -----------------------

sw = 7800 ; // specific wheight of iron (stainless steel)

dm = 12E-3   ; // sphere diameter = 12 mmm
r  = dm / 2  ;

v_sphere = 4 / 3 * %pi * r^3; 

w_sphere = v_sphere * sw ; // 7.057

m = 8.400E-3 ; // measured with wheiger 

//**

//** ---------------- BEAM --------------------------

L_beam = 0.15 ; // half lenght of the beam 
                // total rail lenght = 30 cm

//** Estimate: value that require direct measures
M_beam = 20E-3 ; // half mass of the beam 
                        
Jb = 2 * ( 1/3 *  M_beam * (L_beam)^2) ; // Estimate of the beam total inertia

Jball_MAX = m * L_beam^2 ;

//** Estimate of Max static torque
Tb_Max = m * g * L_beam ;

//** Rail sensor 
Kr = 0.30 / 2.0 ; // rail costant ( [meter / Volt] )

ro = 0.960 ; // Volt 


//**  --------------- Motor -------------------------
//**  Lego 9V Motor code: 71427
//**  CAUTION: the ABSOLUTE MAXIMUM VOLTAGE IS 10 Volt 

wn_rpm = 360 ; //** nominal axe speed (rpm)

wn = wn_rpm / 60 * 2 * %pi; //** nominal speed (radian / second )   

Van     = 9.0 ; //** nominal voltage motor
Ia_noload   = 3.5E-3 ; //** no-load nominal current

//** Stall torque 
Tn = 6E-2 ; // 6 N cm   stall torque
Ian = 0.360 ; // 360 mA  current 

//** Internal resistance 
//** CAUTION: a PTC overcurrent / overtemperature protection device
//** is installed in series at the motor.
//** Ra include the the effect of this device

Ra = 25 ; //** total internal series resistance Ra = 25 ohm 

//** this off line neasure is in perfect accord with the stall
//** torque test at nominal voltage ( Ra * Ian = Van ) 

//** Motor constant 

Kv = Van / wn; // motor speed costant 

Kt = Tn / Ian; // motor torque constant 

//** the two costant are NOT equal because there is the effect of the internal
//** friction inside the motor: the efficency is < 1 ! (0.50 average)

//**  Internet refernces for LEGO Mindstorm devices 
//**  http://www.philohome.com/motors/motor.htm
//**  http://www.philohome.com/motors/motorcomp.htm
//**  http://www.crynwr.com/lego-robotics/
//**  http://www.plazaearth.com/usr/gasperi/lego.htm

//** -----------------------------------------------------

//** ---------- COUPLING ----------------------------------
//** A reduction gear is used to move the beam 
//** Motor_Gear / Beam_Gear
//    Kc = 8 / 40  

Kc = 40 / 8 ;

//**-------------------------------------------------------
//

//---------------> State Space rapresentation of the system 
// omega -> beam angular speed
// theta -> beam angular position     
// v     -> ball speed
// x     -> ball position 


A = [ -(Kv*Kc^2*Kt)/(Ra*Jb)   0       0  (m*g)/Jb 
                 1            0       0      0
                 0         5/7*g      0      0    
                 0            0       1      0     ];
      
B = [ (Kc*Kt)/(Ra*Jb)
        0
        0
        0        ] ;
      
C = [ 0 0 0 1 ] ; //** the output "y" of the system is the ball's position 



//** No direct Input-Output connection 
D = [ 0 ];
      
OpenLoopAutoValues = spec(A);      

//** ------------------------------------------------      
      
sys = syslin('c',A,B,C,D); // Build the continous system datastructure

sys_d = dscr(sys,Ts); // Transform in the discrete 

[Ad,Bd,Cd,Dd] = abcd(sys_d); // split the discrete system 

// --- Augmented system : integrator 

zeri = [0 ; 0 ; 0; 0] ;

Cdi = [ 0 0 0 -1  1 ];

Adi = [Ad zeri ; Cdi];

Bdi = [Bd ; 0] ;

// ---------- LQR Controller Design ------------------

// weights: start with Q=diag(1,1,1,1) ; change the wheight of position and angle in tens steps
//          position_one=>beam_angle, position_three=>ball_position 

R = [0.1];               // default value R=[1] 

Qi = diag([ 1 1 1 1 1]); // alternative "wheiged" experimental approach 

F_lqr_i = bb_dlqr(Adi,Bdi,Qi,R) ;// k_lqr is the Riccati feedback matrix (a dim.5 vector in this case)

//------------------------------------------------------------------------------

F =  -F_lqr_i(1:4) ; // extract the first four terms negative feedback please :)

Ki = -F_lqr_i(5) ;   // extract integrator gain  
                                            
//--------------------------------------------------------------------------------------------

Aci = Adi + Bdi * ( -F_lqr_i ) ;

//--------------------------------------------------------------------------------------------

// Observer design choice 
// The theoretical - fastest - approach is to place all the observes' discretes poles
// in  the orgin of the Z plane (zero) [podx] = 0 ; x=1,2..4
//
//         pod = [0 0 0 0]
//
// This is the case of the "deadbeat observer": fast (ready after "2 x N" samples) but 
// not immune to the noise from the sensors
// A better - pratical - choice is use real poles "far enough"(faster) than the fastest pole
// of the plant. In this way the observer has a dynamics faster than the plant but not too fast
// It is VERY important to check if the desired poles are compatible with the sampling time

wf_plant = 1.0 ; // rad/s fastes mode (instable) of the plant

Freq_MAX = ( 1/2 ) * 1 / Ts ; // Nyquist limit
W_MAX = 2*%pi*Freq_MAX      ;

poc1 = -wf_plant * 20 ; // observer's continous poles
poc2 = -wf_plant * 20 ;
poc3 = -wf_plant * 20 ;
poc4 = -wf_plant * 20 ;


pod1 = exp(poc1*Ts); // observer's discrete poles
pod2 = exp(poc2*Ts);
pod3 = exp(poc3*Ts);
pod4 = exp(poc4*Ts);

pod = [pod1 pod2 pod3 pod4] ; // observer's poles in the Z plane 

L = ppol(Ad', Cd', pod)' ; // pole placement for the observer (Z plane)  
                           // observer's feedback matrix 
                           
                           

