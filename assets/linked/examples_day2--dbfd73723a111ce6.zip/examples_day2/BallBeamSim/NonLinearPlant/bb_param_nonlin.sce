//********************************************************************************************* 
//
//  BALL AND BEAM MODELLING EQUATIONS 
//
//*********************************************************************************************
//
//** 14 March 2006: More accurate full non linear model
//
//** 15 March 2006: Controller and Simuation 

//** Linear Designed Controller LQR-Alpha - and Non Linear Simulation 


//**----------------------------------------------------------------------------------
//** bb_dlqr : automatic design of Digital LQR regulator
//**           (Roberto Bucher; roberto.bucher@supsi.ch)
function k = bb_dlqr(fi,H,Q,R)
 // Calculates the LQR gains for discrete systems
 [n1,d1] = size(fi);
  big = sysdiag(Q,R);
 [w,wp] = fullrf(big,1e-20);
  C1 = wp(:,1:n1);
  D12 = wp(:,n1+1:$);
  P = syslin('d',fi,H,C1,D12);
 [k,X] = lqr(P);
  k=-k;
endfunction ;
//**--------------------------------------------------------------------------

//**
//** Ball and beam model parameters

g = 9.81; //** m/s^2 gravity acceleration

//**
//** ------------------- BALL -----------------------

sw = 7800 ; // specific wheight of iron (stainless steel)
dm = 12E-3   ; // sphere diameter = 12 mmm
r  = dm / 2  ;
v_sphere = 4 / 3 * %pi * r^3; 
w_sphere = v_sphere * sw ; // estimanted wheight = 7.057g 

m = 8.400E-3 ; // measured with "gold accurate" wheiger 

//**

//** ---------------- BEAM --------------------------

L_rail = 0.140 ; // [meter]  Max usable lenght of the rail (+/-)   

L_beam = 0.388 ; // [meter]  Full lenght of the beam 

M_beam = 0.110 ; // [kilogram] Mass of the beam 
                                           
Jb = 1.0 / 12.0 * M_beam * (L_beam)^2 // Beam Total Inertia

Jball_MAX = m * L_rail^2  // Maximum moment of inertia of the ball 

//** Rail sensor 
Kr = 0.27 / 2.0 ; // rail costant ( [meter / Volt] )

ro = 0.960 ; // Volt 

//**  --------------- MOTOR -------------------------
//**  Lego 9V Motor code: 71427
//**  CAUTION: the ABSOLUTE MAXIMUM VOLTAGE IS 10 Volt 

wn_rpm = 360 ; //** nominal axe speed (rpm)

wn = wn_rpm / 60 * 2 * %pi; //** nominal speed (radian / second )   

Van     = 9.0 ; //** nominal voltage motor
Ia_noload   = 3.5E-3 ; //** no-load nominal current

//** Stall torque 
Tn = 6E-2 ; // 6 N cm   stall torque
Ian = 0.360 ; // 360 mA  current 

//** Internal resistance 
//** CAUTION: a PTC overcurrent / overtemperature protection device
//** is installed in series at the motor.
//** Ra include the the COLD resistance of this device

Ra = 25 ; //** total internal series resistance Ra = 25 ohm 

//** This off line neasure is in perfect accord with the stall
//** torque test at nominal voltage ( Ra * Ian = Van ) 

//** Motor constant 

Kv = Van / wn; // motor speed costant 

Kt = Tn / Ian; // motor torque constant 

//** the two costant are NOT equal because there is the effect of the internal
//** friction inside the motor: the efficency is < 1 ! (0.50 average)

//**  Internet refernces for LEGO Mindstorm devices 
//**  http://www.philohome.com/motors/motor.htm
//**  http://www.philohome.com/motors/motorcomp.htm
//**  http://www.crynwr.com/lego-robotics/
//**  http://www.plazaearth.com/usr/gasperi/lego.htm

//** -----------------------------------------------------

//** ---------- EXTERNAL MECHANICAL COUPLING -------------------------------
//** A reduction gear is used to move the beam 
//** Motor_Gear / Beam_Gear
//    Kc = 8 / 40  

Kc = 40 / 8 ; 

//**-------------------------------------------------------

//**-------------------------------------------------------
//---------------> State Space rapresentation of the system 
// omega -> beam angular speed
// theta -> beam angular position     
// v     -> ball speed
// x     -> ball position 


A = [ -(Kv*Kc^2*Kt)/(Ra*Jb)   0       0  (m*g)/Jb 
                 1            0       0      0
                 0         5/7*g      0      0    
                 0            0       1      0     ];
      
B = [ (Kc*Kt)/(Ra*Jb)
        0
        0
        0        ] ;
      
C = [ 0 0 0 1 ] ; //** the output "y" of the system is the ball's position 

//** No direct Input-Output connection 
D = [ 0 ];
      
OpenLoopAutoValues = spec(A);      

//** ------------------------------------------------


//** ------------------------------------------------      
      
      
      
Ts = 10E-3;  //** Sampling time = 10 ms

sys = syslin('c',A,B,C,D); // Build the continous system datastructure

sys_d = dscr(sys,Ts); // Transform in the discrete 

[Ad,Bd,Cd,Dd] = abcd(sys_d); // split the discrete system 

// --- Augmented system : integrator 

zeri = [0 ; 0 ; 0; 0] ;

Cdi = [ 0 0 0 -1  1 ];

// Cdi = [ -1 0 0 0  1 ];

Adi = [Ad zeri ; Cdi];

Bdi = [Bd ; 0] ;

// ---------- Design of LQR Alpha Controller  ------------------

// weights: per il tunining partire da Q=diag(1,1,1,1) e cambiare i pesi dell'angolo e della posizione
//          a colpi di dieci termine_uno=>angolo, termine_tre=>posizione carrello

alpha = 1.00 ;

R = [10];            // 1 per 1
                    
Qi = diag([1 1 1 100 10]); // alternative "wheiged" experimental approach 

F_lqr_i = bb_dlqr(Adi*alpha,Bdi*alpha,Qi,R) ;// 

//------------------------------------------------------------------------------

F =  -F_lqr_i(1:4) ; // negative feedback please :)

Ki = -F_lqr_i(5) ;

Aci = Adi + Bdi * ( -F_lqr_i ) ; // test of the closed loop system 
       
disp(abs(spec(Aci))) 

//-----------------------------------------------------------------------

// 15 March 2004: design of observer and controller with linearized system 

//** motor non linearity

M_step = 0.4 ;

M_max = +2.0 ;
M_min = -2.0 ;


//** Non Linear

xo = 0.050 ; // Steady state reference (desired) ball position [meter]

sq_amp = 0.050 ; // reference (zero) position 

// Observer design choice 
//** The observer design is the calculalation of L, feedback matrix of the Kalman Observer
// ---> lqe - linear quadratic estimator (Kalman Filter)  
//
//  Calling Sequence
//
//  [K,X] = lqe(P21) 
//
//  Parameters
//
//  P21: syslin list 
//  K, X: real matrices 
//
//  Description
//
//  lqe returns the Kalman gain for the filtering problem in continuous or discrete time. 
//
//  P21 is a syslin list representing the system
//
//      P21 = [A,B1,C2,D21] 
//
//      P21 = syslin('c',A,B1,C2,D21)
//
//      P21 = syslin('d',A,B1,C2,D21) 
//
// The input to P21 is a white noise with variance: 
//
//        [B1 ]                    [Q  S]
// BigV = [   ]      [ B1' D21'] = [    ]
//        [D21]                    [S' R]
//   
//     
//
//  X is the solution of the stabilizing Riccati equation and A+K*C2 is stable.
//
//  K is the Kalman feedback matrix of the observer 
//
//  In continuous time: 
//
//     (A-S*inv(R)*C2)*X+X*(A-S*inv(R)*C2)'-X*C2'*inv(R)*C2*X+Q-S*inv(R)*S'=0
//   
//      K=-(X*C2'+S)*inv(R)
//   
// 
//  In discrete time: 
//
//      X=A*X*A'-(A*X*C2'+B1*D21')*pinv(C2*X*C2'+D21*D21')*(C2*X*A'+D21*B1')+B1*B1'
//   
//      K=-(A*X*C2'+B1*D21')*pinv(C2*X*C2'+D21*D21') 
//
//      xhat(t+1)= E(x(t+1)| y(0),...,y(t)) (one-step predicted x) satisfies the recursion: 
//
//      xhat(t+1)=(A+K*C2)*xhat(t) - K*y(t).
//   
//Examples : Assume the equations
//.
//   x = Ax + Ge
//   y = Cx + v

//   with

//   E ee' = Q_e,    Evv' = R,    Eev' = N 

//
//  This is equivalent to
//.
//  x = Ax  + B1 w
//  y = C2x + D21 w
//
//  with E { [Ge ]  [Ge v]' } = E { [B1w ] [B1w D21w]' } = bigR =
//           [ v ]                  [D21w]    
//
//  [B1*B1'  B1*D21';
//   D21*B1'  D21*D21']  
//  =
//  [G*Q_e*G' G*N;
//   N*G' R       ]

// To find (B1,D21) given (G,Q_e,R,N) form bigR =[G*Q_e*G' G*N;N'*G' R].
// Then [W,Wt]=fullrf(bigR);  B1=W(1:size(G,1),:);
// D21=W(($+1-size(C2,1)):$,:)
//
// P21=syslin('c',A,B1,C2,D21);
// [K,X]=lqe(P21);

//** In our system  

   nx = 4 ; //** 4 state to estimate 
   ne = 4 ; //** one input 
   ny = 1 ; //** one output
   
   A = Ad         ; // A matrix (discrete case)
    
   G = eye(A); // input noise matrix 

   C = Cd ; //** output matrix 
   
   Q_e  = diag([1 0 0.1 0])*(M_step)^2  //** noise covariance
   
   R    = (5E-3)^2 ;  //** output noise scalar: position error 
   
   N = zeros(ne,ny) //** NO input/output noise cross correlation (zero)

   bigR =[G*Q_e*G' G*N ; N'*G' R] ;

   [W,Wt] = fullrf(bigR); B1 = W(1:size(G,1),:);
  
   D21 = W(($+1-size(C,1)):$,:);
   
   C2 = C; //** output matrix 

   P21 = syslin('d', A,B1,C2,D21);

   [K,X] = lqe(P21);

   L = - K  //** to adjust the sign in the Scicos Diagram    

//Riccati check:

   S=G*N;Q=B1*B1';
   (A-S*inv(R)*C2)*X+X*(A-S*inv(R)*C2)'-X*C2'*inv(R)*C2*X+Q-S*inv(R)*S'; 

//Stability check:

   autoval = spec(A+K*C); disp(autoval)
  

//**---------------------------------------------------------------------------------
//** Just for comparison : LQR designed observer 

//Ro = [1];               // 1 per 1
//                        // R=[1] costante durante il tuning !
//Qo = diag([1 1 1 10]);  // alternative "wheiged" axperimental approach 
//
//F_obs = bb_dlqr(Ad',Cd',Qo,Ro) ;// k_lqr e' la matrice F di retroazione progettata con Riccati
//
//L_lqr = F_obs';











