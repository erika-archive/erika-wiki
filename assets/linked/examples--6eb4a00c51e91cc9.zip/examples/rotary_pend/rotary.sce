// Flags
plot_flag = 0;
fname='ID_MOT';

// Identification
x=read(fname,-1,2);
t=x(:,1);
y=x(:,2);
t=t(1000:$);
t=t-t(1);
y=y(1000:$);
y=y-y(1);
if plot_flag then
  xbasc()
  plot(t,y)
end

function z=fun(p,t,y)
z=y+p(1)/p(2)^2-p(1)/p(2)*t-p(1)/p(2)^2*exp(-p(2)*t);
endfunction

p0=[1,4];
Uo=500;

[ff,p]=leastsq(list(fun,t,y/Uo),p0);

g=syslin('c',p(1)/(s*(s+p(2))));

if plot_flag==1 then
  xbasc()
  bb_step(Uo*g,3.8)
  plot(t,y)
end

Kt = 126e-6;    // Motor torque constant
Jm = Kt/p(1);
Dm = p(2)*Jm;

Ts=1e-3;

Isat=1670;

//===================================================
//
//  Linear model continous
g=9.81;      
L0=0.210;           // Arm length
J0 = Jm;            // Motor+arm inertia
J1 = 6.475353e-3;   // Pendulum inertia
R0 = Dm;            // Arm friction 
R1 = 3.499e-3;      // Pendulum friction
m = 0.07386;        // Pendulum mass
L1 = 21.0e-2;       // Pendulum length

A11 = 0;    
A12 = 1;
A13 = 0;
A14 = 0;

A21 = 0;
A22 = -R0*(J1+m*L1^2)/(J1*J0+J1*m*L0^2+m*L1^2*J0);
A23 = -m^2*L0*L1^2*g/(J1*J0+J1*m*L0^2+m*L1^2*J0);
A24 = m*L0*L1*R1/(J1*J0+J1*m*L0^2+m*L1^2*J0);

A31 = 0;
A32 = 0;
A33 = 0;
A34 = 1;

A41 = 0;
A42 = m*L0*L1*R0/(J1*J0+J1*m*L0^2+m*L1^2*J0);
A43 = m*g*L1*(J0+m*L0^2)/(J1*J0+J1*m*L0^2+m*L1^2*J0);
A44 = -R1*(J0+m*L0^2)/(J1*J0+J1*m*L0^2+m*L1^2*J0);

B1 = 0;
B2 = Kt*(J1+m*L1^2)/(J1*J0+J1*m*L0^2+m*L1^2*J0);
B3 = 0;
B4 = -Kt*m*L0*L1/(J1*J0+J1*m*L0^2+m*L1^2*J0);

A = [A11 A12 A13 A14; A21 A22 A23 A24; A31 A32 A33 A34; A41 A42 A43 A44];
B = [B1; B2; B3; B4];
C = [1 0 0 0; 0 0 1 0]; 
D = [0;0]; 

sys = syslin('c',A,B,C,D);
sysd = dscr(sys,Ts);

[Ad,Bd,Cd,Dd] = abcd(sysd);

//==========================================================//
//  Controller
Q=diag([1e5,1e2,1e4,1]);
R=[0.1]

Q=diag([1e5,1,5e3,1]);
R=[0.1]

// Control design - LQR
k_lqr=bb_dlqr(Ad,Bd,Q,R);
k=k_lqr;

//preg = 5;
//poly_c = -preg*[cos(pi/12)-%i*sin(pi/12), cos(pi/12)+%i*sin(pi/12), cos(pi/6)-%i*sin(pi/6), cos(pi/6)+%i*sin(pi/6)];
//poly_d = exp(poly_c*Ts);
//
poly_c = [-2,-3,-1.5+0.5*%i,-1.5-0.5*%i]*1.75;
poly_d = exp(poly_c*Ts);
// k = ppol(Ad,Bd,poly_d);

preg=max(abs(spec(A-B*k)));
poli_oss=exp([-preg,-preg]*10*Ts);
T=[0,0,0,1;0,1,0,0];
[Ao,Bo,Co,Do]=redobs(Ad,Bd,Cd,Dd,T,poli_oss);
obs = syslin(Ts,Ao,Bo,Co,Do);

// Control design - Controller and observer in compact form
Contr=comp_form(sysd,obs,k);

Contr.A = clean(Contr.A);

g_contr=ss2tf(Contr)
ord=z^2;
comden=poly(spec(Contr.A),'z')
gcom=syslin('d',comden/ord)

gin=g_contr*gcom;
g_s=1-gcom
gss_in2=tf2ss(gin);
gss_fbk2 = tf2ss(g_s);


Adnew=Ad-Bd*k;
Bdnew=Bd;
Cdnew=Cd(1,:);
Ddnew=Dd(1,:);

Gzctr=syslin(Ts,Adnew,Bdnew,Cdnew,Ddnew);

Kpregain=1/dcgain(Gzctr);


