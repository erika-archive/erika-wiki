function [sysc] = d2c(sys)
// Continous to discrete conversion with ZOH method
//
// Call:
//    sysc=c2d(sysd)
//
//  Parameters
//  ----------
//  sys :   System in statespace or Tf form 
//  method: 'zoh' or 'bi'
//
//  Returns
//  -------
//  sysc: continous system ss or tf

flag = 0;

if sys(1)(1)=='r' then
   if sys(4)=='c' | sys(4)==0 then
      sysc=0;
      return;
   end
   sys=tf2ss(sys);
   flag=1;
   Ts=sys(7);
else
   if sys(7)=='c' | sys(7)==0 then
      sysc=0;      
      return
   else
      Ts=sys(7);
   end
end

[a,b,c,d]=abcd(sys)
n=size(a,1);
nb=size(b,2);
nc=size(c,1);

if n==1 then
   if b==1 then
      A=0;
      B=b/Ts;
      sysc=syslin('c',A,B,c,d);
      if flag==1 then
         sysc=ss2tf(sysc);
      end
      return
   end
end

S = logm([a, b; zeros(nb,n) eye(nb,nb)]);
S = S/Ts;
if norm(imag(S)) > sqrt(%eps) then
   disp('Warning: accuracy may be poor')
end
S=real(S);
A=S(1:n,1:n);
B=S(1:n,n+1:n+nb);

sysc=syslin('c',A,B,c,d);
if flag==1 then
     sysc=clean(ss2tf(sysc));
end

endfunction
