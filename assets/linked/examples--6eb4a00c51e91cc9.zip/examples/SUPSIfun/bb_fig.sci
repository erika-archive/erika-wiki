function my_handle=bb_fig(nwindow)
  my_handle=scf(100000+nwindow);
  clf(my_handle,"reset");
endfunction
