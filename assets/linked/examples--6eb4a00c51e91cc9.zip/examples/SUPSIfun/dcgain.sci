function gm = dcgain (sys)

if sys(1)(1)~='lss' then
   sys=tf2ss(sys)
end

[a,b,c,d]=abcd(sys);
nx=size(a,1);

if sys(7)~='c' & sys(7)~=0 then
   a=a-eye(nx,nx);
end
r=rank(a);

if r<nx then
   gm=[]
else
   gm=-c*inv(a)*b+d
end
endfunction
