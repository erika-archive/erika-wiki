function [Contr]=comp_form_i(sys,obs,K,Cy)
// Create the compact form of the Observer ABCD and the
// gain K, using an integrator at the input to eliminate the
// steady state error
//
// sys: System
// obs: Observer
// K: state feedback gains
// Cy: matrix to extract the output for the steady state feedback

[larg,rarg]=argn(0);

if rarg ~= 4 then
	Cy = [1];
end

Ts = sys(7);

ny = size(sys.C,1);   // outputs
nu = size(sys.B,2);   // inputs
nx = size(sys.A,1);   // states
no = size(obs.A,1);   // observed states
ni = size(Cy,1);      // intgrated signals

B_obsu = obs.B(:,1:nu);
B_obsy = obs.B(:,nu+1:nu+ny);
D_obsu = obs.D(:,1:nu);
D_obsy = obs.D(:,nu+1:nu+ny);

Ke = K(:,$-ni+1:$);
K = K(:,1:$-ni);
X = inv(eye(nu,nu)+K*D_obsu);

A_ctr = [obs.A-B_obsu*X*K*obs.C, -B_obsu*X*Ke;  zeros(ni,no), eye(ni,ni)];
B_ctr = [zeros(no,ni) -B_obsu*X*K*D_obsy+B_obsy; eye(ni,ni)*Ts -Cy*Ts];
C_ctr = [-X*K*obs.C  -X*Ke];
D_ctr = [zeros(nu,ni) -X*K*D_obsy];

Contr = syslin(Ts,A_ctr,B_ctr,C_ctr,D_ctr);
endfunction

