function [in,fbk]=set_aw(Contr,p)
// Calculate system for anri-windup
// from controlle Contr

[larg,rarg]=argn(0);

[n,m]=size(Contr.A);
den=poly(spec(Contr.A),'z')
if rarg == 1 then
  tmp = syslin('d',den/z^n);
else
  d = poly(p,'z')
  tmp = syslin('d',den/d);
end

id=eye(n,m);

g_contr=Contr.C*inv(z*id-Contr.A)*Contr.B+Contr.D;

//g_contr=ss2tf(Contr)
fbk=syslin(Contr(7),1-tmp);
in =syslin(Contr(7),g_contr*tmp);

endfunction

