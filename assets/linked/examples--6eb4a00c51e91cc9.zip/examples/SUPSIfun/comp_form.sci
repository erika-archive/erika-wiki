function [Contr]=comp_form(sys,obs,K)
// Create the compact form of the Observer ABCD and the
// gain K, 
//
// sys: system
// obs: Observer
// K: state feedback gains

Ts = sys(7);

nx = size(sys.A,1);   // states
ny = size(sys.C,1);   // outputs
nu = size(sys.B,2);   // inputs
no = size(obs.A,1); // observed states

Bu = obs.B(:,1:nu);
By = obs.B(:,nu+1:$);
Du = obs.D(:,1:nu);
Dy = obs.D(:,nu+1:$);

X = inv(eye(nu,nu)+K*Du);

Ac = obs.A-Bu*X*K*obs.C;
Bc = [Bu*X,By-Bu*X*K*Dy]
Cc = -X*K*obs.C;
Dc = [X,-X*K*Dy]
Contr = syslin(Ts,Ac,Bc,Cc,Dc)

endfunction
