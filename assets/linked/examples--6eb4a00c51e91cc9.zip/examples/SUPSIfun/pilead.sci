function [ctr,K,Ti,alfa,Tl]=pilead(g,wgc,PM,Ti)

[larg,rarg]=argn(0);

if rarg ~= 4 then
  [frq1,rep] =repfreq(g,wgc/(2*pi));
  [db,phi]=dbphi(rep);

  tmpPM=phi+180;
  gpi=syslin('c',(1+s)/s);
  frq=bode2freq(gpi,-tmpPM,0.01/(2*pi),100/(2*pi),'phi');
  Ti=2*pi*frq/wgc;
end

gpi=syslin('c',(1+s*Ti)/(s*Ti));
[frq1,rep] =repfreq(gpi*g,wgc/(2*pi));
[db,phi]=dbphi(rep);

tmpPM=phi+180;

DPMr=(PM-tmpPM)/180*pi;
alfa=(1+sin(DPMr))/(1-sin(DPMr));
Tl=1/sqrt(alfa)/wgc;
glead=syslin('c',(1+alfa*s*Tl)/(1+s*Tl));

[frq1,rep] =repfreq(gpi*glead*g,wgc/(2*pi));
[db,phi]=dbphi(rep);

K=10^(-db/20);
ctr=K*gpi*glead;
endfunction
