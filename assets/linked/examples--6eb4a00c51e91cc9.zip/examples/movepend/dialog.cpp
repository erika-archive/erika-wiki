#include "dialog.h"
#include "ui_dialog.h"
#include <stdio.h>
#include <fcntl.h>

int fifo;

struct data{
  float u;
};

struct data val;

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    ui->Wheel->setRange(-100.0,100.0,0.1,2);

    if ((fifo = ::open("/dev/rtf0", O_WRONLY)) < 0) {
      printf("Fifo cannot be opened!\n");
      exit(1);
    }
}

Dialog::~Dialog()
{
    delete ui;
    ::close(fifo);
}

void Dialog::changeEvent(QEvent *e)
{
    QDialog::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

void Dialog::on_Wheel_valueChanged(double value)
{
    val.u=(float) value/100;
    write(fifo, &val, sizeof(val));
}
