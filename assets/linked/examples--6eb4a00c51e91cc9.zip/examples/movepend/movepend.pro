#-------------------------------------------------
#
# Project created by QtCreator 2010-04-16T16:24:26
#
#-------------------------------------------------

TARGET = movepend
TEMPLATE = app

INCLUDEPATH += /usr/include/qwt-qt4
DEPENDPATH  += /usr/include/qwt-qt4

SOURCES += main.cpp\
        dialog.cpp

HEADERS  += dialog.h

QWTLIB = qwt
LIBS += -l qwt-qt4

FORMS    += dialog.ui
