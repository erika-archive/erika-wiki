#include <machine.h>
#include <scicos_block4.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef double * pDouble;

struct meanSig{
  int channels;
  int npoints;
  int nWait;
  char fName[30];
  pDouble * sign;
  pDouble * sigm;
  int cnt;
  int nsets;
};

static void init(scicos_block *block)
{
  struct meanSig * sig = (struct meanSig *) malloc(sizeof(struct meanSig));
  int i;
  int nch=block->nin;
  int npts=block->ipar[0];
  int nWait=block->ipar[1];
  char sName[15];

  par_getstr(sName,block->ipar,3,block->ipar[2]);
  sig->channels=nch;
  strcpy(sig->fName,sName);

  sig->sign=(pDouble *) calloc(nch,sizeof(double *));
  sig->sigm=(pDouble *) calloc(nch,sizeof(double *));
  for(i=0;i<nch;i++){
    sig->sign[i]=(double *)calloc(npts,sizeof(double));
    sig->sigm[i]=(double *)calloc(npts,sizeof(double));
  }
  sig->nWait=nWait;
  sig->npoints=npts;
  sig->cnt=0;
  sig->nsets=0;

  *block->work=  (void *) sig;
}

static void inout(scicos_block *block)
{
  struct meanSig * sig = (struct meanSig *) *block->work;
  int i;
  double *y;

  if(sig->nWait == 0) {
    for(i=0;i<sig->channels;i++){
      y = block->inptr[i];
      sig->sign[i][sig->cnt]=y[0];
      sig->sigm[i][sig->cnt]+=y[0];
    }
    sig->cnt=(sig->cnt+1) % sig->npoints;
    if (sig->cnt==0) sig->nsets++;
  }
  else{
    sig->cnt = (sig->cnt+1) % sig->npoints;
    if (sig->cnt==0) sig->nWait--;
  }
}

static void end(scicos_block *block)
{
  struct meanSig * sig = (struct meanSig *) *block->work;
  int i,j;
  FILE * fp;

  if(sig->nsets != 0) {
    for(i=0;i<sig->channels;i++){
      for(j=0;j<sig->cnt;j++) {
        sig->sigm[i][j]-=sig->sign[i][j];
      }
    }
    fp=fopen(sig->fName,"w");
    if(fp!=NULL){
      for(i=0;i<sig->npoints;i++) {
        for(j=0;j<sig->channels;j++) {
          fprintf(fp,"%lf\t",sig->sigm[j][i]/sig->nsets);
        }
        fprintf(fp,"\n");
      }
      fclose(fp);
    }
    printf("Mean applied to %d set of signals\n",sig->nsets);
    printf("File %s closed\n",sig->fName);
    free(sig->sign);
    free(sig->sigm);
    free(sig);
  }
}

void rt_meansignals(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


