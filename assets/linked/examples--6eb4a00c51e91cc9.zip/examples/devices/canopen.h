void set_msg_flag(int v);
void sendMsg(WORD ID, BYTE DATA[], int len);
int canOpen(int interface, int baudrate, int port, int irq);
int register_pdo(int id, int PDOn);

int get_1b_signed_val(int id, int PDOn, int pos);
unsigned int get_1b_unsigned_val(int id, int PDOn, int pos);
int get_2b_signed_val(int id, int PDOn, int pos);
unsigned int get_2b_unsigned_val(int id, int PDOn, int pos);
int get_4b_signed_val(int id, int PDOn, int pos);
unsigned int get_4b_unsigned_val(int id, int PDOn, int pos);


void canClose();
