/*
COPYRIGHT (C) 2007  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <stdio.h>
#include <can_common.h>
#include <pcan.h>
#include <libpcan.h>
#include <canopen.h>
#include <unistd.h>

static BYTE data[8][8]= {
  {0x22, 0x40, 0x60, 0x00, 0x80, 0x00, 0x00, 0x00},
  {0x22, 0x40, 0x60, 0x00, 0x06, 0x00, 0x00, 0x00},
  {0x22, 0x40, 0x60, 0x00, 0x07, 0x00, 0x00, 0x00},
  {0x22, 0x40, 0x60, 0x00, 0x0F, 0x00, 0x00, 0x00},
  {0x22, 0xFB, 0x60, 0x01, 0x00, 0x00, 0x00, 0x00},
  {0x22, 0xFB, 0x60, 0x02, 0x00, 0x00, 0x00, 0x00},
  {0x22, 0xFB, 0x60, 0x03, 0x00, 0x00, 0x00, 0x00},
  {0x22, 0x60, 0x60, 0x00, 0xFF, 0x00, 0x00, 0x00},
};

static BYTE PDO[5][8]= {
  {0x22, 0x00, 0x14, 0x01, 0x00, 0x02, 0x00, 0x40},
  {0x22, 0x00, 0x14, 0x02, 0x01, 0x00, 0x00, 0x00},
  {0x22, 0x00, 0x16, 0x00, 0x00, 0x00, 0x00, 0x00},
  {0x22, 0x00, 0x16, 0x01, 0x20, 0x00, 0x62, 0x20},
  {0x22, 0x00, 0x16, 0x00, 0x01, 0x00, 0x00, 0x00},
};

static BYTE NMT_pre[2]  = {0x80, 0x00};
static BYTE NMT_act[2]  = {0x01, 0x00};
static BYTE position[4] = {0x00, 0x00, 0x00, 0x00};

void exit_on_error();

static void init(scicos_block *block)
{
  int i;

  if(canOpen(block->ipar[1], block->ipar[3], block->ipar[2], block->ipar[4])) exit_on_error();

  data[4][4]=(0x000000FF & (int) block->rpar[0]);
  data[4][5]=((0x0000FF00 & (int) block->rpar[0]) >> 8);
  data[5][4]=(0x000000FF & (int) block->rpar[1]);
  data[5][5]=((0x0000FF00 & (int) block->rpar[1]) >> 8);
  data[6][4]=(0x000000FF & (int) block->rpar[2]);
  data[6][5]=((0x0000FF00 & (int) block->rpar[2]) >> 8);

  PDO[0][4]  = (BYTE) block->ipar[0];
  NMT_pre[1] = (BYTE) block->ipar[0];
  NMT_act[1] = (BYTE) block->ipar[0];

  sendMsg(0x000,NMT_pre,2);

  for(i=0;i<5;i++){
    sendMsg(0x600+block->ipar[0],PDO[i],8);
    usleep(100000);
  }

  for(i=0;i<8;i++){
    sendMsg(0x600+block->ipar[0],data[i],8);
    usleep(10000);
  }

  sendMsg(0x000,NMT_act,2);
}

static void inout(scicos_block *block)
{
  int Pos_can;
  double *u = block->inptr[0];

  Pos_can = (int) u[0];

  position[0]=(BYTE)Pos_can;
  position[1]=(BYTE)(Pos_can>>8);
  position[2]=(BYTE)(Pos_can>>16);
  position[3]=(BYTE)(Pos_can>>24);

  sendMsg(0x200+block->ipar[0],position,4);
}

static void end(scicos_block *block)
{  
  canClose();
}

void rt_epos_canopen_motX(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


