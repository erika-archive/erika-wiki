/*
COPYRIGHT (C) 2009  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <can_common.h>
#include <pcan.h>
#include <libpcan.h>
#include <canopen.h>
#include <unistd.h>
#include <rtai_sem.h>

static BYTE data[7][8]= {
  {0x22, 0x40, 0x60, 0x00, 0x80, 0x00, 0x00, 0x00},
  {0x22, 0x40, 0x60, 0x00, 0x06, 0x00, 0x00, 0x00},
  {0x22, 0x40, 0x60, 0x00, 0x07, 0x00, 0x00, 0x00},
  {0x22, 0x40, 0x60, 0x00, 0x0F, 0x00, 0x00, 0x00},
  {0x40, 0x61, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00},
  {0x22, 0x60, 0x60, 0x00, 0xFD, 0x00, 0x00, 0x00},
};

/* RX PDO                                   */
/* PDO2     AO AO                           */
/*                                          */
/* AO  : analog aoutput                     */

static BYTE PDO[5][8]= {
  {0x22, 0x01, 0x14, 0x01, 0x00, 0x03, 0x00, 0x40},
  {0x22, 0x01, 0x14, 0x02, 0x01, 0x00, 0x00, 0x00},
  {0x22, 0x01, 0x16, 0x00, 0x00, 0x00, 0x00, 0x00},
  {0x22, 0x01, 0x16, 0x01, 0x10, 0x00, 0x7E, 0x20},
  {0x22, 0x01, 0x16, 0x00, 0x01, 0x00, 0x00, 0x00},
};

static BYTE NMT_pre[2]  = {0x80, 0x00};
static BYTE NMT_act[2]  = {0x01, 0x00};
static BYTE a_out[2]    = {0x00, 0x00};

void exit_on_error();

static SEM* msgsem;
extern BYTE lastSDOack[8];

static void init(scicos_block *block)
{
  int i;

  if(canOpen(block->ipar[1], block->ipar[3], block->ipar[2], block->ipar[4])) exit_on_error();

  msgsem = rt_typed_named_sem_init("MSGS", 0, CNT_SEM);
  if(msgsem == NULL) {
    fprintf(stderr, "Error in getting MSGS semaphore address\n");
    exit_on_error();
  }

  PDO[0][4]  = (BYTE) block->ipar[0];   /* COB for PDO2  */
  NMT_pre[1] = (BYTE) block->ipar[0];
  NMT_act[1] = (BYTE) block->ipar[0];

  sendMsg(0x000,NMT_pre,2);
  usleep(100000);
  for(i=0;i<4;i++){
    sendMsg(0x600+block->ipar[0],PDO[i],8);   /* configure PDO */
    usleep(100000);
  }

  set_msg_flag(1);
  sendMsg(0x600+block->ipar[0],data[4],8); /* Configure CAN device */
  usleep(10000);
  rt_sem_wait(msgsem);
  data[5][4] = lastSDOack[4];    /* set operational modus  */

  sendMsg(0x600+block->ipar[0],data[5],8);

  sendMsg(0x000,NMT_act,2);   /* operastional status */
  usleep(100000);
}

static void inout(scicos_block *block)
{
  unsigned short int U_can;
  double *u = block->inptr[0];

  U_can = (unsigned short int) (u[0]*1000);
  a_out[0] = (BYTE) (U_can & 0xFF);
  a_out[1] = (BYTE)((U_can>>8) & 0xFF);
  sendMsg(0x300+block->ipar[0],a_out,2);
}

static void end(scicos_block *block)
{
  rt_named_sem_delete(msgsem);
  a_out[0] = 0x00;
  a_out[1] = 0x00;
  sendMsg(0x300+block->ipar[0],a_out,2);
  usleep(10000);
  sendMsg(0x80,NULL,0);
  usleep(100000);
  
  canClose();
}

void rt_epos_canopen_awrite(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


