/*
COPYRIGHT (C) 2007  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <can_common.h>
#include <pcan.h>
#include <libpcan.h>
#include <canopen.h>

#define DATA_SIZE 5

static BYTE data[DATA_SIZE][8]= {
  {0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
  {0x00, 0x15, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00},
  {0x00, 0x15, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00},
  {0x00, 0x15, 0x88, 0x00, 0x01, 0x00, 0x00, 0x00},
  {0x00, 0x05, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00}
};

static BYTE write_req[8]={0x00,0x22,0x00,0x00,0x00,0x00,0x00,0x00};

void exit_on_error();

static void init(scicos_block *block)
{
  int i;

  if(canOpen(block->ipar[1], block->ipar[3], block->ipar[2], block->ipar[4])) exit_on_error();

  data[1][6]=(BYTE) (0x000000FF & (int) block->rpar[0]);
  data[1][7]=(BYTE) ((0x0000FF00 & (int) block->rpar[0]) >> 8);
  data[2][6]=(BYTE) (0x000000FF & (int) block->rpar[1]);
  data[2][7]=(BYTE) ((0x0000FF00 & (int) block->rpar[1]) >> 8);

  for(i=0;i<DATA_SIZE;i++){
    sendMsg(0x600+block->ipar[0],data[i],8);   /* SPDO */
    usleep(100000);
  }
}

static void inout(scicos_block *block)
{
  BYTE DATA[8];
  int U_can;
  double *u = block->inptr[0];
  int ret;

  U_can = (int) u[0];

  write_req[2]=(BYTE)U_can;
  write_req[3]=(BYTE)(U_can>>8);

  sendMsg(0x600+block->ipar[0],write_req,8);
}

static void end(scicos_block *block)
{
  BYTE DATA[8];
  int ret;

  write_req[2]=0x00;
  write_req[3]=0x00;
  sendMsg(0x600+block->ipar[0],write_req,8);

  canClose();
  printf("Maxon Motor at 0x%x closed\n",block->ipar[0]);
}

void rt_maxon_mot(scicos_block *block,int flag)
{
  if (flag==1){          /* get the input */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


