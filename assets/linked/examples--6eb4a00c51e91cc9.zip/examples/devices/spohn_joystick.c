/*
COPYRIGHT (C) 2007  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <stdio.h>
#include <can_common.h>
#include <pcan.h>
#include <libpcan.h>
#include <canopen.h>


//Transmit PDO for trigger button, red/black button and X-Y axes
static BYTE TPDO[7][8]= {
  {0x22, 0x00, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00},
  {0x22, 0x00, 0x1A, 0x01, 0x08, 0x03, 0x00, 0x60},
  {0x22, 0x00, 0x1A, 0x00, 0x01, 0x00, 0x00, 0x00},
  {0x22, 0x01, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00},
  {0x22, 0x01, 0x1A, 0x01, 0x08, 0x01, 0x01, 0x64},
  {0x22, 0x01, 0x1A, 0x02, 0x08, 0x02, 0x01, 0x64}, 
  {0x22, 0x01, 0x1A, 0x00, 0x02, 0x00, 0x00, 0x00}
};

//Type of comunication (sync)
static BYTE data[2][8]= {
  {0x22, 0x00, 0x18, 0x02, 0xF0, 0x00, 0x00, 0x00},
  {0x22, 0x01, 0x18, 0x02, 0xF0, 0x00, 0x00, 0x00},
};

static BYTE NMT_pre[2]  = {0x80, 0x00};
static BYTE NMT_act[2]  = {0x01, 0x00};

int x=0;

void exit_on_error();

static void init(scicos_block *block)
{
  int i;

  if(canOpen(block->ipar[1], block->ipar[3], block->ipar[2], block->ipar[4])) exit_on_error();

  NMT_pre[1] = (BYTE) block->ipar[0];
  NMT_act[1] = (BYTE) block->ipar[0];
  

  sendMsg(0x000,NMT_pre,2);
  for(i=0;i<7;i++){
    sendMsg(0x600+block->ipar[0],TPDO[i],8);
    usleep(10000);
  }

  for(i=0;i<2;i++){
    sendMsg(0x600+block->ipar[0],data[i],8);
    usleep(10000);
  }

  sendMsg(0x000,NMT_act,2);

  register_pdo(block->ipar[0],1);
  register_pdo(block->ipar[0],2);
}

static void inout(scicos_block *block)
{
  int button;

  double *black = block->outptr[0];
  double *red = block->outptr[1];
  double *trigger = block->outptr[2];
  double *X_axis = block->outptr[3];
  double *Y_axis = block->outptr[4];


  button = get_1b_signed_val(block->ipar[0], 1, 0);
	
	
  if(button == 1) black[0]=1;
  else if(button == 2) red[0]=1;
  else if(button == 8) 
	{
	if((trigger[0]==0) && (x==0)) trigger[0]=1;
	if((trigger[0]==1) && (x==1)) trigger[0]=0;	
	}

  else
	{
	black[0]=0;
	red[0]=0;
	if(trigger[0]==1) x=1;
	if(trigger[0]==0) x=0;
	}

  Y_axis[0] = get_2b_signed_val(block->ipar[0], 2, 0);
  X_axis[0] = get_2b_signed_val(block->ipar[0], 2, 2);
}

static void end(scicos_block *block)
{ 
  canClose();
}

void rt_spohn_joystick(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


