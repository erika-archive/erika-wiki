/*
COPYRIGHT (C) 2009  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <stdio.h>
#include <can_common.h>
#include <pcan.h>
#include <libpcan.h>
#include <canopen.h>

/* TX PDO   380H + ID                       */
/* PDO3     X   X   X    X    P   P   X   X */
/*                                          */
/* P    : position                          */

static BYTE read_req[8]={0x40,0x04,0x60,0x00,0x00,0x00,0x00,0x00};

void exit_on_error();

static void init(scicos_block *block)
{
  if(canOpen(block->ipar[1], block->ipar[3], block->ipar[2], block->ipar[4])) exit_on_error();

  register_pdo(block->ipar[0],3);   /* Map PDOs */
}

static void inout(scicos_block *block)
{
  double pi2 = 6.28318530718;
  int counter;
  double *y = block->outptr[0];

  sendMsg(0x380+block->ipar[0],read_req,8);
  counter = get_2b_signed_val(block->ipar[0],3,4);

  y[0] = pi2*counter/block->rpar[0];
}

static void end(scicos_block *block)
{
  canClose();
}

void rt_encoder_baumer(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag==4){    /* initialisation */
    init(block);
  }
}


