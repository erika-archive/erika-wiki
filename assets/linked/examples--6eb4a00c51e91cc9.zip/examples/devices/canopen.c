#include <pthread.h>
#include <rtai_lxrt.h>
#include <rtai_sem.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <can_common.h>
#include <pcan.h>
#include <libpcan.h>
#include <sys/mman.h>

/* The verbode flag allows to send all the messages to a display application */
/* using the FIFO 15                                                         */

/* #define VERB */

#ifdef VERB
#define FIFON 15
#include <rtai_fifos.h>
#endif

#define PRIO 1               /* Priority of the receiving thread  */

BYTE * PDO0[128] = {NULL};   /* Memory reserved for TX PDO1 */
BYTE * PDO1[128] = {NULL};   /* Memory reserved for TX PDO2 */
BYTE * PDO2[128] = {NULL};   /* Memory reserved for TX PDO3 */

int (*sendFun)(HANDLE , TPCANMsg*);
int (*recvFun)(HANDLE , TPCANMsg*);
int (*statFun)(HANDLE);

BYTE lastSDOack[8];          /* When msg_flag is set this array contains the las received message */

static int msg_flag = 0;
static SEM* msgsem;

static void * canHandle;
static int dev_cnt = 0;      /* CAN devices counter */

static volatile int endrcv = 0;

static pthread_t  rt_rcv;
static RT_TASK    *rt_RcvTask;

void set_msg_flag(int v)
{
  msg_flag = v;
}

BYTE * get_PDO(int PDOn,int id)
{
  switch(PDOn){
  case 1:
    return(PDO0[id]);
    break;
  case 2:
    return(PDO1[id]);
    break;
  case 3:
    return(PDO2[id]);
    break;
  }
  return(NULL);
}


void sendMsg(WORD ID, BYTE DATA[], int len)
{
  /* Procedure to send a CAN message */

  TPCANMsg Tmsg;

  Tmsg.ID = ID;
  Tmsg.MSGTYPE = MSGTYPE_STANDARD;
  Tmsg.LEN = len;
  int i, errno;

  for(i=0;i<len;i++) Tmsg.DATA[i] = DATA[i];
#ifdef VERB
  rtf_put(FIFON,&Tmsg,sizeof(Tmsg));
#endif

  errno = sendFun(canHandle,&Tmsg);
}

void *rcv(void *args)
{
  /* Receiving thread scheduled as RTAI task */

  TPCANMsg m;
  int errno;
#ifdef VERB
  unsigned char DATA[8];
  int i;
#endif
  int id, PDOn;
  BYTE * data;

  if (!(rt_RcvTask = rt_task_init_schmod(nam2num("RCV"), PRIO, 0, 0, SCHED_FIFO, 0xF))) {
    fprintf(stderr,"Cannot init rt_RcvTask.\n");
    return (void *)1;
  }

  rt_task_use_fpu(rt_RcvTask, 1);
  mlockall(MCL_CURRENT | MCL_FUTURE);
  rt_make_hard_real_time();

  while (!endrcv) {       /* receiving loop */
    errno = recvFun(canHandle, &m);

#ifdef VERB
    rtf_put(FIFON,&m,sizeof(m));
#endif

    /* Store PDO messages  */
    if(m.ID==0x7FF) m.ID=0x3FF;

    if((m.ID>=0x180) && (m.ID<=0x3FF)){    
      PDOn = (m.ID >> 8) & 0x0F;
      id   = (m.ID & 0xFF) - 0x80;

      data = get_PDO(PDOn,id);
      if (data!=NULL) memcpy(data,m.DATA,m.LEN);
    }
    else{
      if(msg_flag){
	memcpy(lastSDOack,m.DATA,m.LEN);
	rt_sem_signal(msgsem);
	msg_flag=0;
      }
    }
    if(m.MSGTYPE & MSGTYPE_STATUS) statFun(canHandle);

  }
  rt_make_soft_real_time();
  return 0;
}

int canOpen(int interface, int baudrate, int port, int irq)
{
  /* CAN initialization */

  int bd;
  char txt[VERSIONSTRING_LEN];
  int priority = 0;

  if(!dev_cnt){  /* This task is performed only one time */
#ifdef VERB
    rtf_create(FIFON,50000);   /* FIFO for debugging messages */
    rtf_reset(FIFON);
#endif
    msgsem = rt_typed_named_sem_init("MSGS", 0, CNT_SEM);
    if(msgsem == NULL) {
      fprintf(stderr, "Error in getting MSGS semaphore address\n");
      exit(0);
    }

    switch(interface){
    case 1:
    case 2:
      switch(baudrate){
      case 1:
	bd = CAN_BAUD_1M;
	break;
      case 2:
	bd = CAN_BAUD_500K;
	break;
      default:
	bd = CAN_BAUD_500K;
	break;
      }
      sendFun = CAN_Write;   /* This allows in the future to have more CAN interfaces */
      recvFun = CAN_Read;
      statFun = CAN_Status;
      canHandle = CAN_Open(HW_DONGLE_SJA_EPP, port,irq);
      if(!canHandle) return -1;
      CAN_VersionInfo(canHandle,txt);
      CAN_Init(canHandle, bd, CAN_INIT_TYPE_ST);
     break;
    default:
      exit(0);
    }
    pthread_create(&rt_rcv, NULL, rcv, &priority);  /* Start receiving task */
  }
  dev_cnt++;
  printf("Init CAN end\n");
  return 0;
}

int register_pdo(int id, int PDOn)
{
  /* This procedure allows to allocate the memory for the registered PDO's */
  int i;
  BYTE * data;

  data = malloc(8*sizeof(BYTE));
  for(i=0;i<8;i++) data[i]=0;
  switch(PDOn){
  case 1:
    PDO0[id] = data;
    break;
  case 2:
    PDO1[id] = data;
    break;
  case 3:
    PDO2[id] = data;
    break;
  }
  return(0);
}

void canClose()
{
  if(--dev_cnt == 0) {
    endrcv = 1;
    CAN_Close(canHandle);
    rt_named_sem_delete(msgsem);
    rt_task_delete(rt_RcvTask);
#ifdef VERB
    rtf_destroy(FIFON);
#endif

  }
}

/* The following 8 functions allows to read N (1, 2 or 4) */
/* signed or unsigned bytes from a saved PDO message    */ 

int get_1b_signed_val(int id, int PDOn, int pos)
{
  BYTE * data;
  char counter;
  counter = 0;

  data = get_PDO(PDOn,id);
  counter = data[pos];
  return ((int) counter);
}

unsigned int get_1b_unsigned_val(int id, int PDOn, int pos)
{
  BYTE * data;
  unsigned char counter;
  counter = 0;

  data = get_PDO(PDOn,id);
  counter = data[pos];
  return ((unsigned int) counter);

}

int get_2b_signed_val(int id, int PDOn, int pos)
{
  BYTE * data;
  short int counter;
  int i;
  counter = 0;

  data = get_PDO(PDOn,id);
  for(i=pos+1;i>=pos;i--) counter = (counter << 8) + data[i];
  return ((int) counter);
}

unsigned int get_2b_unsigned_val(int id, int PDOn, int pos)
{
  BYTE * data;
  short unsigned int counter;
  int i;
  counter = 0;

  data = get_PDO(PDOn,id);
  for(i=pos+1;i>=pos;i--) counter = (counter << 8) + data[i];
  return ((unsigned int) counter);

}

int get_4b_signed_val(int id, int PDOn, int pos)
{
  BYTE * data;
  int counter;
  int i;
  counter = 0;

  data = get_PDO(PDOn,id);
  for(i=pos+3;i>=pos;i--) counter = (counter << 8) + data[i];
  return (counter);
}

unsigned int get_4b_unsigned_val(int id, int PDOn, int pos)
{
  BYTE * data;
  unsigned int counter;
  int i;
  counter = 0;

  data = get_PDO(PDOn,id);
  for(i=pos+3;i>=pos;i--) counter = (counter << 8) + data[i];
  return (counter);

}

