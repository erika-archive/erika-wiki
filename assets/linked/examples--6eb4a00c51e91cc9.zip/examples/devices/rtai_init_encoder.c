#include <machine.h>
#include <scicos_block4.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double get_scicos_time();

static void init(scicos_block *block)
{
}

static void inout(scicos_block *block)
{
  double *y = block->outptr[0];
  double *u = block->inptr[0];

  double t=get_scicos_time();
  if (t >= block->rpar[0]) 
    y[0] = u[0]-block->rpar[2]-block->rpar[3];
  else {
    block->rpar[3] = u[0];
    y[0] = block->rpar[1];
  }

}

static void end(scicos_block *block)
{
  printf("Init Encoder closed\n");
}



void rt_init_encoder(scicos_block *block,int flag)
{
  if (flag==1){          /* get input */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


