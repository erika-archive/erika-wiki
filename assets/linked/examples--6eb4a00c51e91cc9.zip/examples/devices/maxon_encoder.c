/*
COPYRIGHT (C) 2009  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <can_common.h>
#include <pcan.h>
#include <libpcan.h>
#include <canopen.h>
#include <rtai_sem.h>

static BYTE data[8]={0x00, 0x05, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00};
static BYTE read_req[8]={0x00,0x14,0x88,0x00,0x01,0x00,0x00,0x00};

void exit_on_error();

static SEM* msgsem;
extern BYTE lastSDOack[8];

static void init(scicos_block *block)
{
  int i;

  if(canOpen(block->ipar[1], block->ipar[3], block->ipar[2], block->ipar[4])) exit_on_error();

  msgsem = rt_typed_named_sem_init("MSGS", 0, CNT_SEM);
  if(msgsem == NULL) {
    fprintf(stderr, "Error in getting MSGS semaphore address\n");
    exit_on_error();
  }

  sendMsg(0x600+block->ipar[0],data,8); /* Configure CAN device */
}  

static void inout(scicos_block *block)
{
  BYTE DATA[8];
  double pi2 =  6.28318530718;
  int counter;
  double *y = block->outptr[0];

  set_msg_flag(1);
  sendMsg(0x600+block->ipar[0],read_req,8);
  rt_sem_wait(msgsem);
  counter=(lastSDOack[3] << 24)  + (lastSDOack[2] << 16) + (lastSDOack[5] << 8) + lastSDOack[4];
  y[0]= pi2*counter/block->rpar[0];
}

static void end(scicos_block *block)
{
  rt_named_sem_delete(msgsem);
  canClose();
}

void rt_maxon_encoder(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


