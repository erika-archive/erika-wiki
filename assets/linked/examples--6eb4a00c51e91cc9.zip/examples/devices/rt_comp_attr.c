/*
COPYRIGHT (C) 2010  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <math.h>

void par_getstr(char * str, int par[], int init, int len);

static void init(scicos_block *block)
{
}

static void inout(scicos_block *block)
{
  double * rpar =  GetRparPtrs(block);

  double *u = GetRealInPortPtrs(block,1);
  double *y = GetRealOutPortPtrs(block,1);

  double Izero = rpar[0];
  double Idead = rpar[1];
  double sign;
  double absu;

  if(u[0] >= 0.0) sign = 1;
     else         sign = -1;

  absu = fabs(u[0]);
  if ((absu > Idead) && (absu < Izero)) y[0] = Izero * sign;
  else if(absu > Izero)                 y[0] = u[0];
  else                                  y[0] = u[0]/Idead*Izero;
}

static void end(scicos_block *block)
{
}

void rt_comp_attr(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


