/*
COPYRIGHT (C) 2007  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <stdio.h>
#include <machine.h>
#include <scicos_block4.h>

void par_getstr(char * str, int par[], int init, int len);

static void init(scicos_block *block)
{
  int nin  = GetNin(block);
  int nout = GetNout(block);
  int * ipar = GetIparPtrs(block);
  double * rpar =  GetRparPtrs(block);
  int i;

  double *u;

  for(i=0;i<nin;i++) {
    u=block->inptr[i];
    printf("%lf  ",u[0]);
  }
  printf("\n");
}

static void inout(scicos_block *block)
{
  int nin  = GetNin(block);
  int nout = GetNout(block);
  int * ipar = GetIparPtrs(block);
  double * rpar =  GetRparPtrs(block);
  int i;

  double *u;

  for(i=0;i<nin;i++) {
    u=block->inptr[i];
    printf("%lf  ",u[0]);
  }
  printf("\n");
}

static void end(scicos_block *block)
{
  int nin  = GetNin(block);
  int nout = GetNout(block);
  int * ipar = GetIparPtrs(block);
  double * rpar =  GetRparPtrs(block);
  int i;

  double *u;

  for(i=0;i<nin;i++) {
    u=block->inptr[i];
    printf("%lf  ",u[0]);
  }
  printf("\n");
}

void rt_print(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


