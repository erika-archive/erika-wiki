/*
COPYRIGHT (C) 2007  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <sys/io.h>

static void init(scicos_block *block)
{
  block->ipar[0]=block->ipar[0];
}

static void inout(scicos_block *block)
{
  double * u = block->inptr[0];
  unsigned char val;

  val = inb(block->ipar[1]);

  if (u[0] > 0) val |= (0x01 << block->ipar[0]);
  else          val &= ~(0x01 << block->ipar[0]);
  outb(val,block->ipar[1]);
}

static void end(scicos_block *block)
{
  outb(0x00,block->ipar[1]);
}

void rt_pport_out(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


