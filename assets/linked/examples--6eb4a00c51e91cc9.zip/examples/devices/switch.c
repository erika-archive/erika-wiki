/*
COPYRIGHT (C) 2007  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <math.h>

static void init(scicos_block *block)
{
  block->ipar[1]=0;
}

static void inout(scicos_block *block)
{
  double * in1 = (double*) block->inptr[0];
  double * in2 = (double*) block->inptr[1];
  double * val = (double*) block->inptr[2];
  double * y   = (double*) block->outptr[0];

  double t = get_scicos_time();

  if(block->ipar[1]) {
    y[0]=in2[0];
  }
  else{
    if(t>block->rpar[1]) {
      switch(block->ipar[0]){
      case 0:
	if(val[0] < block->rpar[0]) {
	  y[0]=in1[0];
	}
	else{
	  y[0]=in2[0];
	  block->ipar[1]=1;  
	}
	break;
      case 1:
	if(val[0] > block->rpar[0]) {
	  y[0]=in1[0];
	}
	else{
	  y[0]=in2[0];
	  block->ipar[1]=1;  
	}
	break;
      }
    }
  }
}

static void end(scicos_block *block)
{
}

void rt_switch(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag ==4){    /* initialisation */
    init(block);
  }
}


