/*
COPYRIGHT (C) 2009  Roberto Bucher (roberto.bucher@supsi.ch)

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
*/

#include <machine.h>
#include <scicos_block4.h>
#include <sys/mman.h>
#include <pthread.h>
#include <can_common.h>
#include <libpcan.h>
#include <canopen.h>

void exit_on_error();

static void init(scicos_block *block)
{
  if(canOpen(block->ipar[0], block->ipar[2], block->ipar[1], block->ipar[3])) exit_on_error();

}

static void inout(scicos_block *block)
{
/*   printf("Sending...\n"); */
  sendMsg(0x80,NULL,0);
}

static void end(scicos_block *block)
{
  canClose();
}

void rt_epos_canopen_sync(scicos_block *block,int flag)
{
  if (flag==1){          /* set output */
    inout(block);
  }
  else if (flag==5){     /* termination */ 
    end(block);
  }
  else if (flag==4){    /* initialisation */
    init(block);
  }
}


