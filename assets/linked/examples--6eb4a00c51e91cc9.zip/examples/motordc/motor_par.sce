// Flags
plot_flag = 0;
fname='ID_MOT';

// Identification from step answer
x=read(fname,-1,2);
t=x(:,1);
y=x(:,2);
t=t(1000:$);
t=t-t(1);
y=y(1000:$);
y=y-y(1);
if plot_flag then
  xbasc()
  plot(t,y)
end

function z=fun(p,t,y)
z=y+p(1)/p(2)^2-p(1)/p(2)*t-p(1)/p(2)^2*exp(-p(2)*t);
endfunction

p0=[1,4];
Uo=500;

[ff,p]=leastsq(list(fun,t,y/Uo),p0);

g=syslin('c',p(1)/(s*(s+p(2))));

if plot_flag==1 then
  xbasc()
  bb_step(Uo*g,3.8)
  plot(t,y)
end

Kt = 126e-6;
Jm = Kt/p(1);
Dm = p(2)*Jm;
