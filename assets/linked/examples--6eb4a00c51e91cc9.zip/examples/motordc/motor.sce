// Continuous-time model of system
gc = syslin('c',(Kt/Jm)/(s*(s+Dm/Jm)));

Ts=1e-3;                // Sampling time [s]
g_ss=tf2ss(gc);         // state space form
a=[0,1;0,-Dm/Jm];
b=[0;1]
c=[Kt/Jm,0];
d=0;
g_ss=syslin('c',a,b,c,d);
g_dss=dscr(g_ss,Ts);    // discrete state space form

// Control design 
// Definition of closed-loop poles
wn = 15;
xi = 0.9;

s=%s;

cl_poly = s^2+2*xi*wn*s+wn^2;
cl_poles = roots(cl_poly);
cl_poles_d = exp(cl_poles*Ts);

[A,B,C,D]=abcd(g_dss);
ny=size(C,1);
nx=size(A,1);
nu=size(B,2);
no=nx;
// State-feedback gains 
K=ppol(A,B,cl_poles_d);

// Poles for state feedback with integrator
policar = (s+wn)*(s^2+2*xi*wn*s+wn^2);
p_c=roots(policar);

p_d=exp(p_c*Ts);
[Phi,G,C,D]=abcd(g_dss);

[m1,n1]=size(Phi);
[m2,n2]=size(G);
Phi_f=[Phi,zeros(m1,1);-C(1,:)*Ts,1];
G_f=[G;zeros(1,n2)];

// Pole placement
k=ppol(Phi_f,G_f,p_d);

// Definition of poles for reduced-order observer
p_oc=10*(p_c(1:2));
p_od=exp(p_oc*Ts);

// Design of the full-order observer
[Ao,Bo,Co,Do]=fullobs(Phi,G,C,D,p_od);

// Definition of poles for reduced-order observer
p_oc=-10*max(abs(p_c));
p_od=exp(p_oc*Ts);
T=[0,1];
[Ao,Bo,Co,Do]=redobs(Phi,G,C,D,T,p_od);
obs = syslin(Ts,Ao,Bo,Co,Do);

Contr=comp_form(g_dss,obs,k(1:2));
Contr(7)=Ts;

Contr=comp_form_i(g_dss,obs,k);
Contr(7)=Ts;

// Antiwindup for reduced order observer
Isat=1670;
[in,fbk] = set_aw(Contr,[0.1,0.1]);
gss_in=tf2ss(in);
gss_fbk=tf2ss(fbk);
