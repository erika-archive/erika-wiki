function [x,y,typ] = rtai_epos_canopen_sync(job,arg1,arg2)
  x=[];y=[];typ=[];
  select job
  case 'plot' then
    exprs=arg1.graphics.exprs;
    
    standard_draw(arg1)
  case 'getinputs' then
    [x,y,typ]=standard_inputs(arg1)
  case 'getoutputs' then
    [x,y,typ]=standard_outputs(arg1)
  case 'getorigin' then
    [x,y]=standard_origin(arg1)
  case 'set' then
    x=arg1
    model=arg1.model;graphics=arg1.graphics;
    exprs=graphics.exprs;
    while %t do
      [ok,interf,paddr,baudrate,irq,exprs]=..
      getvalue('Set SYNC data block parameters',..
      ['Interface:';
       'Port addr:';
       'Baudrate:';
       'Irq:'],..
      list('vec',-1,'str',1,'vec',-1,'vec',-1),exprs)
      if ~ok then break,end
      in=[],
      out=[],
      [model,graphics,ok]=check_io(model,graphics,in,out,1,[])
      if ok then
        graphics.exprs=exprs;
        model.rpar=[];
        model.ipar=[interf;hex2dec(strsubst(paddr,'0x',''));baudrate;irq];
        model.dstate=[];
        x.graphics=graphics;x.model=model
        break
      end
    end
  case 'define' then
    interf=1
    paddr='0x378'
    baudrate=2
    irq=5
    model=scicos_model()
    model.sim=list('rt_epos_canopen_sync',4)
    model.in=[],
    model.out=[],
    model.evtin=1
    model.rpar=[]
    model.ipar=[interf;hex2dec(strsubst(paddr,'0x',''));baudrate;irq]
    model.dstate=[];
    model.blocktype='d'
    model.dep_ut=[%t %f]
    exprs=[sci2exp(interf),paddr,sci2exp(baudrate),sci2exp(irq)]
    gr_i=['xstringb(orig(1),orig(2),[''Epos'';''canopen'';''sync''],sz(1),sz(2),''fill'');']
    x=standard_define([3 2],model,exprs,gr_i)
  end
endfunction
