function [x,y,typ] = rtai_pport_out(job,arg1,arg2)
  x=[];y=[];typ=[];
  select job
  case 'plot' then
    exprs=arg1.graphics.exprs;
    pinout=exprs(1)
    paddr=exprs(2)
    standard_draw(arg1)
  case 'getinputs' then
    [x,y,typ]=standard_inputs(arg1)
  case 'getoutputs' then
    [x,y,typ]=standard_outputs(arg1)
  case 'getorigin' then
    [x,y]=standard_origin(arg1)
  case 'set' then
    x=arg1
    model=arg1.model;graphics=arg1.graphics;
    exprs=graphics.exprs;
    while %t do
      [ok,pinout,paddr,exprs]=..
      getvalue('Set block parameters',..
      ['Parallel port PIN [0..7]:';
       'Parallel port Address'],..
      list('vec',-1,'str',1),exprs)
      if ~ok then break,end
      if exists('inport') then in=ones(inport,1), else in=1, end
      out=[]
      [model,graphics,ok]=check_io(model,graphics,in,out,1,[])

      if ok then
        graphics.exprs=exprs;
        model.rpar=[];
        model.ipar=[pinout;hex2dec(strsubst(paddr,'0x',''))];
        model.dstate=[];
        x.graphics=graphics;x.model=model
        break
      end
    end
  case 'define' then
    pinout=1
    paddr='0x378'
    model=scicos_model()
    model.sim=list('rt_pport_out',4)
    if exists('inport') then model.in=ones(inport,1), else model.in=1, end
    model.out=[]
    model.evtin=1
    model.rpar=[]
    model.ipar=[pinout;hex2dec(strsubst(paddr,'0x',''))]
    model.dstate=[];
    model.blocktype='d'
    model.dep_ut=[%t %f]
    exprs=[sci2exp(pinout),paddr]
    gr_i=['xstringb(orig(1),orig(2),[''Pport_out'' ; string(pinout) ; paddr],sz(1),sz(2),''fill'');']
    x=standard_define([3 2],model,exprs,gr_i)
  end
endfunction
