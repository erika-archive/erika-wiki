unix('ls -1 *.sci > x.x');
txt=mgetl('x.x');
create_gif(txt,'./gif_icons')
mdelete x.x

