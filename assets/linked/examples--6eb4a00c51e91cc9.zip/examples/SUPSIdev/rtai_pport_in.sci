function [x,y,typ] = rtai_pport_in(job,arg1,arg2)
  x=[];y=[];typ=[];
  select job
  case 'plot' then
    exprs=arg1.graphics.exprs;
    pinin=exprs(1)
    paddr=exprs(2)
    standard_draw(arg1)
  case 'getinputs' then
    [x,y,typ]=standard_inputs(arg1)
  case 'getoutputs' then
    [x,y,typ]=standard_outputs(arg1)
  case 'getorigin' then
    [x,y]=standard_origin(arg1)
  case 'set' then
    x=arg1
    model=arg1.model;graphics=arg1.graphics;
    exprs=graphics.exprs;
    while %t do
      [ok,pinin,paddr,exprs]=..
      getvalue('Set block parameters',..
      ['Parallel port Input [1...5]:';
       'Parallel port Address'],..
      list('vec',-1,'str',1),exprs)
      if ~ok then break,end
      in=[],
      if exists('outport') then out=ones(outport,1), else out=1, end
      [model,graphics,ok]=check_io(model,graphics,in,out,1,[])

      if ok then
        graphics.exprs=exprs;
        model.rpar=[];
        model.ipar=[pinin;hex2dec(strsubst(paddr,'0x',''))];
        model.dstate=[];
        x.graphics=graphics;x.model=model
        break
      end
    end
  case 'define' then
    pinin=1
    paddr='0x378'
    model=scicos_model()
    model.sim=list('rt_pport_in',4)
    model.in=[],
    if exists('outport') then model.out=ones(outport,1), else model.out=1, end
    model.evtin=1
    model.rpar=[]
    model.ipar=[pinin;hex2dec(strsubst(paddr,'0x',''))]
    model.dstate=[];
    model.blocktype='d'
    model.dep_ut=[%t %f]
    exprs=[sci2exp(pinin),paddr]
    gr_i=['xstringb(orig(1),orig(2),[''Pport_in'' ; string(pinin) ; paddr],sz(1),sz(2),''fill'');']
    x=standard_define([3 2],model,exprs,gr_i)
  end
endfunction
