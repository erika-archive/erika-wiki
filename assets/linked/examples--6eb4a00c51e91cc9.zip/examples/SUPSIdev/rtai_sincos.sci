function [x,y,typ] = rtai_sincos(job,arg1,arg2)
  x=[];y=[];typ=[];
  select job
  case 'plot' then
    exprs=arg1.graphics.exprs;
    addr=exprs(1)
    standard_draw(arg1)
  case 'getinputs' then
    [x,y,typ]=standard_inputs(arg1)
  case 'getoutputs' then
    [x,y,typ]=standard_outputs(arg1)
  case 'getorigin' then
    [x,y]=standard_origin(arg1)
  case 'set' then
    x=arg1
    model=arg1.model;graphics=arg1.graphics;
    exprs=graphics.exprs;
    while %t do
      [ok,addr,syncp,irqper,sctyp,exprs]=..
      getvalue('Sincos parameters',..
      ['Device Address:';
       'Syncp:';
       'Irqper:';
       'Sincos typ [1:fusion,2:quad):'],..
      list('str',1,'vec',-1,'vec',-1,'vec',-1),exprs)
      if ~ok then break,end
      in=[],
      out=ones(2,1)
      [model,graphics,ok]=check_io(model,graphics,in,out,1,[])
      if ok then
        graphics.exprs=exprs;
        model.rpar=[];
        model.ipar=[hex2dec(strsubst(addr,'0x',''));syncp;irqper;sctyp];
        model.dstate=[];
        x.graphics=graphics;x.model=model
        break
      end
    end
  case 'define' then
    addr='0x2000'
    syncp=332
    irqper=9
    sctyp=[1;1;1]
    model=scicos_model()
    model.sim=list('rt_sincos',4)
    model.in=[],
    model.out=ones(2,1)
    model.evtin=1
    model.rpar=[]
    model.ipar=[hex2dec(strsubst(addr,'0x',''));syncp;irqper;sctyp]
    model.dstate=[];
    model.blocktype='d'
    model.dep_ut=[%t %f]
    exprs=[addr,sci2exp(syncp),sci2exp(irqper),sci2exp(sctyp)]
    gr_i=['xstringb(orig(1),orig(2),[''Sincos'' ; addr],sz(1),sz(2),''fill'');']
    x=standard_define([3 4],model,exprs,gr_i)
  end
endfunction
