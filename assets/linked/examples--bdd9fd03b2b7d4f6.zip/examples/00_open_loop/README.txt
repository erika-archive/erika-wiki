README

File presenti nella cartella

1)progetto_cont_loop.sce
2)open_loop.cos

Nel primo file vengono definite le specifiche di sistema (frequenza di campionamento, ripple sulla tensione di uscita, resitenza di carico nominale e valore dell'induttore), 
in base a questi vengono ricavati i valori del condensatore e il ripple della corrente sull'induttore.

!!NOTA BENE : al momento della realizzazione del primo prototipo in laboratorio avevamo induttori non + grandi di L = 2.28 mH, cosi invece di avere una specifica sul 
valore dell'ondulazione della corrente ci siamo ricavati l'ondulazione (Delta_i_L) in base al valore dell'induttore. 

Il file "open_loop.cos" è lo schema elettrico realizzato all'interno di Scicos del quale vogliamo effettuare la simulazione. 
Con questa simulazione vogliamo dimostrare come ci sia bisogno di un controllore per stabilizzare il sistema nell'intorno di un valore di regime.
