//04 Agosto 2008


// Esempio di allocazione dei poli con azione integrale

//getf('cd.sci');

E  = 15.0 ;         // [Volt] Input voltage 
Vo =  5.0 ;         // [Volt] Output voltage 
Vo_rif=Vo;
t_sim=5;
s=%s;

Don = Vo/E      ;   // Duty Cycle : ideal input/output voltage gain 
//Delta_Vo = 0.05;  // [Volt] peak-peak output ripple
Ts = 1*10^(-3);     // [Second]: switching period
t_on = Don*Ts ;     // [Second]: switch ON time 
t_of = Ts-t_on;     // [Second]: switch OFF time
Ro = 5.1 ;          // [Ohm]: output load
L  = 2.28E-3;       // [Henry] : output inductance

// Usually the inductance is calculated in order to obtain a reasonable current ripple 
// In this case, the indictance is given and the current ripple is calculated as 
// L = (E*(1-D)*D*Ts)/Delta_i_L;

// Parameters used by the PWM super block 
K_nor  = 1/Ts; // Normalized gain; in order to obtain [0-1] sawthoot 
K_prop = 1/Vo;  //

//Delta_i_L=0.1;
// The peak-peack current ripple in the inductor is 
//L=(E*(1-D)*D*Ts)/Delta_i_L;
Delta_i_L=(E*(1-Don)*Don*Ts)/L; //[Ampere]
// The capacitor "C" value is a function of the desired output voltage ripple
// and the current ripple 
Ca =4* 2.2E-3;
Delta_Vo = (Delta_i_L*Ts)/(8*Ca);
//Ca=0.02;
// The "ideal" "small-signal" trasfer functions (using computed Ro, C, L, etc. values) is :
fdt_Vo_d = syslin('c',E,((L*Ca)*s^2+(L/Ro)*s+1) );

//Estrae le matrici del sistema dalla funzione di trasferimento
//sys=tf2ss(fdt_Vo_d);

A=[0 -1/L; 1/Ca -1/(Ro*Ca)];
B=[E/L; 0];
C=[0 1];
D=[0];

sys=syslin('c',A,B,C,D);

//sys=tf2ss(fdt_Vo_d);
//A1=sys1("A");
//B1=sys1("B");
//C1=sys1("C");
//D1=sys1("D");



// Discretizzazione del sistema
sysd=dscr(sys,Ts);

Ad=sysd("A");
Bd=sysd("B"); // Estrae matrici A e B del discretizzato
Cd=sysd("C");
//epsa=10E-2;
//Ad=clean(Ad,epsa);
//Bd=clean(Bd);
//Cd=clean(Cd);
//Dd=clean(sys("Dd"));
// ordine del sistema
n=size(Ad);
n=n(1);

syd=ss2tf(sysd);
//syd=syslin('d',1,denom(syd));

// Calcolo del sistema aumentato
Adaug=[Ad zeros(Bd) ; -Cd 1];
Bdaug=[Bd;0];

//Poli dominanti desiderati
zeta=0.9;
omegan=600;
fdt_desired=syslin('c',1,(1/omegan^2)*s^2 + ((2*zeta)/omegan) *s +1 ) ;
uno = syslin('c',1,1);
//wds=fdt_desired/.uno;
t=[0:0.001:1];
simulation = csim("step",t,fdt_desired);
gh_time = scf(1); clf(1); 
plot2d(t,simulation);
gh_time.figure_name = "Unit step time reponse";
polidominanti=[roots(denom(fdt_desired))];
polidominantidisc=exp(Ts*polidominanti);
// calcolo della legge di controllo FK
FK=-ppol(Adaug,Bdaug,[polidominantidisc' 0.7]);

//calcolo della legge di controllo FK assegnado tutti i poli in zero
//FK=-ppol(Adaug,Bdaug,[0 0 0]);

// separazione di F e K
F=FK(1:n);
K=FK(n+1);

//Calcolo del gudagno di retroazione
//H = ppol(Ad',Cd',[polidominantidisc])';
H = ppol(Ad',Cd',[0 0])';

//prove
//
//z=%z;
//unod=syslin('d',1,1);
//fd=Cd*inv(z*eye(Ad)-Ad)*Bd;
//fd=syslin(Ts,numer(fd),denom(fd));
//fun=syd/.unod;
//tq=[0:0.01:1];
//simulation2 = csim("step",tq,syd);
//gh_time = scf(2); clf(2); 
//plot2d(tq,simulation2);
//gh_time.figure_name = "Unit step time reponse System";
