File contenuti nella cartella:

1)prog_observer.sce
2)prog_observer.cos


Dove "prog_observer.sce" � lo script dove vengono:

-definite le specifiche
-calcolata la funzione di trasferimento
-inserite le matrici di stato del sistema
-ricostruito lo stato stimato
-calcolata la legge di retroazione dallo stato stimato (cio� la matrice F e H).

Nel file "prog_observer.cos" � rappresentato lo schema a blocchi del sistema in retroazione dallo stato con doppio anello
di retroazione.
Il primo anello � la retroazione statica dallo stato per l'allocazione dei poli in posizioni determinate, il secondo anello
richiude il sistema in un azione integrale che permette di eliminare i disturbi costanti in ingresso nell'anello.
