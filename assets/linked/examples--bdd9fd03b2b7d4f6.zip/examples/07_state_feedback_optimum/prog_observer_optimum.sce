//** bb_dlqr : automatic design of Digital LQR regulator (Roberto Bucher; roberto.bucher@supsi.ch)
function k = bb_dlqr(fi,H,Q,R)
 // Calculates the LQR gains for discrete systems
 [n1,d1] = size(fi);
  big = sysdiag(Q,R);
 [w,wp] = fullrf(big,1e-20);
  C1 = wp(:,1:n1);
  D12 = wp(:,n1+1:$);
  P = syslin('d',fi,H,C1,D12);
 [k,X] = lqr(P);
  k=-k;
endfunction ;
//**--------------------------------------------------------------------------
//01 Agosto 2008
// Esempio di allocazione dei poli con azione integrale

//getf('cd.sci');

E  = 15.0 ;         // [Volt] Input voltage 
Vo =  5.0 ;         // [Volt] Output voltage 
Vo_rif=Vo;
t_sim=5;
s=%s;

Don = Vo/E      ;   // Duty Cycle : ideal input/output voltage gain 
//Delta_Vo = 0.05;  // [Volt] peak-peak output ripple
Ts = 1*10^(-3);     // [Second]: switching period
t_on = Don*Ts ;     // [Second]: switch ON time 
t_of = Ts-t_on;     // [Second]: switch OFF time
Ro = 5.1 ;          // [Ohm]: output load
L  = 2.28E-3;       // [Henry] : output inductance

// Usually the inductance is calculated in order to obtain a reasonable current ripple 
// In this case, the indictance is given and the current ripple is calculated as 
// L = (E*(1-D)*D*Ts)/Delta_i_L;

// Parameters used by the PWM super block 
K_nor  = 1/Ts; // Normalized gain; in order to obtain [0-1] sawthoot 
K_prop = 1/Vo;  //

//Delta_i_L=0.1;
// The peak-peack current ripple in the inductor is 
//L=(E*(1-D)*D*Ts)/Delta_i_L;
Delta_i_L=(E*(1-Don)*Don*Ts)/L; //[Ampere]
// The capacitor "C" value is a function of the desired output voltage ripple
// and the current ripple 
Ca =4* 2.2E-3;
Delta_Vo = (Delta_i_L*Ts)/(8*Ca);
//Ca=0.02;
// The "ideal" "small-signal" trasfer functions (using computed Ro, C, L, etc. values) is :
fdt_Vo_d = syslin('c',E,((L*Ca)*s^2+(L/Ro)*s+1) );

//Estrae le matrici del sistema dalla funzione di trasferimento
//sys=tf2ss(fdt_Vo_d);

A = [0 -1/L; 1/Ca -1/(Ro*Ca)];
B = [E/L; 0];
C = [0 1];
D = [0];

sys = syslin('c',A,B,C,D); // Build the continous system datastructure

sys_d = dscr(sys,Ts); // Transform in the discrete 

[Ad,Bd,Cd,Dd] = abcd(sys_d); // split the discrete system 

// --- Augmented system : integrator 

zeri = [0 ; 0 ] ;

Cdi =  [ 0 -1  1 ];

Adi = [Ad zeri ; Cdi];

Bdi = [Bd ; 0] ;

// ---------- LQR Controller Design ------------------

// weights: start with Q=diag(1,1,1,1) ; change the wheight of position and angle in tens steps
//          position_one=>beam_angle, position_three=>ball_position 

Rc = [0.01];               // default value R=[1] 

Qc = diag([1 1 1]); // alternative "wheiged" experimental approach 

F_lqr_i = bb_dlqr(Adi,Bdi,Qc,Rc) ;// k_lqr is the Riccati feedback matrix (a dim.5 vector in this case)

//------------------------------------------------------------------------------

F =  -F_lqr_i(1:2) ; // extract the first four terms negative feedback please :)

K = -F_lqr_i(3) ;   // extract integrator gain  
                                            
//--------------------------------------------------------------------------------------------

Aci = Adi + Bdi * ( -F_lqr_i ) ;

Robs = [0.01];    
             
Qobs = diag([1 1]);  // alternative "wheiged" axperimental approach 

F_obs = bb_dlqr(Ad',Cd',Qobs,Robs) ;// k_lqr 

H = F_obs'

Aobs = Ad - H*Cd  ;

