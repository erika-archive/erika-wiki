File contenuti nella cartella:

1)prog_observer_optimum.sce
2)prog_observer_optimum.cos

Il file "prog_observer_optimum.sce" calcola i valori in cui devono essere allocati i poli attraverso un controllore ottimo,
in base a quali vengono poi calcolate le matrici di retroazione statica F e H. (Lo script in questione non � un mio frutto)


Il file "prog_observer_optimum.cos" contiene lo schema a blocchi del sistema in retroazione dallo stato ricostruito.
Nello schema sono presenti due anelli di retroazione, il primo � relativo alla retroazione statica dallo stato stimato il 
secondo si chiude in un anello con azione integrale che permette di eliminare eventuali disturbi costanti.
