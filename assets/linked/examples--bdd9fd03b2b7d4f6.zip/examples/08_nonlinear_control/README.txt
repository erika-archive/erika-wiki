File contenuti nella cartella:

1)cd.sci
2)prog_LnLc.sce
3)prog_LnLc.cos

Il file "cd.sci" � una raccolta di funzioni,tra le quali necessarie risultano le funzione tstn() e tstnpw() rispettivamente corrispondenti all'approssimazione di tustin e tustin con prewarping.

Il file "prog_LnLc.sce" inizializza il sistema definendo le specifiche, calcolando i valori del condensatore, calcolando il valore
della corrente di ripple dell'induttore, calcolandone la funzione di trasferimento.
Viene poi calcolato un controllore analogico e poi digitalizzato attraverso tustin con prewarping con azione integrale 
(controllore lineare).

Il file "prog_LnLc.cos" invece comprende lo schema a blocchi del controllo Lineare non Lineare, che prevede che il controllore 
sia composto da due sistemi. L'idea �: quando l'errore supera in valore assoluto una certa soglia viene applicato un 
controllo non lineare che apre o chiude gli interruttori fin tanto che il sistema non rientra dentro la soglia. Quando invece 
l'errore � di piccola entit� e quindi si � dentro la soglia viene applicato un cotrollore lineare pi� preciso a regime.
Quindi il controllore � composto da due blocchi e in base all'entit� dell'errore viene scelto quale dei due applicare.


