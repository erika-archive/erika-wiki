// Variable definitions
//** Inside Scilab there are two ways to define the "s" complex variable 
s = %s ;         // using the Scilab predefined complex variable  
s = poly(0,'s'); // using the explicit polynomial definition  
t_sim=1.2;        //Simulation time

// Input design data 
// [E, Vo, Po]   [Tensione di ingresso, Tensione D'uscita, Potenza d'uscita]  

//Specifiche in ingresso

E  = 15.0 ;  // [Volt] Input voltage 
Vo =  5.0 ;  // [Volt] Output voltage 
Vo_rif=Vo;


D = Vo/E      ;    // Duty Cycle : ideal input/output voltage gain 
Delta_Vo = 0.1;    // [Volt] peak-peak output ripple
Ts = 1*10^(-3);    // [Second]: switching period
t_on = D*Ts ;      // [Second]: switch ON time 
t_of = Ts-t_on;    // [Second]: switch OFF time
Ro = 5.1 ;         // [Ohm]: output load
L  = 2.28*10^(-3);    // [Henry] : output inductance
// Usually the inductance is calculated in order to obtain a reasonable current ripple 
// In this case, the indictance is given and the current ripple is calculated as 
// L = (E*(1-D)*D*Ts)/Delta_i_L;

// Parameters used by the PWM super block 
K_nor  = 1/Ts; // Normalized gain; in order to obtain [0-1] sawthoot 
K_prop = 1/Vo;  //
                    

// The peak-peack current ripple in the inductor is 
//L=(E*(1-D)*D*Ts)/Delta_i_L;
Delta_i_L=(E*(1-D)*D*Ts)/L; //[Ampere]

// The capacitor "C" value is a function of the desired output voltage ripple
// and the current ripple 
C = (Delta_i_L*Ts)/(8*Delta_Vo);

// An alternative equation (same numerical result) is 
// C1=((1-D)*Ts^2*Vo)/(8*L*Delta_Vo);

// The "ideal" "small-signal" trasfer functions (using computed Ro, C, L, etc. values) is :
fdt_Vo_d = syslin('c',E,((L*C)*s^(2)+(L/Ro)*s+1) );

sigma = (sqrt(L*C))/(2*C*Ro);   // damping factor 
omega_r = 1/(sqrt(L*C)) ;       // [rad/s] natural pulsation frequency 
fr = omega_r/(2*%pi);           // [Hz] natural frequency 
picco_ris    =  1/(2*sigma*sqrt(1-sigma^2));  // resonance peak value 
picco_ris_db = 20*log(picco_ris);             //[db] resonance peak value
puls_ris=omega_r*sqrt(1-2*sigma^2);           // [rad/sec] resonant frequency 

// Closed loop system
z=poly(0,'z');

// Discretizzazione parte razionale
sysd=ss2tf(dscr(fdt_Vo_d,Ts)); 


//Calcolo della W0 desiderata
k=1/(1-roots(numer(sysd)));
w0=syslin(Ts,k*(z-roots(numer(sysd))),z^2);

//Calcolo del controllore desiderato
unod=syslin('d',1,1);
cz=(-(-w0)/.unod)*sysd^(-1);
numcz=cz("num"); //Definizione del numeratore
dencz=cz("den"); //Definizione del denumeratore

