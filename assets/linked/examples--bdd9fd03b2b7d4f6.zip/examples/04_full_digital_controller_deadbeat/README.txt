File contenuti nella cartella:

1)progetto_cont_DIG_loop.sce
2)progetto_cont_DIG.cos


Il primo file "progetto_cont_DIG_loop.sce" contiene la routine di inizializzazione, la dichiarazione delle specifiche, il calcolo del condensatore, il calcolo della corrente di ripple, il calcolo della funzione di trasferimento. 
Dopodich� vengono calcolati i poli della funzione di trasferimento linearizzata dell'impianto e viene sintetizzato 
il controllore in maniera che cancelli la dinamica dell'impianto e vi sostituisca una dinamica desiderata.
In questo caso abbiamo sostituito un sistema con tutti poli in zero con l'idea di rendere la 
risposta del sistema pi� veloce rispetto alle varizioni. E' stato implementato un controllore DEADBEAT. 

!! Come vedremo dalle simulazioni il controllore non riesce a stabilizzare in pieno il sistema in quanto rispetto a 
variazioni di carico il sistema diventa oscillante.

Il secondo file "progetto_cont_DIG.cos" invece contiene lo schema a blocchi del sistema composto da controllore digitale 
e S/H.
