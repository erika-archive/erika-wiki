// Variable definitions
//** Inside Scilab there are two ways to define the "s" complex variable 
s = %s ;         // using the Scilab predefined complex variable  
s = poly(0,'s'); // using the explicit polynomial definition  

// Input design data 
// [E, Vo, Po]   [Tensione di ingresso, Tensione D'uscita, Potenza d'uscita]  

// Specifiche in ingresso

E  = 15.0 ;  // [Volt] Input voltage 
Vo =  5.0 ;  // [Volt] Output voltage 
Vo_rif = Vo;
t_sim=2.5;         //[second] Simulation time
D = Vo/E      ;    // Duty Cycle : ideal input/output voltage gain 
Delta_Vo = 0.1;    // [Volt] peak-peak output ripple  
Ts = 1*10^(-3);    // [Second]: switching period
t_on = D*Ts ;      // [Second]: switch ON time 
t_of = Ts-t_on;    // [Second]: switch OFF time 
Ro = 5.1 ;         // [Ohm]: output load 
L  = 2.28*10^(-3);    // [Henry] : output inductance

// Usually the inductance is calculated in order to obtain a reasonable current ripple 
// In this case, the indictance is given and the current ripple is calculated as 
// L = (E*(1-D)*D*Ts)/Delta_i_L;

// Parameters used by the PWM super block 
K_nor  = 1/Ts; // Normalized gain; in order to obtain [0-1] sawthoot 
K_prop = 1/Vo;  // 
              
// The peak-peack current ripple in the inductor is 
Delta_i_L=(E*(1-D)*D*Ts)/L; //[Ampere]

// The capacitor "C" value is a function of the desired output voltage ripple
// and the current ripple 
C = (Delta_i_L*Ts)/(8*Delta_Vo);
// An alternative equation (same numerical result) is 
// C1=((1-D)*Ts^2*Vo)/(8*L*Delta_Vo); 

// The "ideal" "small-signal" trasfer functions (using computed Ro, C, L, etc. values) is :
fdt_Vo_d = syslin('c',E,((L*C)*s^(2)+(L/Ro)*s+1) );

gh_plant = scf(1); clf(1); bode(fdt_Vo_d);
gh_plant.figure_name = "Small-signal open loop trasfer function";


sigma = (sqrt(L*C))/(2*C*Ro); // damping factor 
omega_r = 1/(sqrt(L*C)) ;     // [rad/s] natural pulsation frequency 
fr = omega_r/(2*%pi); // [Hz] natural frequency 
picco_ris    =  1/(2*sigma*sqrt(1-sigma^2));  // resonance peak value 
picco_ris_db = 20*log(picco_ris);             //[db] resonance peak value
puls_ris=omega_r*sqrt(1-2*sigma^2);  // [rad/sec] resonant frequency 

// Closed loop system
// Desired - closed loop - crossing frequency (closed loop bandwith) 
fa0 =100;        // [Hertz]
wa0 = 2*%pi*fa0; // [rad/sec] pulsation 

// Phase margin 
mf0 = 45;           //[gradi] margine di fase desiderato

// Bode static gain adjust 
Kc = 1/(E*0.1) ; // from the final value theorem 

// open loop gain without compensation networks 
Lprimo = Kc*fdt_Vo_d;

gh_open=scf(2); clf(2); bode(Lprimo); 
gh_open.figure_name = "Open loop with final value spec.";  
// Open loop reponse
// disp("Risposta in frequenza alla pusazione wa desiderata wa0")
rf = repfreq(Lprimo, fa0); 
[modulodb,fase] = dbphi(rf);

// First delay network used to reduce the phase 
mr  = 10;
wtr =  100;
Cr = syslin('c',1+wtr/wa0/mr*s,1+wtr/wa0*s);
//

faa =300;        // [Hertz]
waa = 2*%pi*faa;
ma=16;
wta=2;
Ca=syslin('c',1+(wta/waa)*s,1+s*(wta/waa)/ma);


K=10^(25/20);
// Controller design  
Cds = K*Kc*Cr*Ca;

// Loop gain 
Lds = Cds*fdt_Vo_d;
gh_comp = scf(3); clf(3); bode(Lds);
gh_comp.figure_name = "Small-signal open loop compensated t.f.";  

gh_comp2 = scf(4); clf(4); evans(Lds);
gh_comp2.figure_name = "root locus of open loop gain";

gh_comp3 = scf(5); clf(5); nyquist(Lds);
gh_comp3.figure_name = "nyquist diagram of L(s)";

// Closed loop gain trasfer function 
uno = syslin('c',1,1);
Wds = Lds/.uno;  
gh_close = scf(6); clf(6); bode(Wds);
gh_close.figure_name = "Small-signal closed loop t.f.";  


// Design verification 
// Unit step input reponse 
//disp("Risposta al gradino FdT ad anello chiuso")
t=[0:0.001:1];
Wdoppio = csim("step",t,Wds);
gh_time = scf(7); clf(7); 
plot2d(t,Wdoppio)
gh_time.figure_name = "Unit step time reponse";


////Another Kind of compensation without overshoot
//
//
//// First delay network used to reduce the phase 
//mr_fase  = 16;
//wtr_fase =  2;
//Cr_fase = syslin('c',1+wtr_fase/wa0/mr_fase*s,1+wtr_fase/wa0*s); 
//
//// Second delay network used to reduce the amplitude 
//mr_modu  =  10;
//wtr_modu = 100 ;
//Cr_modu  = syslin('c',1+wtr_modu/wa0/mr_modu*s,1+wtr_modu/wa0*s);
//
//// Controller design  
//Cds = Kc*Cr_fase^2*Cr_modu;
//
//// Loop gain 
//Lds = Cds*fdt_Vo_d;
//gh_compe = scf(6); clf(6); bode(Lds);
//gh_compe.figure_name = "Small-signal open loop compensated t.f.";  
//
//// Phase margin (loop gain) 
//[fasewa,fa] = p_margin(Lds);
//wa = 2*%pi*fa; // rad/s
//disp("Margine di fase compensato")
//pm = 180+fasewa
//disp("Pulsazione attraversamento compensata")
//wa
//
//// Closed loop gain trasfer function 
//disp("Funzione di trasferimento ad anello chiuso")
//uno = syslin('c',1,1);
//Wds = Lds/.uno; //** L(s)/(1+L(s)) ; ???  
//gh_closeloop = scf(7); clf(7); bode(Wds);
//gh_closeloop.figure_name = "Small-signal closed loop t.f.";  
//
//
//// Design verification 
//// Unit step input reponse 
////disp("Risposta al gradino FdT ad anello chiuso")
//t=[0:0.001:1];
//Wdoppio = csim("step",t,Wds);
//gh_time2 = scf(8); clf(8); 
//plot2d(t,Wdoppio)
//gh_time2.figure_name = "Unit step time reponse";
