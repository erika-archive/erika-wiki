README

File presenti nella cartella:

1)progetto_cont_loop.sce
2)feed_forward_buck_controller.cos
3)feed_forward_buck_controller_block.cos


Nel primo file vengono definite le specifiche del sistema, viene calcolata al funzione di trasferimento
e viene calcolato un primo controllore per la configurazione Feed Forward.
In tale configurazione useremo un segnale costante in ingresso all'impianto di ampiezza D ( pari al rapporto tensione
di uscita su tensioen di ingresso) pi� un controllore analogico composto da reti correttrici ( anticipatrici e ritardatrici).
In questa maniera viene cosi stabilizzato il sistema intorno alle variazioni di carico presenti nel sistema.

Il file "feed_forward_buck_controller.cos" rappresenta lo schema elettrico di un alimentatore a commutazione e permette di
simularne l'andamento. All'uscita di tale schema � implementato un sistema che permette di passare da una condizione di carico
nominale R0=5.1 Ohm a una condizione di carico R0=50 Ohm in maniera da simulare una variazione delle condizioni di lavoro
per testarne la stabilit�.

Il file "feed_forward_buck_controller_block.cos" rappresenta lo stesso schema dove la parte "elettrica" � stata inserita
all'interno di un sperblocco.

