// Script file used to load the "compiled"
// scicos block into ScicosLab

//Copyright (c) 1989-2010 Metalau project INRIA

//@@ Define the name of the block
blknam="SuperBlock";

//** Get the absolute path of this loader file
DIR=get_absolute_file_path(blknam+'_loader.sce');

//** Define Makefile name
Makename=DIR+'Makefile_'+blknam;

//** Unlink if necessary
[a,b]=c_link(blknam);
while a
  ulink(b);
  [a,b]=c_link(blknam);
end

//** Run Makefile
libn=ilib_compile("libSuperBlock",Makename);

//** Adjust path name of object files
if MSDOS then
  fileso=strsubst(libn,'/','\');
else
  fileso=strsubst(libn,'\','/');
end

//@@ Inform %scicos_libs with library
if exists('%scicos_libs') then
  if find(fileso==%scicos_libs)==[] then
    %scicos_libs=[%scicos_libs,fileso];
  end
else
  %scicos_libs=[fileso];
end

//** Link block routine in ScicosLab
link(fileso,blknam,'c');

//** Load the gui function
if fileinfo(DIR+blknam+'_c.sci')<>[] then
  getf(DIR+blknam+'_c.sci');
end

//## Define name of interf lib
l_blknam=length(blknam);
l_blknam=(l_blknam>17)*17 + (l_blknam<=17)*l_blknam;
blknamint='int'+part(blknam,1:l_blknam);
Makename=DIR+'Makefile_'+blknamint;

//** Unlink if necessary
[a,b]=c_link(blknamint+'_sci');
while a
  ulink(b);
  [a,b]=c_link(blknam+'_sci');
end

//** Run Makefile
libn=ilib_compile("libintSuperBlock",Makename);

//** Adjust path name of object files
if MSDOS then
  fileso=strsubst(libn,'/','\');
else
  fileso=strsubst(libn,'\','/');
end

//## Link and add ScicosLab function of the standalone.
addinter(fileso,blknamint+'_sci',blknam);

//@@ Clear the used variabe
clear blknam
clear l_blknam
clear blknamint
clear Makename
clear DIR
clear fileso
clear libn
clear a
clear b

