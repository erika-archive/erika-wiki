// Collezione di funzioni per il corso di Controllo Digitale
// Include le funzioni modificate r_* per il calcolo
// della risposta in frequenza



function F=dlqr(A,B,Q,R)

// Wrapper per il calcolo soluzione problema LQ a tempo discreto

n=size(A);
n=n(1);
Big=sysdiag(Q,R);    // Calculate C1 and D12
[w,wp]=fullrf(Big);
C1=wp(:,1:n);
D12=wp(:,n+1:$);   //[C1,D12]'*[C1,D12]=Big
P=syslin('d',A,B,C1,D12);    //The plant (discrete-time)
[F,X]=lqr(P)

endfunction



function sysdd=dscrdel(a,tau,T)

// Discretizzazione con ZOH di impianto con ritardo
// a: Parte razionale dell'impianto [a=syslin('c',num,den)]
// tau: ritardo dell'impianto
// T: passo di campionamento

m=floor(tau/T);
delta=tau-m*T;

if delta==0 then
  sysdx=ss2tf(dscr(a,T));
else
  a=tf2ss(a);
  sysd=dscr(a,T);
  sysd0=dscr(a,T-delta);
  sysd1=dscr(a,delta);
  Ad=sysd("A");
  Bd0=sysd0("B");
  Bd1=sysd0("A")*sysd1("B");
  rb=size(Bd1,1);
  cb=size(Bd1,2);
  Adaug=[Ad Bd1;zeros(cb,rb) zeros(cb,cb)];
  Bdaug=[Bd0;eye(cb,cb)]
  Cdaug=[sysd("C") sysd("D")];
  Ddaug=zeros(size(a("D"),1));
  sysdx=ss2tf(syslin(T,Adaug,Bdaug,Cdaug,Ddaug));
end;
z=poly(0,'z');
sysdd=syslin(T,sysdx("num"),z^m*sysdx("den"));


endfunction




function cz=mpz(T,cs)

// Calcola il controllore approssimato di cs mediante
// tecnica matching poli-zeri (MPZ)
// IN
// cs=Linear system: Controllore continuo
// T: Tempo di campionamento
// OUT
// cz=Linear system: Controllore approssimato discreto

eps=%eps;
numc=cs("num"); // Estrae num e den del controllore analogico
denc=cs("den"); 
coeffdenc=coeff(denc);
maxcoeff=coeffdenc(size(coeffdenc,2));
dummy=1/maxcoeff*poly([],'s');
numc=numc*dummy;
denc=denc*dummy; // denc ora e' monico
zeri=roots(numc); // Calcolo zeri analogico
poli=roots(denc); // Poli
polinonzero=[];
for i=1:size(poli,1),
  if abs(poli(i)) > eps then
    polinonzero=[polinonzero;poli(i)];
  end,
end;
numpolinzero=size(poli,1)-size(polinonzero,1);
dencsnonzero=poly(polinonzero,'s');
kbodecs=horner(numc,0)/horner(dencsnonzero,0);
zerid=exp(zeri*T); // Zeri trasformati
polid=exp(poli*T); // Poli
polidnonuno=exp(polinonzero*T);
z=poly(0,'z');
numcz=poly(zerid,'z'); // Costruzione numeratore C(z)
dencz=poly(polid,'z'); // Costruzione denominatore C(z)
dencznonuno=poly(polidnonuno,'z');
eccpz=degree(denc)-degree(numc); // Eccesso p-z del C(s)
zeriinmenouno=-1*ones(eccpz,1); // Vettore di zeri in -1 pari a ecc. p-z
polzeri=poly(zeriinmenouno,'z'); // Polinomio (z+1)^(n-m)
numcz=numcz*polzeri; // Aggiunta a numeratore di C(z)
kbodecz=horner(numcz,1)/horner(dencznonuno,1);
kappa=kbodecs/kbodecz*poly([],'z'); // Normalizzazione guadagno
numcz=numcz*kappa*T^numpolinzero; // Ditto
cz=syslin(T,numcz,dencz);
endfunction




function cz=tstn(T,cs)

// Calcola il controllore approssimato di cs mediante
// la trasformazione di Tustin
// IN
// cs=Linear system: Controllore continuo
// T: Tempo di campionamento
// OUT
// cz=Linear system: Controllore approssimato discreto

z=poly(0,'z');
czstato=tf2ss(cs);
czstato=cls2dls(czstato,T); // Bilineare
cz=ss2tf(czstato);
cz=syslin(T,cz("num"),cz("den"));
endfunction




function cz=tstnpw(T,cs,wp)

// Calcola il controllore approssimato di cs mediante
// la trasformazione di Tustin con prewarping
// IN
// cs=Linear system: Controllore continuo
// T: Tempo di campionamento
// wp: pulsazione di prewarping
// OUT
// cz=Linear system: Controllore approssimato discreto

z=poly(0,'z');
czstato=tf2ss(cs);
czstato=cls2dls(czstato,T,wp/2/%pi); // Bilineare con pw
cz=ss2tf(czstato);
cz=syslin(T,cz("num"),cz("den"));
endfunction




function cz=eulav(T,cs)

// Calcola il controllore approssimato di cs mediante
// la trasformazione di Eulero avanti
// IN
// cs=Linear system: Controllore continuo
// T: Tempo di campionamento
// OUT
// cz=Linear system: Controllore approssimato discreto

z=poly(0,'z');
cz=horner(cs,(z-1)/T);
cz=syslin(T,cz("num"),cz("den"));
endfunction





function cz=eulind(T,cs)

// Calcola il controllore approssimato di cs mediante
// la trasformazione di Eulero indietro
// IN
// cs=Linear system: Controllore continuo
// T: Tempo di campionamento
// OUT
// cz=Linear system: Controllore approssimato discreto

z=poly(0,'z');
cz=horner(cs,(z-1)/(T*z));
cz=syslin(T,cz("num"),cz("den"));
endfunction



function [frq,bnds,splitf]=r_calfrq(h,fmin,fmax)
//!
// Copyright INRIA
// giannibi: modified to express frequencies in rad/s
eps=1.d-14   //minimum absolute lower frequency
k=0.001;     // Minimum relative prediction error in the nyquist plan 
epss=0.002   // minimum frequency distance with a singularity
nptmax=5000 //maximum number of discretisation points
tol=0.01     // Tolerance for testing pure imaginary numbers 

// Check inputs
// ------------
if type(h)<>15&type(h)<>16 then 
  error('first arg. to calfrq : waiting for syslin list'),
  end
flag=h(1);
if flag(1)<>'lss'&h(1)<>'r' then 
  error('first arg. to calfrq : waiting for syslin list'),
end
if flag(1)=='lss' then
  h=ss2tf(h)
end
[m,n]=size(h('num'))
if  n<>1 then  
  error('SIMO system only!')
end
dom=h('dt')
select dom
case 'd' then 
  dom=1
case [] then 
  error(96,1)
case 0 then
  error(96,1)
end;

if type(dom)==1 then 
  nyq_frq=%pi/dom;
  if fmax>nyq_frq then 
    warning('frequencies beyond Nyquist f are ignored!');
    fmax=min(fmax,nyq_frq)
  end
  if fmin<-nyq_frq then 
    warning('negative frequencies below Nyquist f are ignored!');
    fmin=max(fmin,-nyq_frq)
  end
end
// Use symmetry to reduce the range
// --------------------------------
if fmin<0&fmax>=0 then
  [frq,bnds,splitf]=calfrq(h,eps,-fmin)
  ns1=size(splitf,'*')-1;
  nsp=size(frq,'*');
  bnds=[bnds(1),bnds(2),-bnds(4),-bnds(3)];

  if fmax>eps then
    if fmax==-fmin then
      splitf=[1, (nsp+2)*ones(1,ns1)-splitf($:-1:2),nsp*ones(ns1)+splitf(2:$)];
      bnds=[bnds(1),bnds(2),min(bnds(3),-bnds(3)),max(bnds(4),-bnds(4))];
      frq=[-frq($:-1:1),frq]
    else
      [frq2,bnds2,splitf2]=calfrq(h,eps,fmax);
      ns2=size(splitf2,'*')-1
      splitf=[1, (nsp+2)*ones(1,ns1)-splitf($:-1:2),nsp*ones(ns2)+splitf2(2:$)];
      bnds=[min(bnds(1),bnds2(1)),max(bnds(2),bnds2(2)),...
              min(bnds(3),bnds2(3)),max(bnds(4),bnds2(4))];
      frq=[-frq($:-1:1),frq2]
    end
    return
  else
    frq=-frq($:-1:1);
    nsp=size(frq,'*');
    
    splitf=[1, (nsp+2)*ones(1,ns1)-splitf($:-1:2)]
    bnds=bnds;
    return;
  end
elseif fmin<0&fmax<=0 then
  [frq,bnds,splitf]=calfrq(h,-fmax,-fmin)
  ns1=size(splitf,'*')-1;
  frq=-frq($:-1:1);
  nsp=size(frq,'*');
  splitf=[1, (nsp+2)*ones(1,ns1)-splitf($:-1:2)]
  bnds=[bnds(1),bnds(2),-bnds(4),-bnds(3)];
  return;
elseif fmin >= fmax then
  error('calfrq: fmin must be < fmax');
end

// Compute dicretisation over a given range
// ----------------------------------------


splitf=[]
if fmin==0 then fmin=min(1d-14,fmax/10);end
//
denh=h('den');numh=h('num')
l10=log(10)

// Locate singularities to avoid them
// ----------------------------------
if dom=='c' then
  c=2*%pi;
  //selection function for singularities in the frequency range
  deff('f=%sel(r,fmin,fmax,tol)',['f=[],';
  'if prod(size(r))==0 then return,end';
  'f=imag(r(find((abs(real(r))<=tol*abs(r))&(imag(r)>=0))))';
  'if f<>[] then  f=f(find((f>fmin-tol)&(f<fmax+tol)));end']);
else
  c=2*%pi*dom
  //selection function for singularities in the frequency range
  deff('[f]=%sel(r,fmin,fmax,dom,tol)',['f=[],';
  'if prod(size(r))==0 then return,end';
  'f=r(find( ((abs(abs(r)-ones(r)))<=tol)&(imag(r)>=0)))';
  'if f<>[] then ';
  '  f=atan(imag(f),real(f));nf=prod(size(f))';
  '  for k=1:nf ,';
  '    kk=int((fmax-f(k))/(2*%pi))+1;';
  '    f=[f;f(1:nf)+2*%pi*kk*ones(nf,1)];';
  '  end;'
  '  f=f(find((f>fmin-tol)&(f<fmax+tol)))';
  'end']);
end

sing=[];zers=[];
fmin=c*fmin,fmax=c*fmax;

for i=1:m
  sing=[sing;%sel(roots(denh(i)),fmin,fmax,tol)];
end

pp=sort(sing');npp=size(pp,'*');//'

// singularities just on the left of the range
kinf=find(pp<fmin)
if kinf<>[] then
  fmin=fmin+tol
  pp(kinf)=[]
end

// singularities just on the right of the range
ksup=find(pp>=fmax)
if ksup<>[] then
  fmax=fmax-tol
  pp(ksup)=[]
end

//check for nearly multiple singularities
if pp<>[] then
  dpp=pp(2:$)-pp(1:$-1)
  keq=find(abs(dpp)<2*epss)
  if keq<>[] then pp(keq)=[],end
end

if pp<>[] then
  frqs=[fmin real(matrix([(1-epss)*pp;(1+epss)*pp],2*size(pp,'*'),1)') fmax]
  //'
else
  frqs=[fmin fmax]
end
nfrq=size(frqs,'*');

// Evaluate bounds of nyquist plot
//-------------------------------

xt=[];Pas=[]
for i=1:2:nfrq-1
  w=logspace(log(frqs(i))/log(10),log(frqs(i+1))/log(10),100);
  xt=[xt,w]
  Pas=[Pas w(2)-w(1)]
end
if dom=='c' then 
  rf=freq(h('num'),h('den'),%i*xt);
else
  rf=freq(h('num'),h('den'),exp(%i*xt));
end
//
xmin=mini(real(rf));xmax=maxi(real(rf));
ymin=mini(imag(rf));ymax=maxi(imag(rf));
bnds=[xmin xmax ymin ymax];
dx=max([xmax-xmin,1]);dy=max([ymax-ymin,1]);

// Compute discretization with a step adaptation method
// ----------------------------------------------------
frq=[];
i=1;
nptr=nptmax; // number of unused discretization points
l10last=log10(frqs($));
while i<nfrq
  f0=frqs(i);fmax=frqs(i+1);
  while f0==fmax do
    i=i+2;
    f=frqs(i);fmax=frqs(i+1);
  end
  frq=[frq,f0];
  pas=Pas(floor(i/2)+1)
  splitf=[splitf size(frq,'*')];

  f=mini(f0+pas,fmax);

  if dom=='c' then //cas continu
    while f0<fmax
      rf0=freq(h('num'),h('den'),(%i*f0));
      rfc=freq(h('num'),h('den'),%i*f);
      // compute prediction error
      epsd=pas/100;//epsd=1.d-8
      
      rfd=(freq(h('num'),h('den'),%i*(f0+epsd))-rf0)/(epsd);
      rfp=rf0+pas*rfd;

      e=maxi([abs(imag(rfp-rfc))/dy;abs(real(rfp-rfc))/dx])
      if (e>k) then rf0=freq(h('num'),h('den'),(%i*f0));
      rfc=freq(h('num'),h('den'),%i*f);
      // compute prediction error
      epsd=pas/100;//epsd=1.d-8

      rfd=(freq(h('num'),h('den'),%i*(f0+epsd))-rf0)/(epsd);
      rfp=rf0+pas*rfd;

      e=maxi([abs(imag(rfp-rfc))/dy;abs(real(rfp-rfc))/dx])
	// compute minimum frequency logarithmic step to ensure a maximum 
	//of nptmax points to discretize
	pasmin=f0*(10^((l10last-log10(f0))/(nptr+1))-1)
	pas=pas/2
	if pas<pasmin then
	  pas=pasmin
	  frq=[frq,f];nptr=max([1,nptr-1])
	  f0=f;f=mini(f0+pas,fmax)
	else
	  f=mini(f0+pas,fmax)
	end
      elseif e<k/2 then
	pas=2*pas
	frq=[frq,f];nptr=max([1,nptr-1])
	f0=f;f=mini(f0+pas,fmax),
      else
	frq=[frq,f];nptr=max([1,nptr-1])
	f0=f;f=mini(f0+pas,fmax),
      end
    end
  else  //cas discret
    pas=pas/dom
    while f0<fmax
      rf0=freq(h('num'),h('den'),exp(%i*f0))
      rfd=dom*(freq(h('num'),h('den'),exp(%i*(f0+pas/100)))-rf0)/(pas/100);
      rfp=rf0+pas*rfd
      rfc=freq(h('num'),h('den'),exp(%i*f));
      e=maxi([abs(imag(rfp-rfc))/dy;abs(real(rfp-rfc))/dx])
      if (e>k) then
	pasmin=f0*(10^((l10last-log10(f0))/(nptr+1))-1)
	pas=pas/2
	if pas<pasmin then
	  pas=pasmin
	  frq=[frq,f];nptr=max([1,nptr-1])
	  f0=f;f=mini(f0+pas,fmax)
	else
	  f=mini(f0+pas,fmax)
	end
      elseif e<k/2 then
	pas=2*pas
	frq=[frq,f];nptr=max([1,nptr-1])
	f0=f;f=mini(f0+pas,fmax),
      else
	frq=[frq,f];nptr=max([1,nptr-1])
	f0=f;f=mini(f0+pas,fmax),
      end
    end
  end
  i=i+2
end
frq( size(frq,'*') )=fmax
frq=frq/c;
endfunction





function []=r_black(sl,fmin,fmax,pas,comments)
//Black's diagram (Nichols chart) for a linear system sl.
//sl can be a continuous-time, discrete-time or sampled SIMO system
//Syntax:
//
//           black( sl,fmin,fmax [,pas] [,comments] )
//           black(frq,db,phi [,comments])
//           black(frq, repf  [,comments])
//  
//  sl       : SIMO linear system (see syslin). In case of multi-output
//             system the outputs are plotted with differents symbols.
//            
//  fmin     : minimal frequency (in Hz).
//  fmax     : maximal frequency (in Hz).
//  pas      : logarithmic discretization step. (see calfrq for the
//             choice of default value).
//  comments : character strings to comment the curves.
//
//  frq      : (row)-vector of frequencies (in Hz) or (SIMO case) matrix
//             of frequencies.
//  db       : matrix of modulus (in Db). One row for each response.
//  phi      : matrix of phases (in degrees). One row for each response.
//  repf     : matrix of complex numbers. One row for each response.

// Copyright INRIA
//To plot the grid of iso-gain and iso-phase of y/(1+y) use abaque()
//%Example
//  s=poly(0,'s')
//  h=syslin('c',(s**2+2*0.9*10*s+100)/(s**2+2*0.3*10.1*s+102.01))
//  abaque();
//  black(h,0.01,100,'(s**2+2*0.9*10*s+100)/(s**2+2*0.3*10.1*s+102.01)')
//  //
//  h1=h*syslin('c',(s**2+2*0.1*15.1*s+228.01)/(s**2+2*0.9*15*s+225))
//  black([h1;h],0.01,100,['h1';'h'])
//See also:
//  bode nyquist  abaque freq repfreq 
//!
[lhs,rhs]=argn(0);
pas_def='auto' //
//
//
ilf=0
typ=type(sl)
//-compat next line added for list/tlist compatibility
if typ==15 then typ=16,end
select typ
case 16 then  // sl,fmin,fmax [,pas] [,comments]
  typ=sl(1);typ=typ(1);
  if typ<>'lss'&typ<>'r' then
    error(97,1)
  end
  select rhs
  case 1 then //sl
   comments=' '
   [frq,repf]=r_repfreq(sl);
   [d,phi]=dbphi(repf);
   sl=[] 
  case 2 then // sl,frq
   comments=' '
   [frq,repf]=r_repfreq(sl,fmin);
   [d,phi]=dbphi(repf);
   fmin=[];sl=[]
  case 3 ,
   if type(fmax)==1 then
      comments=' '
      [frq,repf]=r_repfreq(sl,fmin,fmax,pas_def),
      [d,phi]=dbphi(repf);
      sl=[]
   else
      comments=fmax
      [frq,repf]=r_repfreq(sl,fmin);
      [d,phi]=dbphi(repf);
      fmin=[];sl=[]
   end
  case 4 ,
    if type(pas)==1 then 
      comments=' ',
    else 
      comments=pas;pas=pas_def
    end,
    [frq,repf]=r_repfreq(sl,fmin,fmax,pas)
    [d,phi]=dbphi(repf);
  case 5 then,
    [frq,repf]=r_repfreq(sl,fmin,fmax,pas)
    [d,phi]=dbphi(repf);
  else 
    error('invalid call: sys,fmin,fmax [,pas] [,com]')
  end;
//bode(sl,fmin,fmax,pas,comments)
case 1 then //frq,db,phi [,comments] or frq, repf [,comments]
  select rhs
  case 2 , //frq,repf
    comments=' '
    [phi,d]=phasemag(fmin),fmin=[]
  case 3 then
    if type(fmax)==1 then
      comments=' '//frq db phi
      d=fmin,fmin=[]
      phi=fmax,fmax=[]
    else
      [phi,d]=phasemag(fmin);fmin=[]
      comments=fmax
     end;
   case 4 then 
     comments=pas;d=fmin;fmin=[];phi=fmax;fmax=[]
   else 
     error('invalid call :frq,db,phi,[com] ou frq,repf,[com]')
   end;
   frq=sl;sl=[];[mn,n]=size(frq);
   if mn<>1 then
      ilf=1;
   else
      ilf=0;
   end;
else 
   error('invalid call to black')
end;

[mn,n]=size(phi);
//
if comments==' ' then
   comments(mn)=' ';
   mnc=0;
   strf='051'
else
   mnc=mn;
  strf='151'
end;
xmn=floor(min(phi)/90)*90
xmx=ceil(max(phi)/90)*90
ymn=min(d)
ymx=max(d)
rect=[ymn;xmn;ymx;xmx]
//[xmn,xmx,npx]=graduate(-360,0)
//[ymn,ymx,npy]=graduate(mini(d),maxi(d))
rect=[xmn,ymn,xmx,ymx]
leg=strcat(comments,'@')

//plot2d(phi',d',(1:mn),strf,leg,rect,[10,npx,10,npy]);
plot2d(phi',d',(1:mn),strf,leg,rect);
kf=1
phi1=phi+5*ones(phi);
xgeti=xget("mark");
xset("mark",2,xgeti(2));
xset("clipgrf");



kk=1;p0=[phi(:,kk) d(:,kk)];ks=1;dst=0;
dx=rect(3)-rect(1)
dy=rect(4)-rect(2)
dx2=dx^2;dy2=dy^2

while kk<n
  kk=kk+1
  dst=dst+mini(((phi(:,kk-1)-phi(:,kk))^2)/dx2+((d(:,kk-1)-d(:,kk))^2)/dy2)
  if dst>0.001 then
  if mini(abs(frq(:,ks(prod(size(ks))))-frq(:,kk))./frq(:,kk))>0.2 then
   ks=[ks kk]
   dst=0
  end
  end
end
kf=1
for k=1:mn,
    xnumb(phi(k,ks),d(k,ks),frq(kf,ks),0);
    xpoly(phi(k,ks),d(k,ks),'marks',0);
  kf=kf+ilf
end;
xclip();
xtitle('h(2i.pi.f) ','phase','magnitude');
//     contour 2.3 db
mbf=2.3;
lmda=exp(log(10)/20*mbf);
r=lmda/(lmda**2-1);
npts=100;
crcl=exp(%i*(-%pi:(2*%pi/npts):%pi));
lgmt=log(-r*crcl+r*lmda*ones(crcl));
plot2d([180*(imag(lgmt)/%pi-ones(lgmt))]',[(20/log(10)*real(lgmt))]',...
     [2,-(mnc+1)],"100",'2.3db curve'),
xset("mark",xgeti(1),xgeti(2));
endfunction



function []=r_bode(sl,fmin,fmax,pas,comments)
//! 
// Copyright INRIA
// giannibi: modified in order to plot the frequency response
// as a function of omega (rad/s)
[lhs,rhs]=argn(0);
dom='c';
//---------------------
nyq_frq=[];l10=log(10);
pas_def='auto' // default
ilf=0
typ=type(sl)
//-compat next line added for list/tlist compatibility
if typ==15 then typ=16,end
select typ
case 16 then  // sl,fmin,fmax [,pas] [,comments]
  typ=sl(1);typ=typ(1);
  if typ<>'lss'&typ<>'r' then
    error(97,1)
  end
  if typ=='lss' then
    if sl(7)==[] then error('Undefined time domain (sl(7))');end
  end
  if typ=='r' then
    if sl(4)==[] then error('Undefined time domain (sl(4))');end
  end
  dom=sl('dt')
  if dom==[]|dom==0 then error(96,1),end
  if dom=='d' then dom=1;end
  
  select rhs
  case 1 then //sl
   comments=' '
   fmin_default=1.d-3;
   fmax_default=1.d3;

   if dom=='c' then fmax_default=1.d3; else fmax_default=%pi/dom,end
   [frq,repf]=r_repfreq(sl,fmin_default,fmax_default);
   [d,phi]=dbphi(repf);
   sl=[] 
  case 2 then // sl,frq
   comments=' '
   if min(fmin)<=0 then
     error('bode: requires strictly positive frequency vector')
   end
   [frq,repf]=r_repfreq(sl,fmin);
   [d,phi]=dbphi(repf);
   fmin=[];sl=[]
  case 3 , //sl,frq,comments ou sl,fmin,fmax
   if type(fmax)==1 then
      comments=' '
      if fmin<=0 then
         error('bode: requires strictly positive frequency range')
       end
      [frq,repf]=r_repfreq(sl,fmin,fmax,pas_def),sl=[]
      [d,phi]=dbphi(repf);
   else
      comments=fmax
      if min(fmin)<=0 then
	error('bode: requires strictly positive frequency vector')
      end      
      if type(dom)==1 then nyq_frq=%pi/dom;end
      if find(fmin>nyq_frq)~=[] then 
	warning('There are frequencies beyond Nyquist f!');
      end
      [frq,repf]=r_repfreq(sl,fmin);fmin=[];sl=[]
      [d,phi]=dbphi(repf);
   end
  case 4 ,
    if type(pas)==1 then 
      comments=' ',
    else 
      comments=pas;pas=pas_def;
    end,
    if min(fmin)<=0 then
      error('bode: requires strictly positive frequency vector')
    end
    [frq,repf]=r_repfreq(sl,fmin,fmax,pas)
    [d,phi]=dbphi(repf);
  case 5 then,
    if min(fmin)<=0 then
      error('bode: requires strictly positive frequency vector')
    end
    [frq,repf]=r_repfreq(sl,fmin,fmax,pas)
    [d,phi]=dbphi(repf);
  else 
    error('Invalid call: sys,fmin,fmax [,pas] [,com]')
  end;

case 1 then //frq,db,phi [,comments] ou frq, repf [,comments]
  select rhs
  case 2 , //frq,repf
    comments=' '
    [phi,d]=phasemag(fmin);fmin=[]
  case 3 then
    if type(fmax)==1 then
      comments=' '//frq db phi
      d=fmin,fmin=[]
      phi=fmax,fmax=[]
    else
      [phi,d]=phasemag(fmin);fmin=[]
      comments=fmax
     end;
   case 4 then 
     comments=pas;d=fmin;fmin=[];phi=fmax;fmax=[]
   else 
     error('Invalid call: frq,db,phi,[com] or frq,repf,[com]')
   end;
   frq=sl;sl=[];[mn,n]=size(frq);
   if min(frq)<=0 then
     error('bode: requires strictly positive frequencies')
   end
   if mn<>1 then
      ilf=1;//un vecteur de frequences par reponse
   else
      ilf=0;//un seul vecteur de frequence
   end;
else 
   error('Bode: invalid call')
end;
[mn,n]=size(phi)
//
//Captions
if comments==' ' then
   comments(mn)=' ';
   mnc=0
   hx=0.48
   else
   mnc=mn
   hx=0.43
end;

[wrect,frect]=xgetech();
//magnitude
xsetech(wrect=[wrect(1)+0,wrect(2)+0,wrect(3)*1.0,wrect(4)*hx*0.95]);
rect=[mini(frq),mini(d),maxi(frq),maxi(d)]
// just to fix the scales for xgrid
plot2d1("oln",mini(frq),mini(d),0,"051"," ",rect);
// xgrid first 
xgrid(4);
// now the curves 
plot2d1("oln",frq',d',[1:mn],"000"," ",rect);
if type(dom)==1 then
  [xx1,xx2]=xgetech();
  val= xx2([2;4])';
  plot2d1("oln",max(frq)*[1;1],val,5,"000"," ",rect);
end
xtitle('Magnitude ',' rad/s','db');

//phase
xsetech(wrect=[wrect(1)+0,wrect(2)+wrect(4)*hx,wrect(3)*1.0,wrect(4)*hx*0.95]);
rect=[mini(frq),mini(phi),maxi(frq),maxi(phi)]
// just to fix the scales for xgrid
plot2d1("oln",mini(frq),mini(phi),0,"051"," ",rect);
xgrid(4);
//  now the curves
plot2d1("oln",frq',phi',[1:mn],"000");
if type(dom)==1 then
  [xx1,xx2]=xgetech();
  val= xx2([2;4])';
  plot2d1("oln",max(frq)*[1;1],val,5,"000");
end
xtitle('Phase ',' rad/s','degrees');
if mnc>0 then
  xsetech([wrect(1)+0,wrect(2)+wrect(4)*2*hx,wrect(3)*1.0,wrect(4)*0.1],[0 0 1 1]);
  dash=xget('color')
  y0=0.7;dy=-1/2
  x0=0;dx=1/2
  count=0
  for k=1:mnc
    xset('color',k)
    xsegs([x0;x0+0.08],[y0;y0])
    rect=xstringl(x0+0.1,y0,comments(k))
    xset('color',dash(1));
    xstring(x0+0.1,y0-rect(4)/3,comments(k))
    count=count+1
    y0=y0+dy
    if count==3 then x0=x0+dx;y0=0.7,end
  end
  xset('color',dash(1))
end
xsetech(wrect,frect);
endfunction



function r_nyquist(sl,fmin,fmax,pas,comments)
// Nyquist plot 
//!
// Copyright INRIA
// giannibi: ditto, frequenze in rad/s
[lhs,rhs]=argn(0);
sltyp='x';
pas_def='auto' //valeur du pas par defaut
//---------------------
//xbasc()
ilf=0
typ=type(sl)
//-compat next line added for list/tlist compatibility
if typ==15 then typ=16,end
select typ
case 16 then  // sl,fmin,fmax [,pas] [,comments]
  typ=sl(1);typ=typ(1);
  if typ<>'lss'&typ<>'r' then
    error(97,1)
  end
  sltyp=sl('dt')
  select rhs
  case 1 then //sl
   comments=' '
   [frq,repf,splitf]=r_repfreq(sl,'sym');sl=[] 
  case 2 then // sl,frq
   comments=' '
   [frq,repf,splitf]=r_repfreq(sl,fmin);fmin=[];sl=[]
  case 3 , //sl,frq,comments ou sl,fmin,fmax
   if type(fmax)==1 then
      comments=' '
      [frq,repf,splitf]=r_repfreq(sl,fmin,fmax,pas_def),sl=[]
   else
      comments=fmax
      [frq,repf,splitf]=r_repfreq(sl,fmin);fmin=[];sl=[]
   end
  case 4 ,
    if type(pas)==1 then 
      comments=' ',
    else 
      comments=pas;pas=pas_def
    end,
    [frq,repf,splitf]=r_repfreq(sl,fmin,fmax,pas)
  case 5 then,
    [frq,repf,splitf]=r_repfreq(sl,fmin,fmax,pas)
  else 
    error('invalid call: sys,fmin,fmax [,pas] [,com]')
  end;
case 1 then //frq,db,phi [,comments] ou frq, repf [,comments]
  select rhs
  case 2 , //frq,repf
    comments=' '
    repf=fmin;fmin=[]
  case 3 then
    if type(fmax)==1 then
      comments=' '//frq db phi
      repf=exp(log(10)*fmin/20 + %pi*%i/180*fmax);
      fmin=[]; fmax=[]  
    else
      repf=fmin;fmin=[]
      comments=fmax
     end;
   case 4 then 
     repf=exp(log(10)*fmin/20 + %pi*%i/180*fmax);
     comments=pas;
     fmin=[];fmax=[]
   else 
     error('invalid call: frq,db,phi,[com] or frq,repf,[com]')
   end;
   frq=sl;sl=[];[mn,n]=size(frq);
   splitf=1
   if mn<>1 then
      ilf=1;//un vecteur de frequences par reponse
   else
      ilf=0;//un seul vecteur de frequence
   end;
else 
   error('Nyquist: invalid call')
end;

[mn,n]=size(repf)
//
if comments==' ' then
  comments(mn)=' ';
  mnc=1
else
  mnc=mn+1
end
//
//trace d
repi=imag(repf);repf=real(repf)
//
mnx=mini(repf);
mny=mini(repi);
mxx=maxi(repf);
mxy=maxi(repi);
// computing bounds of graphic window
dx=(mxx-mnx)/30;dy=(mxy-mny)/30
rect=[mnx-dx,mny-dy,mxx+dx,mxy+dy]

// drawing the curves 
splitf($+1)=n+1;
for ksplit=1:size(splitf,'*')-1
  sel=splitf(ksplit):splitf(ksplit+1)-1
  if mnc==1 then
    plot2d(repf(:,sel)',repi(:,sel)',(1:mn),"051",' ',rect);
  else
    plot2d(repf(:,sel)',repi(:,sel)',(1:mn),"151",strcat(comments,'@'),rect);
  end
end
[r1,rect]=xgetech()
// drawing the grid 
alu=xget('alufunction');xset('alufunction',6)
xgrid(4);
xset('alufunction',alu)
// setting the current mark 
xgeti=xget("mark");
xset("mark",2,xgeti(2));
// clipping on (graphic box)
xset("clipgrf");

kk=1;p0=[repf(:,kk) repi(:,kk)];ks=1;d=0;
dx=rect(3)-rect(1)
dy=rect(4)-rect(2)
dx2=dx^2;dy2=dy^2

// collection significant frequencies along the curve 
//-------------------------------------------------------
Ic=mini(cumsum(sqrt(((repf(:,1:$-1)-repf(:,2:$)).^2)/dx2+((repi(:,1:$-1)-repi(:,2:$)).^2)/dy2),2),'r');
kk=1
L=0
DIc=0.2
while %t
  ksup=find(Ic-L>DIc)
  if ksup==[] then break,end
  kk1=mini(ksup)
  L=Ic(kk1)
  Ic(1:kk1)=[]
  kk=kk+kk1
  
  if mini(abs(frq(:,ks($))-frq(:,kk))./abs(frq(:,kk)))>0.001 then
    if mini(sqrt(((repf(:,ks)-repf(:,kk)*ones(ks)).^2)/dx2+..
        ((repi(:,ks)-repi(:,kk)*ones(ks)).^2)/dy2)) >DIc then
      ks=[ks kk]
      d=0
    end
  end
end  
if ks($)~=n then    
if mini(((repf(:,ks(1))-repf(:,n))^2)/dx2+((repi(:,ks(1))-repi(:,n))^2)/dy2)>0.01
  ks=[ks n]
end
end
// display of parametrization (frequencies along the curve)
//-------------------------------------------------------
kf=1
frmt=format();
mrksiz=0.015*(rect(3)-rect(1))

for k=1:mn,
  for kks=ks
    if abs(frq(kf,kks))>9999|abs(frq(kf,kks))<0.001 then
      format('e',6)
    else
      format('v',6)
    end
    xstring(repf(k,kks),repi(k,kks),string(frq(kf,kks)),0);
  end
  if size(ks,'*') >1 then
    if ks($)<size(repf,2) then
      last=$;
    else
      last=$-1;
    end
    dx=repf(k,ks(1:last)+1)-repf(k,ks(1:last));
    dy=repi(k,ks(1:last)+1)-repi(k,ks(1:last));
    dd=150*sqrt((dx/(rect(3)-rect(1))).^2+(dy/(rect(4)-rect(2))).^2);
    if dd>0 then
      dx=dx./dd;dy=dy./dd;

      xarrows([repf(k,ks(1:last));repf(k,ks(1:last))+dx],..
          [repi(k,ks(1:last));repi(k,ks(1:last))+dy],mrksiz)
    end
  end
//  xpoly(repf(k,ks),repi(k,ks),'marks',0);
  kf=kf+ilf
end;
vv=['v','e'];format(vv(frmt(1)),frmt(2))


xset("mark",xgeti(1),xgeti(2));
// axes with 0 
[w,rect]=xgetech()
xpoly([rect(1),rect(3)],[0,0],'lines');
xpoly([0,0],[rect(2),rect(4)],'lines');
//Optional unit circle 
//t=(0:0.1:2*%pi)';
//plot2d(sin(t),cos(t),[(mn+1) -mnc],'100','Unit Circle')

// clipping off 
xclip();

if sltyp=='c' then
  xtitle('Nyquist plot ','Re(h(2i*pi*f))','Im(h(2i*pi*f))');
elseif sltyp=='x' then 
    xtitle('Nyquist plot ','Re','Im');
else   
  xtitle('Nyquist plot ',['Re(h(exp(';'f*dt)))'],'Im(h(exp(f*dt)))');
end
endfunction



function [frq,rep,splitf]=r_repfreq(sys,fmin,fmax,pas)
// Copyright INRIA
// giannibi: modified to compute frequency response as a function of omega
// (rad/s)
pas_def='auto';
l10=log(10);
[lhs,rhs]=argn(0)
//discretization 

if type(sys)<>16 then  error(97,1),end;
flag=sys(1);
dom=sys('dt')
if dom==[]|dom==0 then error(96,1),end
if dom=='d' then dom=1;end

select  rhs
case 1 then
  pas=pas_def
  if dom=='c' then fmax=1.d3; else fmax=%pi/dom,end
  fmin=0
case 2 then
  if type(fmin)==10 then
    rhs=1
    pas=pas_def
    if dom=='c' then fmax=1.d3; else fmax=%pi/dom,end
    if fmin=='sym' then
      fmin=-fmax
    else
      fmin=0
    end
  else
    frq=fmin
  end
case 3 then
  pas=pas_def
case 4 then ,
else 
  error('calling sequences: sys,fmin,fmax [,pas] or sys,frq')
end;
splitf=1
if rhs<>2 then
  if type(pas)==1 then
    splitf=1
    eps=1.e-14
    if fmin<0&fmax>=0 then
      frq=- [exp(l10*((log(eps)/l10):pas:(log(-fmin)/l10))) -fmin];
      if fmax>eps then
        frq1=[exp(l10*((log(eps)/l10):pas:(log(fmax)/l10))) fmax];
        frq=[frq($:-1:1) frq1]
      else
        frq=frq($:-1:1);
      end
    elseif fmin<0&fmax<0 then
      frq= [exp(l10*((log(-fmax)/l10):pas:(log(-fmin)/l10))) -fmin];
      frq=-frq($:-1:1);
    elseif fmin >= fmax then
      error('repfrq: fmin must be < fmax');
    else
      fmin=max(eps,fmin);
      frq=[exp(l10*((log(fmin)/l10):pas:(log(fmax)/l10))) fmax];
    end
  else
    [frq,bnds,splitf]=r_calfrq(sys,fmin,fmax)
  end;
end
//
typ=sys(1)
select typ(1)
case 'r' then
  [n,d]=sys(['num','den']),
  [mn,nn]=size(n)
  if nn<>1 then error(95,1),end
  if dom=='c' then 
    rep=freq(n,d,%i*frq),
  else 
    rep=freq(n,d,exp(%i*dom*frq)),
  end;
case 'lss' then
  [a,b,c,d,x0]=sys(2:6),
  [mn,nn]=size(b)
  if nn<>1 then error(95,1),end
  if dom=='c' then 
    rep=freq(a,b,c,d,%i*frq)
  else 
    rep=freq(a,b,c,d,exp(%i*dom*frq))
  end;
else error(97,1),
end;
//representation
if lhs==1 then frq=rep,end
endfunction


function r=r_routh(h)
// Semplice wrapper per aggirare il bug di routh_t
n=h("num");
d=h("den");
r=routh_t(n+d);
endfunction




