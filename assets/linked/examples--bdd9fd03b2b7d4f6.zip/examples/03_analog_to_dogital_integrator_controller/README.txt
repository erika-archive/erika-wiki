File contenuti nella cartella:

1)cd.sci
2)progetto_cont_int_DIG_loop.sce
3)progetto_cont_int_DIG_loop.cos

Il file "cd.sci" � una raccolta di funzioni del prof. Gianni Bianchini. In particolare in questo caso  � stato 
inserito per sfruttare la funzione di approssimazione di Tustin e di tustin con prewarping presente nel file (tstn() e tstnpw() ).

Nello script "progetto_cont_int_DIG_loop.sce" vengono dichiarate le specifiche, calcolato il valore del condensatore, il ripple della corrente sull'induttore, viene calcoalta la funzione di trasferimento
Viene poi approssimata ad una funzione di trasferimento digitale usando il metodo di Tustin attraverso la funzione tstn()....e in alternativa la funzione tstnpw() equivalente con prewarping.

Nel file "progetto_cont_int_DIG_loop.cos" � rappresentato lo schema a blocchi del sistema in retroazione unitaria con il 
controllore digitale e il S/H.


