File contenuti nella cartella: 

1)progetto_cont_DIG_poleplacement_stato.sce
2)progetto_cont_DIG_poleplacement_stato.cos

Il controllore realizzato in questo caso � un controllore statico in retroazione dello stato che posiziona i poli ( sotto
alcune condizioni es. RAGGIUNGIBILT�) in posizioni desiderate.

Nel primo file "progetto_cont_DIG_poleplacement_stato.sce" vengono definite le specifiche del progetto, il valore dei condensatori, il valore della corrente di ripple sull'induttore e viene calcolata la funzione di trasferimento del sistema.
Vengono definite le matrici di stato del sistema dalle quali viene calcolata la legge di retroazione per lo spostamento dei poli in posizioni desiderate(la matrice F).

Nel file "progetto_cont_DIG_poleplacement_stato.cos" � implementato lo schema a blocchi per tale controllore con due anelli di retroazione:
i)il primo � relativo alla legge di retroazione statica dallo stato, e permette di allocare i poli in posizione desiderata
ii) il secondo serve per chiudere il sistema in un ulteriore azione integrale che permette di annullare disturbi costanti in 
ingresso nell'anello.
