//13 luglio 2008

//Sentire Simone per come vuole che venga impostato il controllore...
//con questo metodo e con il disturbo sulla tensione di ingresso abbiamo
//bisogno di un condensatore più grande oppure di una legge di controllo calcolata in
//maniera un pò subdola(dalle matrici di stato del sistema) 
// :-) senitire come vuole che venga risolto il problema

// Esempio di allocazione dei poli con retroazione dallo stato



//getf('cd.sci');

E  = 15.0 ;         // [Volt] Input voltage 
Vo =  5.0 ;         // [Volt] Output voltage 
Vo_rif=Vo;
t_sim=5;
s=%s;

Don = Vo/E      ;   // Duty Cycle : ideal input/output voltage gain 
Delta_Vo = 0.1;     // [Volt] peak-peak output ripple
Ts = 1*10^(-3);     // [Second]: switching period
t_on = Don*Ts ;     // [Second]: switch ON time 
t_of = Ts-t_on;     // [Second]: switch OFF time
Ro = 5.1 ;          // [Ohm]: output load
L  = 2*28^(-3);     // [Henry] : output inductance

// Usually the inductance is calculated in order to obtain a reasonable current ripple 
// In this case, the indictance is given and the current ripple is calculated as 
// L = (E*(1-D)*D*Ts)/Delta_i_L;

// Parameters used by the PWM super block 
K_nor  = 1/Ts;      //Normalized gain; in order to obtain [0-1] sawthoot 
K_prop = 1/Vo;      //
                    
//Delta_i_L=0.1;
// The peak-peack current ripple in the inductor is 
//L=(E*(1-D)*D*Ts)/Delta_i_L;
Delta_i_L=(E*(1-Don)*Don*Ts)/L; //[Ampere]

// The capacitor "C" value is a function of the desired output voltage ripple
// and the current ripple 
Ca=(Delta_i_L*Ts)/(8*Delta_Vo);

// The "ideal" "small-signal" trasfer functions (using computed Ro, C, L, etc. values) is :
fdt_Vo_d = syslin('c',E,((L*Ca)*s^(2)+(L/Ro)*s+1) );


//Matrici di stato del sistema
A=[0 -1/L; 1/Ca -1/(Ro*Ca)];
B=[E/L; 0];
C=[0 1];
D=0;

sys=syslin('c',A,B,C,D);
//Calcolando la retroazione con le matrici di stato otteniamo un buon controllore
//Estraendo le matrici di stato dal sistema linearizzato invece ci introduce molte
//oscillazioni e se volgiamo risolvere il problema dobbiamo aumentare la capacità
//del condensatore!
//sys=tf2ss(fdt_Vo_d);

// ordine del sistema
n=size(sys("A"));
n=n(1);

// Discretizzazione
sysd=dscr(sys,Ts);

Ad=sysd("A");
Bd=sysd("B"); // Estrae matrici A e B del discretizzato
Cd=sysd("C");

// Calcolo del sistema aumentato
Adaug=[Ad zeros(Bd) ; -Cd 1];
Bdaug=[Bd;0];

//Poli dominanti desiderati (molto vicini a zero)
zeta=0.9;
omegan=1000;
fdt_desired=syslin('c',1,(1/omegan^2)*s^2 + ((2*zeta)/omegan) *s +1 ) ;

t=[0:0.001:1];
simulation = csim("step",t,fdt_desired);
gh_time = scf(1); clf(1); 
plot2d(t,simulation);
gh_time.figure_name = "Unit step time reponse";
polidominanti=[roots(denom(fdt_desired))];

polidominantidisc=exp(Ts*polidominanti);
// calcolo della legge di controllo FK
//FK=-ppol(Adaug,Bdaug,[polidominantidisc' 0]);

//calcolo della legge di controllo FK assegnado tutti i poli in zero
FK=-ppol(Adaug,Bdaug,[0 0 0]);
// separazione di F e K
F=FK(1:n);
K=FK(n+1);


