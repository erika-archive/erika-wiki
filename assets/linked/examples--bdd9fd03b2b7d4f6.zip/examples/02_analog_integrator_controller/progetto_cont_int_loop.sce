// Variable definitions
//** Inside Scilab there are two ways to define the "s" complex variable 
s = %s ;         // using the Scilab predefined complex variable  
s = poly(0,'s'); // using the explicit polynomial definition  


// Input design data 
// [E, Vo, Po]   [Tensione di ingresso, Tensione D'uscita, Potenza d'uscita]  

//Specifiche in ingresso

E  = 15.0 ;  // [Volt] Input voltage 
Vo =  5.0 ;  // [Volt] Output voltage 
Vo_rif=Vo;
t_sim = 1.5;  //[second] Simulation time  

D = Vo/E      ;    // Duty Cycle : ideal input/output voltage gain 
Delta_Vo = 0.1;    // [Volt] peak-peak output ripple
Ts = 1*10^(-3);    // [Second]: switching period
t_on = D*Ts ;      // [Second]: switch ON time 
t_of = Ts-t_on;    // [Second]: switch OFF time
Ro = 5.1 ;         // [Ohm]: output load
L  = 2*10^(-3);    // [Henry] : output inductance
// Usually the inductance is calculated in order to obtain a reasonable current ripple 
// In this case, the indictance is given and the current ripple is calculated as 
// L = (E*(1-D)*D*Ts)/Delta_i_L;

Error=0.1;    // ramp error desired

// Parameters used by the PWM super block 
K_nor  = 1/Ts; // Normalized gain; in order to obtain [0-1] sawthoot 
K_prop = 1/Vo;  //
                    

// The peak-peack current ripple in the inductor is 
//L=(E*(1-D)*D*Ts)/Delta_i_L;
Delta_i_L=(E*(1-D)*D*Ts)/L; //[Ampere]
// The capacitor "C" value is a function of the desired output voltage ripple
// and the current ripple 
C = (Delta_i_L*Ts)/(8*Delta_Vo);

// An alternative equation (same numerical result) is 
// C1=((1-D)*Ts^2*Vo)/(8*L*Delta_Vo);

// The "ideal" "small-signal" trasfer functions (using computed Ro, C, L, etc. values) is :
fdt_Vo_d = syslin('c',E,((L*C)*s^(2)+(L/Ro)*s+1) );

sigma = (sqrt(L*C))/(2*C*Ro); // damping factor 
omega_r = 1/(sqrt(L*C)) ;     // [rad/s] natural pulsation frequency 
fr = omega_r/(2*%pi); // [Hz] natural frequency 
picco_ris    =  1/(2*sigma*sqrt(1-sigma^2));  // resonance peak value 
picco_ris_db = 20*log(picco_ris);             //[db] resonance peak value
puls_ris=omega_r*sqrt(1-2*sigma^2);  // [rad/sec] resonant frequency 

// Closed loop system

// Desired - closed loop - crossing frequency (closed loop bandwith) 
fa0 = 50;        // [Hertz]
wa0 = 2*%pi*fa0; // [rad/sec] pulsation 


// Phase margin 
mf0 = 45;           //[gradi] margine di fase desiderato

// Bode static gain adjust 
Kc=1/(E*Error); // from the final value theorem 

//Kind of sistem
h=1;              //Tipo del sistema
Ctipo=syslin('c',Kc,s^h);

// open loop gain without compensation networks 
Lprimo = Ctipo*fdt_Vo_d;
gh_open = scf(1); clf(1); bode(Lprimo);
gh_open.figure_name = "Open loop with final value spec.";

//gain adjust for Lds at omega_a_0
K=10^(35/20);


ma=20;
wta=0.8;
Ca=syslin('c',1+(wta/wa0)*s,1+s*(wta/wa0)/ma);



// Controller design  
Cds = K*Ctipo*Ca*Ca;

// Loop gain 
Lds = Cds*fdt_Vo_d;
gh_comp = scf(2); clf(2); bode(Lds);
gh_comp.figure_name = "Small-signal open loop compensated t.f.";  

gh_comp2 = scf(3); clf(3); evans(Lds);
gh_comp2.figure_name = "root locus of open loop gain";

gh_comp3 = scf(4); clf(4); nyquist(Lds);
gh_comp3.figure_name = "nyquist diagram of L(s)";

// Closed loop gain trasfer function 
//disp("Funzione di trasferimento ad anello chiuso");
uno = syslin('c',1,1);
Wds =Lds/.uno;//L(s)/(1+L(s)) ; ??
gh_close = scf(5); clf(5); bode(Wds);
gh_close.figure_name = "Small-signal closed loop t.f.";  


// Design verification 
// Unit step input reponse 
//disp("Risposta al gradino FdT ad anello chiuso")
t=[0:0.01:1];
Wdoppio = csim("step",t,Wds);
gh_time = scf(6); clf(6); 
plot2d(t,Wdoppio)
gh_time.figure_name = "Unit step time reponse";

