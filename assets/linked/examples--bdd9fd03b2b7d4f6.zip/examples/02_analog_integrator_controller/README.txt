File presenti nella cartella :

1)progetto_cont_int_loop.sce
2)progetto_cont_int_loop.cos

Nel primo file vengono come di consueto definite le specifiche del sistema ( sempre uguali ma devono essere inizializzate
tutte le volte), calcolata la funzione di trasferimento e calcolato un controllore con azione integrale con i metodi classici di progetto di controllori analogici.
Il controllore con azione integrale si permette di eliminare l'azione del sistema feedforward in ingresso e quindi ci permette di ricondurci allo studio di un sistema in retroazione unitaria classica.

Nel file progetto_cont_int_loop.cos possiamo notare la nuova configurazione del sistema in retroazione unitaria. Il controllore � ancora analogico.
