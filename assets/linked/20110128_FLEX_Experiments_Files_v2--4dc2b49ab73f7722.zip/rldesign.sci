function rldesign(G)
// Distributing version for rldesign version 3
funcprot(0);
//clear;
//exec('bode2.sci');
//global handles.axes1_h handles.axes2_h handles.axes3_h handles.axes4_h  handles.g;

x = 0; y = 0 ;
handles.axes1  = 1;
handles.axes2  = 1;
handles.axes3  = 1;
handles.axes4  = 1;
h=figure('position',[0 50 300 550],'units','pixels');

//*************
//Initialize Axes
//*************
subplot(4,1,1);
handles.axes1=gca();
handles.axes1.axes_bounds = [0.15 -0.1 0.42,1.2];
plot(x(1),y(1));
handles.axes1.axes_visible = ['off','off','off']; 
    
subplot(4,1,2);
handles.axes2=gca();
handles.axes2.axes_bounds = [0.52 0 0.52,0.3];
plot(x(1),y(1));
handles.axes2.axes_visible = ['off','off','off']; 

subplot(4,1,3);
handles.axes3=gca(); 
handles.axes3.axes_bounds = [0.52 0.25 0.52,0.3];
plot(x(1),y(1));
handles.axes3.axes_visible = ['off','off','off']; 

subplot(4,1,4);
handles.axes4=gca(); 
handles.axes4.axes_bounds = [0.52 0.5 0.52,0.5];
plot(x(1),y(1));
handles.axes4.axes_visible = ['off','off','off']; 


//*************
// Plant Panel
//*************
uicontrol(h, "units","pixels", "style", "frame","string","Plant","position",[5 465 250 80],'fontsize',12,'BackgroundColor',[0.8 0.8 0.8]);
  uicontrol(h, "units","pixels", "style", "text","string","Plant","position",[60 520 80 20],'fontsize',12);
  uicontrol(h, "units","pixels", "style", "text","string","Num","position",[10 500 80 20],'fontsize',12);
  uicontrol(h, "units","pixels", "style", "text","string","Den","position",[10 470 80 20],'fontsize',12);
  handles.num= uicontrol(h, "units","pixels", "style", "edit","string","3","position",[80 500 150 20],'fontsize',12);
  handles.den= uicontrol(h, "units","pixels", "style", "edit","string","3*s^2 + s + 2","position",[80 470 150 20],'fontsize',12);
  
//*************    
// Control Panel
//*************
handles.update= uicontrol(h, "units","pixels", "style", "pushbutton","string","Update","position",[40 430 100 30],"Callback","pbUpdate(handles,h)",'fontsize',12);
handles.gain= uicontrol(h, "units","pixels", "style", "slider","string","Update","position",[5 400 250 20],"Min",1,"Max",1000,"SliderStep",[1 10],"Callback","sldGain(handles,h)","value",10);
handles.sldval = uicontrol(h, "units","pixels", "style", "text","string","1","position",[50 380 80 20],'fontsize',12);

//*************    
// Controller Panel
//*************    
uicontrol(h, "units","pixels", "style", "frame","string","Controller","position",[5 300 250 82],'fontsize',12,'BackgroundColor',[0.8 0.8 0.8]);
  uicontrol(h, "units","pixels", "style", "text","string","Controller","position",[60 360 80 20],'fontsize',12);
  uicontrol(h, "units","pixels", "style", "text","string","Num","position",[10 340 100 20],'fontsize',12);
  uicontrol(h, "units","pixels", "style", "text","string","Den","position",[10 310 100 20],'fontsize',12);
  handles.numC= uicontrol(h, "units","pixels", "style", "edit","string","1","position",[80 340 150 20],'fontsize',12);
  handles.denC= uicontrol(h, "units","pixels", "style", "edit","string","1","position",[80 310 150 20],'fontsize',12);
  
//*************    
// Prefilter Panel
//*************    
uicontrol(h, "units","pixels", "style", "frame","string","Prefilter","position",[5 220 250 82],'fontsize',12,'BackgroundColor',[0.8 0.8 0.8]);
  uicontrol(h, "units","pixels", "style", "text","string","Prefilter","position",[60 280 80 20],'fontsize',12);
  uicontrol(h, "units","pixels", "style", "text","string","Num","position",[10 260 100 20],'fontsize',12);
  uicontrol(h, "units","pixels", "style", "text","string","Den","position",[10 230 100 20],'fontsize',12);
  handles.numF= uicontrol(h, "units","pixels", "style", "edit","string","1","position",[80 260 150 20],'fontsize',12);
  handles.denF= uicontrol(h, "units","pixels", "style", "edit","string","1","position",[80 230 150 20],'fontsize',12);

//*************    
// Design Contraint
//*************    
uicontrol(h, "units","pixels", "style", "frame","string","Design Constraint","position",[5 220-120 250 122],'fontsize',12,'BackgroundColor',[0.8 0.8 0.8]);
  uicontrol(h, "units","pixels", "style", "text","string","Design Constraint","position",[20 280-80 120 20],'fontsize',12);
  uicontrol(h, "units","pixels", "style", "text","string","%OS","position",[10 260-80 100 20],'fontsize',12);
  uicontrol(h, "units","pixels", "style", "text","string","Ts","position",[10 230-80 100 20],'fontsize',12);
  handles.OS = uicontrol(h, "units","pixels", "style", "edit","string","10","position",[80 260-80 150 20],'fontsize',12);
  handles.Ts = uicontrol(h, "units","pixels", "style", "edit","string","1","position",[80 230-80 150 20],'fontsize',12);
  handles.decon= uicontrol(h, "units","pixels", "style", "pushbutton","string","Show Constraint","position",[40 190-80 100 30],"Callback","pbShow(handles,h)",'fontsize',12);

//handles.closef= uicontrol(h, "units","pixels", "style", "pushbutton","string","Close","position",[40 100 100 30],"Callback","pbClose(handles,h)");

// Initialization;s
handles.buffer = 0
handles.axes1_h = 0;
handles.axes2_h = 0;
handles.axes3_h = 0;
handles.axes4_h = 0;
handles.g = 0;

try
set(handles.num,'string',pol2str(G.num));
set(handles.den,'string',pol2str(G.den));
end

pbUpdate(handles,h)



[handles,h] = resume(handles,h);


endfunction
//*************    
// Update Button
//*************    
function pbUpdate(handles,h)
  
// Preparing handles for plot updates 
    //clear handles.axes1_h; global handles.axes1_h; handles.axes1_h = 0;  
    //clear handles.axes2_h; global handles.axes2_h; handles.axes2_h = 0;   
    //clear handles.axes3_h; global handles.axes3_h; handles.axes3_h = 0;   
    //clear handles.axes4_h; global handles.axes4_h; handles.axes4_h = 0;
    val = get(handles.gain,'value')/10;    
    
// Calculation    
 
  s=poly(0,'s');	
  
  // Get the Plant Tranfer Functions
  num = eval(get(handles.num,'string'));
  den = eval(get(handles.den,'string'));
  Gol = syslin('c',(num),den);
  
  // Get the Controller Tranfer Functions
  numC = eval(get(handles.numC,'string'));
  denC = eval(get(handles.denC,'string'));
  Gc=syslin('c',(numC),denC);
  
  numF = eval(get(handles.numF,'string'));
  denF = eval(get(handles.denF,'string'));
  handles.Gf=syslin('c',(numF),denF);
  
  // Open Loop TF with Controller
  handles.g = Gol * Gc;
  drawlater();
// 1. Root Locus Plot
  sca(handles.axes1);
  delete(handles.axes1.children);
  evans(handles.g);
 // pause
  // Calculate close loop gain
  gl=1+val*handles.g;
  numl=numer(gl);
  r=roots(numl);
  x=real(r);
  y=imag(r);
  plot(x,y,'o');
  handles.axes1_h = gce();
  
// 2. Bode Mag Plot  
  sca(handles.axes2);
  //wrect=axes.axes_bounds;
  //axes.axes_bounds=[wrect(1)+0,wrect(2)+0,wrect(3)*1.0,wrect(4)*hx*0.95]
  [fdata,ddata,pdata,gdata]=bode2(val*handles.g,0.01,100);
  handles.axes2.data_bounds = [min(fdata),min(ddata);max(fdata),max(ddata)];
  handles.axes2.log_flags = "lnn" ;
  handles.axes2.grid=color('lightgrey')*ones(1,3);
  handles.axes2.axes_visible="on";
  handles.axes2.clip_state = "clipgrf";
  mtlb_grid on;
  delete(handles.axes2.children);
  xpolys(fdata,ddata,gdata);
  handles.axes2_h =  gce();
  
// 3. Bode Phase Plot  
  sca(handles.axes3);
  //wrect=axes.axes_bounds;
  //axes.axes_bounds=[wrect(1)+0,wrect(2)+0,wrect(3)*1.0,wrect(4)*hx*0.95]
  handles.axes3.data_bounds = [min(fdata),min(pdata);max(fdata),max(pdata)];
  handles.axes3.log_flags = "lnn" ;
  handles.axes3.grid=color('lightgrey')*ones(1,3);
  handles.axes3.axes_visible="on";
  handles.axes3.clip_state = "clipgrf";
  mtlb_grid on;
  delete(handles.axes3.children);
  xpolys(fdata,pdata,gdata);
  handles.axes3_h =  gce();
  
// 4. Step Response
  sca(handles.axes4);
  mtlb_grid on;
  delete(handles.axes4.children);
  g2 = syslin('c',1,1);
  gcl = ((val*handles.g)/.g2)*handles.Gf ;
  t=0:0.001:10;
  y=csim('step',t,gcl);  
  plot(t,y);
  handles.axes4_h = gce();
  drawnow();
// Resuming Sstates: ??? Is it correct way??? 
[handles] = resume(handles); 

endfunction


function sldGain(handles,h)
 handles.buffer = handles.buffer + 1;  
  if handles.buffer <=1
    
    // Place time consuming code here

    val = get(handles.gain,'value')/10;    
    
    // Checking Buffer and also Gain
    //disp([handles.buffer,val]);   
    
    //sleep(500);  
    UpdatePlot(handles,h);
    handles.buffer =handles.buffer - 1;
    //set(handles.sldval,'string',string(val));   
    //UpdatePlot(handles,h);
    handles = resume(handles);
    //UpdatePlot(handles,h);
  else
      
      handles.buffer =handles.buffer - 1;
     // pause;
    val = get(handles.gain,'value')/10;    
    set(handles.sldval,'string',string(val));
   //disp('.');
    handles = resume(handles);
    
  end  
  handles = resume(handles);
  

  
//try
//   if handles.axes4_h ~= 0 
//    val1 = get(handles.gain,'value');
//    sleep(50);
//    val2 = get(handles.gain,'value');
//    sleep(50);
//    while val1 ~= val2 do
//      //abort;
//      disp('Moving');
//   end
//    
//    
//    
//  end
//catch
//  //disp(lasterror);
//  //abort;
//  disp('Error');
//end
////UpdatePlot(handles,h)
////sldGain(handles,h)
// aaa = gcb

endfunction



function UpdatePlot(handles,h)
  
    val = get(handles.gain,'value')/10;    
    set(handles.sldval,'string',string(val));
    
    gl=1+val*handles.g;
    numl=numer(gl);
    r=roots(numl);
    x=real(r);
    y=imag(r);
    
    g2 = syslin('c',1,1);
    gcl = ((val*handles.g)/.g2)*handles.Gf;
    t=0:0.001:10;
    y2=csim('step',t,gcl);  
    [fdata,ddata,pdata,gdata]=bode2(val*handles.g,0.01,100);
    
    drawlater();
    // 1. Root Locus
    sca(handles.axes1);
    set(handles.axes1_h.children,'data',[x,y]);
    
    // 2. Bode Mag Plot  
    sca(handles.axes2);
    mtlb_grid on;
    set(handles.axes2_h.children,'data',[fdata,ddata]);
    handles.axes2.data_bounds = [min(fdata),min(ddata);max(fdata),max(ddata)];
    
    // 3. Phase Mag Plot  
    sca(handles.axes3);
    mtlb_grid on;
    set(handles.axes3_h.children,'data',[fdata,pdata]);
    handles.axes3.data_bounds = [min(fdata),min(pdata);max(fdata),max(pdata)];
        
    // 4. Step Response
    sca(handles.axes4);  
    mtlb_axis([0 10 0 max(y2)]);
    set(handles.axes4_h.children,'data',[t',y2']);

if handles.buffer <=1
    drawnow();
end
   [handles] = resume(handles);
   
endfunction

function pbShow(handles,h)
  sca(handles.axes1);
  OS = eval(get(handles.OS,'string'));  
  zeta = abs(log(OS/100))/(sqrt(%pi^2 + log(OS/100)^2));
  Ts = eval(get(handles.Ts,'string'));  
  wn = 4/(zeta*Ts);
  sgrid(zeta,wn,7);

endfunction

// Do note that bode2 is mmodified from the Scilab Function "bode"
// Scilab ( http://www.scilab.org/ ) - This file is part of Scilab
// Copyright (C) INRIA Serge Steer
// This file must be used under the terms of the CeCILL.
// This source file is licensed as described in the file COPYING, which
// you should have received as part of this distribution.  The terms
// are also available at    
// http://www.cecill.info/licences/Licence_CeCILL_V2-en.txt

function [fdata,ddata,pdata,gdata]=bode2(varargin)
  rhs=size(varargin)
  if type(varargin($))==10 then
    comments=varargin($),rhs=rhs-1;
  else
    comments=[];
  end
  fname="bode";//for error messages
  fmax=[]
  if or(typeof(varargin(1))==['state-space' 'rational']) then 
    //sys,fmin,fmax [,pas] or sys,frq
    refdim=1 //for error message
    if rhs==1 then //sys
      [frq,repf]=repfreq(varargin(1),1d-3,1d3)
    elseif rhs==2 then //sys,frq
      if size(varargin(2),2)<2 then
	error(msprintf(_("%s: Wrong size for input argument #%d: A row vector with length>%d expected.\n"),..
		       fname,2,1))
      end
      [frq,repf]=repfreq(varargin(1:rhs))
    elseif or(rhs==(3:4)) then //sys,fmin,fmax [,pas]
      [frq,repf]=repfreq(varargin(1:rhs))
    else
      error(msprintf(_("%s: Wrong number of input arguments: %d to %d expected.\n"),fname,1,5))
    end
    [phi,d]=phasemag(repf)
    if rhs>=3 then fmax=varargin(3),end
  elseif  type(varargin(1))==1 then 
    //frq,db,phi [,comments] or frq, repf [,comments]
    refdim=2
    select rhs
    case 2 then //frq,repf
      frq=varargin(1);
      if size(frq,2)<2 then
	error(msprintf(_("%s: Wrong size for input argument #%d: A row vector with length>%d expected.\n"),..
		       fname,1,1))
      end
      if size(frq,2)<>size(varargin(2),2) then
	error(msprintf(_("%s: Incompatible input arguments #%d and #%d: Same column dimensions expected.\n"),..
			 fname,1,2))
      end
      [phi,d]=phasemag(varargin(2))
    case 3 then  //frq,db,phi
      [frq,d,phi]=varargin(1:rhs)
      if size(frq,2)<>size(d,2) then
	error(msprintf(_("%s: Incompatible input arguments #%d and #%d: Same column dimensions expected.\n"),..
			 fname,1,2))
      end
      if size(frq,2)<>size(phi,2) then
	error(msprintf(_("%s: Incompatible input arguments #%d and #%d: Same column dimensions expected.\n"),..
			 fname,1,3))
      end
    else 
       error(msprintf(_("%s: Wrong number of input arguments: %d to %d expected.\n"),fname,2,4))
    end
  else
    error(msprintf(_("%s: Wrong type for input argument #%d: Linear dynamical system or row vector of floats expected.\n"),fname,1))
  end;
   frq=frq';d=d',phi=phi'
  [n,mn]=size(d)

  if comments==[] then
    hx=0.48
  else
    if size(comments,'*')<>mn then
      error(msprintf(_("%s: Incompatible input arguments #%d and #%d: Same number of elements expected.\n"),...
		     fname,refdim,rhs+1))
    end
    hx=0.43
  end;

  if size(d,2)>1&size(frq,2)==1 then
    fdata = frq(:,ones(1,mn));
    ddata = d;
    gdata = 1:mn;
  else
    fdata = frq;
    ddata = d;
    gdata = 1:mn;
  end
 
  if size(phi,2)>1&size(frq,2)==1 then
    pdata = phi;
  else
    pdata = phi;
  end


endfunction
